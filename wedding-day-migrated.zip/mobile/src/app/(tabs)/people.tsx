import { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Modal,
  useWindowDimensions,
  FlatList,
} from "react-native";
import { useRouter, useFocusEffect } from "expo-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Plus, X } from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { ImportantPersonDTO, ImportantPersonCategory } from "@/lib/types";
import { IMPORTANT_PERSON_CATEGORIES, PERSON_CATEGORY_LABELS } from "@/lib/types";
import { QUERY_KEYS, getInitials } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";

const CATEGORY_COLORS: Record<ImportantPersonCategory, string> = {
  family: "#F5EDD8",
  bridalParty: "#FCE8E8",
  speechGiver: "#E8F0F8",
  officiant: "#EDE8F5",
  vip: "#E8F5ED",
  other: "#F0EDE8",
};
const CATEGORY_TEXT: Record<ImportantPersonCategory, string> = {
  family: "#C9A84C",
  bridalParty: "#E8474B",
  speechGiver: "#3B82F6",
  officiant: "#8B5CF6",
  vip: "#059669",
  other: "#8B7355",
};
const AVATAR_BG = ["#C9A84C", "#D4A0A0", "#8B7355", "#A8C5DA", "#B5A99A", "#C4B5D4", "#9BB5A0"];
function avatarColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_BG[Math.abs(h) % AVATAR_BG.length];
}

type FilterKey = "all" | ImportantPersonCategory;
const FILTER_OPTIONS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  ...IMPORTANT_PERSON_CATEGORIES.map((c) => ({ key: c as FilterKey, label: PERSON_CATEGORY_LABELS[c] })),
];

type LightboxState = { uri: string; name: string; relationship: string; notes: string | null } | null;

export default function PeopleScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<FilterKey>("all");
  const [lightbox, setLightbox] = useState<LightboxState>(null);

  const { data: people, isLoading } = useQuery({
    queryKey: QUERY_KEYS.people(activeWeddingId ?? ""),
    queryFn: () => api.get<ImportantPersonDTO[]>(`/api/weddings/${activeWeddingId}/important-people`),
    enabled: !!activeWeddingId,
  });

  const { data: wedding } = useQuery({
    queryKey: QUERY_KEYS.wedding(activeWeddingId ?? ""),
    queryFn: () => api.get<{ myRole: string }>(`/api/weddings/${activeWeddingId}`),
    enabled: !!activeWeddingId,
  });

  useFocusEffect(
    useCallback(() => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.people(activeWeddingId ?? "") });
    }, [activeWeddingId, queryClient])
  );

  const canEdit = wedding?.myRole === "admin" || wedding?.myRole === "couple";
  const filtered = filter === "all"
    ? (people ?? [])
    : (people ?? []).filter((p) => p.category === filter);

  // card width: 2 columns with 12px gap and 20px side padding
  const cardWidth = (width - 40 - 12) / 2;
  const photoSize = cardWidth - 0; // full card width

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="people-screen">
      {/* Category filter tabs */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ flexGrow: 0, borderBottomWidth: 1, borderBottomColor: "#E8E0D5", backgroundColor: "#FFFFFF" }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 12, gap: 8 }}
      >
        {FILTER_OPTIONS.map(({ key, label }) => {
          const active = filter === key;
          return (
            <Pressable
              testID={`filter-${key}`}
              key={key}
              onPress={() => setFilter(key)}
              style={{
                backgroundColor: active ? "#C9A84C" : "#F5F0E8",
                borderRadius: 100,
                paddingHorizontal: 16,
                paddingVertical: 7,
              }}
            >
              <Text
                style={{
                  fontFamily: "DMSans_500Medium",
                  fontSize: 13,
                  color: active ? "#FFFFFF" : "#8B7355",
                }}
              >
                {label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {/* Grid */}
      {filtered.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 60 }}>
          <Text style={{ fontSize: 48, marginBottom: 16 }}>💐</Text>
          <Text style={{ fontFamily: "PlayfairDisplay_400Regular", fontSize: 20, color: "#8B7355", textAlign: "center" }}>
            {filter === "all" ? "No people added yet" : `No ${PERSON_CATEGORY_LABELS[filter as ImportantPersonCategory]} added`}
          </Text>
          {canEdit ? (
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginTop: 8, textAlign: "center" }}>
              Tap + to add family, bridal party, and VIPs
            </Text>
          ) : null}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={{ padding: 20, paddingBottom: 100, gap: 12 }}
          columnWrapperStyle={{ gap: 12 }}
          renderItem={({ item }) => (
            <PersonCard
              person={item}
              cardWidth={cardWidth}
              photoSize={photoSize}
              onPhotoPress={() =>
                item.photoUrl
                  ? setLightbox({ uri: item.photoUrl, name: item.name, relationship: item.relationship, notes: item.notes })
                  : null
              }
            />
          )}
        />
      )}

      {/* FAB */}
      {canEdit ? (
        <Pressable
          testID="add-person-fab"
          onPress={() => router.push({ pathname: "/add-person", params: { weddingId: activeWeddingId ?? "" } })}
          style={({ pressed }) => ({
            position: "absolute",
            bottom: 28,
            right: 24,
            width: 56,
            height: 56,
            borderRadius: 28,
            backgroundColor: "#C9A84C",
            alignItems: "center",
            justifyContent: "center",
            shadowColor: "#2C1810",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.2,
            shadowRadius: 10,
            elevation: 6,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Plus size={24} color="#FFFFFF" />
        </Pressable>
      ) : null}

      {/* Photo lightbox */}
      <Modal
        visible={lightbox !== null}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setLightbox(null)}
      >
        <Pressable
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.92)",
            justifyContent: "center",
            alignItems: "center",
            padding: 24,
          }}
          onPress={() => setLightbox(null)}
        >
          {/* Close button */}
          <Pressable
            testID="lightbox-close"
            onPress={() => setLightbox(null)}
            style={{
              position: "absolute",
              top: 56,
              right: 20,
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={20} color="#FFFFFF" />
          </Pressable>

          {/* Photo */}
          {lightbox ? (
            <Pressable onPress={() => {}} style={{ width: "100%", alignItems: "center" }}>
              <Image
                source={{ uri: lightbox.uri }}
                style={{
                  width: width - 48,
                  height: width - 48,
                  borderRadius: 20,
                }}
                contentFit="cover"
              />
              <Text
                style={{
                  fontFamily: "PlayfairDisplay_700Bold",
                  fontSize: 24,
                  color: "#FFFFFF",
                  marginTop: 20,
                  textAlign: "center",
                }}
              >
                {lightbox.name}
              </Text>
              <Text
                style={{
                  fontFamily: "DMSans_400Regular",
                  fontSize: 15,
                  color: "rgba(255,255,255,0.65)",
                  marginTop: 4,
                  textAlign: "center",
                }}
              >
                {lightbox.relationship}
              </Text>
              {lightbox.notes ? (
                <Text
                  style={{
                    fontFamily: "DMSans_400Regular",
                    fontSize: 14,
                    color: "rgba(255,255,255,0.5)",
                    marginTop: 12,
                    textAlign: "center",
                    lineHeight: 20,
                    paddingHorizontal: 12,
                  }}
                >
                  {lightbox.notes}
                </Text>
              ) : null}
            </Pressable>
          ) : null}
        </Pressable>
      </Modal>
    </View>
  );
}

function PersonCard({
  person,
  cardWidth,
  photoSize,
  onPhotoPress,
}: {
  person: ImportantPersonDTO;
  cardWidth: number;
  photoSize: number;
  onPhotoPress: () => void;
}) {
  const initials = getInitials(person.name);
  const bgColor = avatarColor(person.name);
  const hasPhoto = !!person.photoUrl;

  return (
    <View
      testID={`person-card-${person.id}`}
      style={{
        width: cardWidth,
        backgroundColor: "#FFFFFF",
        borderRadius: 18,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: "#E8E0D5",
        shadowColor: "#2C1810",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.07,
        shadowRadius: 8,
        elevation: 2,
      }}
    >
      {/* Photo area — tappable */}
      <Pressable
        testID={`person-photo-${person.id}`}
        onPress={hasPhoto ? onPhotoPress : undefined}
        style={({ pressed }) => ({ opacity: pressed && hasPhoto ? 0.85 : 1 })}
      >
        {hasPhoto ? (
          <Image
            source={{ uri: person.photoUrl! }}
            style={{ width: cardWidth, height: photoSize }}
            contentFit="cover"
          />
        ) : (
          <View
            style={{
              width: cardWidth,
              height: photoSize,
              backgroundColor: bgColor,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text
              style={{
                fontFamily: "PlayfairDisplay_700Bold",
                fontSize: cardWidth * 0.28,
                color: "rgba(255,255,255,0.9)",
              }}
            >
              {initials}
            </Text>
          </View>
        )}
      </Pressable>

      {/* Info below photo */}
      <View style={{ padding: 12 }}>
        <Text
          style={{
            fontFamily: "DMSans_600SemiBold",
            fontSize: 14,
            color: "#2C1810",
            marginBottom: 2,
          }}
          numberOfLines={1}
        >
          {person.name}
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 12,
            color: "#8B7355",
            marginBottom: 6,
          }}
          numberOfLines={1}
        >
          {person.relationship}
        </Text>
        <View
          style={{
            backgroundColor: CATEGORY_COLORS[person.category],
            borderRadius: 100,
            paddingHorizontal: 8,
            paddingVertical: 3,
            alignSelf: "flex-start",
          }}
        >
          <Text
            style={{
              fontFamily: "DMSans_500Medium",
              fontSize: 10,
              color: CATEGORY_TEXT[person.category],
            }}
          >
            {PERSON_CATEGORY_LABELS[person.category]}
          </Text>
        </View>
        {person.notes ? (
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 11,
              color: "#8B7355",
              marginTop: 6,
              lineHeight: 15,
            }}
            numberOfLines={2}
          >
            {person.notes}
          </Text>
        ) : null}
      </View>
    </View>
  );
}
