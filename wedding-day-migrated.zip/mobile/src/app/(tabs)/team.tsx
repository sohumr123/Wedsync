import { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Linking,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  useWindowDimensions,
} from "react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Phone, Mail, Copy, Camera, X, MoreHorizontal, ShieldCheck, ShieldOff, Send } from "lucide-react-native";
import * as Clipboard from "expo-clipboard";
import * as ImagePicker from "expo-image-picker";
import { fetch as expoFetch } from "expo/fetch";
import { api } from "@/lib/api/api";
import type { WeddingDetailDTO, WeddingMemberDTO, UserProfileDTO, UserRole, VendorSpecialty } from "@/lib/types";
import { VENDOR_SPECIALTY_LABELS } from "@/lib/types";
import { QUERY_KEYS, getInitials } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

const ROLE_COLORS: Record<UserRole, string> = {
  admin: "#F5EDD8",
  couple: "#FCE8E8",
  vendor: "#E8F0F8",
};
const ROLE_TEXT: Record<UserRole, string> = {
  admin: "#C9A84C",
  couple: "#E8474B",
  vendor: "#3B82F6",
};
const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Coordinator",
  couple: "Couple",
  vendor: "Vendor",
};

const AVATAR_BG = ["#C9A84C", "#E8C4C4", "#8B7355", "#A8C5DA", "#B5A99A", "#D4A0A0", "#9BB5A0", "#C4B5D4"];
function avatarColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_BG[Math.abs(h) % AVATAR_BG.length];
}

type PhotoLightbox = { uri: string; name: string; role: string } | null;

function Avatar({ name, imageUrl, size }: { name: string; imageUrl: string | null; size: number }) {
  const bg = avatarColor(name);
  const initials = getInitials(name);
  if (imageUrl) {
    return (
      <Image
        source={{ uri: imageUrl }}
        style={{ width: size, height: size, borderRadius: size / 2 }}
        contentFit="cover"
      />
    );
  }
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: bg,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Text
        style={{
          fontFamily: "DMSans_600SemiBold",
          fontSize: size * 0.33,
          color: "#FFFFFF",
        }}
      >
        {initials}
      </Text>
    </View>
  );
}

function MemberCard({
  member,
  isMe,
  isViewerAdmin,
  onPhotoPress,
  onUpdatePhoto,
  updatingPhoto,
  onRoleAction,
}: {
  member: WeddingMemberDTO;
  isMe: boolean;
  isViewerAdmin: boolean;
  onPhotoPress: (uri: string, name: string, role: string) => void;
  onUpdatePhoto: () => void;
  updatingPhoto: boolean;
  onRoleAction?: (member: WeddingMemberDTO) => void;
}) {
  const name = member.user.displayName || member.user.name;
  const photoUrl = member.user.image;

  const handleCall = () => member.user.phone && Linking.openURL(`tel:${member.user.phone}`);
  const handleEmail = () => Linking.openURL(`mailto:${member.user.email}`);

  const roleLabel =
    member.role === "admin"
      ? (member.vendorSpecialty ? VENDOR_SPECIALTY_LABELS[member.vendorSpecialty] : "Coordinator")
      : member.vendorSpecialty
      ? VENDOR_SPECIALTY_LABELS[member.vendorSpecialty]
      : ROLE_LABELS[member.role];

  return (
    <View
      testID={`member-card-${member.id}`}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 16,
        marginBottom: 10,
        borderWidth: isMe ? 1.5 : 1,
        borderColor: isMe ? "#C9A84C" : "#E8E0D5",
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
      }}
    >
      {/* Avatar — tappable to see full photo */}
      <Pressable
        testID={`member-avatar-${member.id}`}
        onPress={() => photoUrl ? onPhotoPress(photoUrl, name, roleLabel) : undefined}
        style={({ pressed }) => ({ opacity: pressed && photoUrl ? 0.85 : 1, position: "relative" })}
      >
        <Avatar name={name} imageUrl={photoUrl} size={56} />
        {/* Camera badge for "me" */}
        {isMe ? (
          <Pressable
            testID="update-photo-badge"
            onPress={onUpdatePhoto}
            disabled={updatingPhoto}
            style={{
              position: "absolute",
              bottom: -2,
              right: -2,
              width: 22,
              height: 22,
              borderRadius: 11,
              backgroundColor: "#C9A84C",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1.5,
              borderColor: "#FFFFFF",
            }}
          >
            {updatingPhoto ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Camera size={11} color="#FFFFFF" />
            )}
          </Pressable>
        ) : null}
      </Pressable>

      {/* Info */}
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#2C1810" }}>
            {name}
          </Text>
          {isMe ? (
            <View style={{ backgroundColor: "#F5EDD8", borderRadius: 100, paddingHorizontal: 8, paddingVertical: 2 }}>
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 10, color: "#C9A84C" }}>You</Text>
            </View>
          ) : null}
          <View
            style={{
              backgroundColor: ROLE_COLORS[member.role],
              borderRadius: 100,
              paddingHorizontal: 8,
              paddingVertical: 2,
            }}
          >
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 10, color: ROLE_TEXT[member.role] }}>
              {ROLE_LABELS[member.role]}
            </Text>
          </View>
        </View>
        <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginTop: 1 }}>
          {roleLabel}
        </Text>
        {member.user.company ? (
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
            {member.user.company}
          </Text>
        ) : null}
        {isMe && !photoUrl ? (
          <Pressable testID="add-photo-link" onPress={onUpdatePhoto} style={{ marginTop: 4 }}>
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 12, color: "#C9A84C" }}>
              + Add your photo
            </Text>
          </Pressable>
        ) : null}
      </View>

      {/* Contact buttons */}
      <View style={{ gap: 10, alignItems: "center" }}>
        {member.user.phone ? (
          <Pressable testID={`call-${member.id}`} onPress={handleCall}>
            <Phone size={18} color="#C9A84C" />
          </Pressable>
        ) : null}
        <Pressable testID={`email-${member.id}`} onPress={handleEmail}>
          <Mail size={18} color="#8B7355" />
        </Pressable>
        {isViewerAdmin && !isMe && onRoleAction ? (
          <Pressable testID={`role-action-${member.id}`} onPress={() => onRoleAction(member)} hitSlop={8}>
            <MoreHorizontal size={18} color="#C8B8A2" />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

export default function TeamScreen() {
  const { width } = useWindowDimensions();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const queryClient = useQueryClient();
  const [lightbox, setLightbox] = useState<PhotoLightbox>(null);
  const [showEmailInvite, setShowEmailInvite] = useState<boolean>(false);
  const [inviteEmail, setInviteEmail] = useState<string>("");

  const { data: wedding, isLoading } = useQuery({
    queryKey: QUERY_KEYS.wedding(activeWeddingId ?? ""),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${activeWeddingId}`),
    enabled: !!activeWeddingId,
  });

  const { data: me } = useQuery({
    queryKey: QUERY_KEYS.me,
    queryFn: () => api.get<UserProfileDTO>("/api/me"),
  });

  const uploadPhotoMutation = useMutation({
    mutationFn: async () => {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      if (result.canceled) return null;

      const asset = result.assets[0];
      const formData = new FormData();
      formData.append("file", { uri: asset.uri, type: "image/jpeg", name: "photo.jpg" } as unknown as Blob);

      const uploadRes = await expoFetch(
        `${process.env.EXPO_PUBLIC_BACKEND_URL}/api/upload`,
        { method: "POST", body: formData, credentials: "include" }
      );
      const uploadJson = await uploadRes.json() as { data: { url: string } };
      const url = uploadJson.data.url;

      await api.patch<UserProfileDTO>("/api/me", { image: url });
      return url;
    },
    onSuccess: (url) => {
      if (!url) return;
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.me });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(activeWeddingId ?? "") });
      toast({ title: "Photo updated!", preset: "done" });
    },
    onError: () => {
      toast({ title: "Upload failed", preset: "error" });
    },
  });

  const handleCopyCode = async () => {
    if (wedding?.inviteCode) {
      await Clipboard.setStringAsync(wedding.inviteCode);
      toast({ title: "Invite code copied!", preset: "done" });
    }
  };

  const handleSendEmailInvite = () => {
    if (!wedding || !inviteEmail.trim()) return;
    const subject = encodeURIComponent(
      `You're invited to join ${wedding.partner1Name} & ${wedding.partner2Name}'s wedding!`
    );
    const body = encodeURIComponent(
      `Hi!\n\nYou've been invited to join the wedding coordination team for ${wedding.partner1Name} & ${wedding.partner2Name}.\n\nTo join, download the Wedding Day app and use this invite code:\n\n${wedding.inviteCode}\n\nSee you there!`
    );
    Linking.openURL(`mailto:${inviteEmail.trim()}?subject=${subject}&body=${body}`);
    setShowEmailInvite(false);
    setInviteEmail("");
  };

  const isAdmin = wedding?.myRole === "admin";
  const members = wedding?.members ?? [];
  const admins = members.filter((m) => m.role === "admin");
  const couples = members.filter((m) => m.role === "couple");
  const vendors = members.filter((m) => m.role === "vendor");

  const [roleTarget, setRoleTarget] = useState<WeddingMemberDTO | null>(null);

  const changeRoleMutation = useMutation({
    mutationFn: ({ memberId, role }: { memberId: string; role: "admin" | "vendor" | "couple" }) =>
      api.patch<WeddingMemberDTO>(`/api/weddings/${activeWeddingId}/members/${memberId}`, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(activeWeddingId ?? "") });
      toast({ title: "Role updated", preset: "done" });
      setRoleTarget(null);
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
      setRoleTarget(null);
    },
  });

  const vendorsBySpecialty = vendors.reduce<Record<string, WeddingMemberDTO[]>>((acc, m) => {
    const key = m.vendorSpecialty ?? "other";
    if (!acc[key]) acc[key] = [];
    acc[key].push(m);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="team-screen">
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>

        {/* Invite code (admin only) */}
        {isAdmin && wedding?.inviteCode ? (
          <View
            style={{
              backgroundColor: "#FDF8EE",
              borderRadius: 14,
              padding: 16,
              marginBottom: 24,
              borderWidth: 1,
              borderColor: "#E8D5A0",
            }}
          >
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 11, color: "#8B7355", letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>
              Invite Code
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 26, color: "#C9A84C", letterSpacing: 4 }}>
                {wedding.inviteCode}
              </Text>
              <Pressable testID="copy-invite-code" onPress={handleCopyCode}>
                <Copy size={20} color="#8B7355" />
              </Pressable>
            </View>
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355", marginTop: 6, marginBottom: 12 }}>
              Share with vendors and the couple to join
            </Text>
            <Pressable
              testID="invite-via-email-button"
              onPress={() => setShowEmailInvite(true)}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                backgroundColor: "#C9A84C",
                borderRadius: 10,
                paddingVertical: 10,
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Send size={15} color="#FFFFFF" />
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 13, color: "#FFFFFF" }}>
                Invite via Email
              </Text>
            </Pressable>
          </View>
        ) : null}

        {/* Admins & Couple */}
        {admins.length > 0 || couples.length > 0 ? (
          <>
            <SectionHeader title="Coordinators & Couple" />
            {[...admins, ...couples].map((m) => (
              <MemberCard
                key={m.id}
                member={m}
                isMe={m.userId === me?.id}
                isViewerAdmin={isAdmin}
                onPhotoPress={(uri, name, role) => setLightbox({ uri, name, role })}
                onUpdatePhoto={() => uploadPhotoMutation.mutate()}
                updatingPhoto={uploadPhotoMutation.isPending}
                onRoleAction={isAdmin && m.userId !== me?.id ? setRoleTarget : undefined}
              />
            ))}
          </>
        ) : null}

        {/* Vendors by specialty */}
        {Object.entries(vendorsBySpecialty).map(([specialty, mems]) => (
          <View key={specialty}>
            <SectionHeader
              title={
                specialty in VENDOR_SPECIALTY_LABELS
                  ? VENDOR_SPECIALTY_LABELS[specialty as VendorSpecialty] + "s"
                  : "Vendors"
              }
            />
            {mems.map((m) => (
              <MemberCard
                key={m.id}
                member={m}
                isMe={m.userId === me?.id}
                isViewerAdmin={isAdmin}
                onPhotoPress={(uri, name, role) => setLightbox({ uri, name, role })}
                onUpdatePhoto={() => uploadPhotoMutation.mutate()}
                updatingPhoto={uploadPhotoMutation.isPending}
                onRoleAction={isAdmin && m.userId !== me?.id ? setRoleTarget : undefined}
              />
            ))}
          </View>
        ))}

        {members.length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: 48 }}>
            <Text style={{ fontFamily: "PlayfairDisplay_400Regular", fontSize: 18, color: "#8B7355", marginTop: 12, textAlign: "center" }}>
              No team members yet
            </Text>
            {isAdmin ? (
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginTop: 6, textAlign: "center" }}>
                Share the invite code above to grow your team
              </Text>
            ) : null}
          </View>
        ) : null}
      </ScrollView>

      {/* Email invite modal */}
      <Modal visible={showEmailInvite} transparent animationType="slide" onRequestClose={() => setShowEmailInvite(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
          <Pressable
            style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
            onPress={() => setShowEmailInvite(false)}
          >
            <Pressable
              style={{ backgroundColor: "#FFFFFF", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 28, paddingBottom: 40 }}
              onPress={() => {}}
            >
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810" }}>
                  Invite via Email
                </Text>
                <Pressable onPress={() => setShowEmailInvite(false)} hitSlop={8}>
                  <X size={20} color="#8B7355" />
                </Pressable>
              </View>
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 14, color: "#8B7355", marginBottom: 16, lineHeight: 20 }}>
                Enter their email address and we'll open your mail app with a pre-filled invitation containing the invite code.
              </Text>
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 11, color: "#8B7355", letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>
                Email Address
              </Text>
              <TextInput
                testID="invite-email-input"
                value={inviteEmail}
                onChangeText={setInviteEmail}
                placeholder="vendor@example.com"
                placeholderTextColor="#C8B8A2"
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                style={{
                  fontFamily: "DMSans_400Regular",
                  fontSize: 16,
                  color: "#2C1810",
                  borderWidth: 1.5,
                  borderColor: "#E8E0D5",
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  marginBottom: 16,
                }}
              />
              <Pressable
                testID="send-email-invite-button"
                onPress={handleSendEmailInvite}
                disabled={!inviteEmail.trim()}
                style={({ pressed }) => ({
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                  backgroundColor: inviteEmail.trim() ? "#C9A84C" : "#D4C090",
                  borderRadius: 14,
                  paddingVertical: 15,
                  opacity: pressed ? 0.85 : 1,
                })}
              >
                <Send size={16} color="#FFFFFF" />
                <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                  Open Mail App
                </Text>
              </Pressable>
            </Pressable>
          </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      {/* Role action modal */}
      <Modal visible={roleTarget !== null} transparent animationType="fade" onRequestClose={() => setRoleTarget(null)}>
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 }}
          onPress={() => setRoleTarget(null)}
        >
          <Pressable style={{ backgroundColor: "#FFFFFF", borderRadius: 20, padding: 24, width: "100%", maxWidth: 340 }} onPress={() => {}}>
            <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 20, color: "#2C1810", marginBottom: 4 }}>
              {roleTarget?.user.displayName || roleTarget?.user.name}
            </Text>
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginBottom: 20 }}>
              Current role: {roleTarget ? ROLE_LABELS[roleTarget.role] : ""}
            </Text>

            {roleTarget?.role !== "admin" ? (
              <Pressable
                testID="make-admin-button"
                onPress={() => roleTarget && changeRoleMutation.mutate({ memberId: roleTarget.id, role: "admin" })}
                disabled={changeRoleMutation.isPending}
                style={({ pressed }) => ({
                  flexDirection: "row", alignItems: "center", gap: 12,
                  backgroundColor: "#FDF8EE", borderRadius: 12, padding: 14, marginBottom: 10,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <ShieldCheck size={20} color="#C9A84C" />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#2C1810" }}>Make Admin</Text>
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>Can manage events and approve changes</Text>
                </View>
              </Pressable>
            ) : null}

            {roleTarget?.role === "admin" ? (
              <Pressable
                testID="remove-admin-button"
                onPress={() => roleTarget && changeRoleMutation.mutate({ memberId: roleTarget.id, role: roleTarget.vendorSpecialty ? "vendor" : "couple" })}
                disabled={changeRoleMutation.isPending}
                style={({ pressed }) => ({
                  flexDirection: "row", alignItems: "center", gap: 12,
                  backgroundColor: "#FEF2F2", borderRadius: 12, padding: 14, marginBottom: 10,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <ShieldOff size={20} color="#EF4444" />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#2C1810" }}>Remove Admin</Text>
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>Revert to {roleTarget.vendorSpecialty ? "vendor" : "couple"} role</Text>
                </View>
              </Pressable>
            ) : null}

            <Pressable onPress={() => setRoleTarget(null)} style={({ pressed }) => ({ paddingVertical: 12, alignItems: "center", opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 14, color: "#8B7355" }}>Cancel</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Photo lightbox */}
      <Modal
        visible={lightbox !== null}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setLightbox(null)}
      >
        <Pressable
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.92)",
            justifyContent: "center",
            alignItems: "center",
            padding: 24,
          }}
          onPress={() => setLightbox(null)}
        >
          <Pressable
            testID="lightbox-close"
            onPress={() => setLightbox(null)}
            style={{
              position: "absolute",
              top: 56,
              right: 20,
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.15)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={20} color="#FFFFFF" />
          </Pressable>

          {lightbox ? (
            <Pressable onPress={() => {}} style={{ alignItems: "center" }}>
              <Image
                source={{ uri: lightbox.uri }}
                style={{ width: width - 64, height: width - 64, borderRadius: width / 2 - 32 }}
                contentFit="cover"
              />
              <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 26, color: "#FFFFFF", marginTop: 24, textAlign: "center" }}>
                {lightbox.name}
              </Text>
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "rgba(255,255,255,0.6)", marginTop: 4, textAlign: "center" }}>
                {lightbox.role}
              </Text>
            </Pressable>
          ) : null}
        </Pressable>
      </Modal>
    </View>
  );
}

function SectionHeader({ title }: { title: string }) {
  return (
    <Text
      style={{
        fontFamily: "DMSans_500Medium",
        fontSize: 11,
        color: "#8B7355",
        letterSpacing: 1,
        textTransform: "uppercase",
        marginBottom: 10,
        marginTop: 4,
      }}
    >
      {title}
    </Text>
  );
}
