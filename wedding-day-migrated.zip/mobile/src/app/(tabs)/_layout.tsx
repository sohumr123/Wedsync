import { Tabs } from "expo-router";
import { Clock, Users, Heart, Menu, CalendarDays } from "lucide-react-native";

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarStyle: { backgroundColor: "#FFFFFF", borderTopColor: "#E8E0D5", borderTopWidth: 1 },
        tabBarActiveTintColor: "#C9A84C",
        tabBarInactiveTintColor: "#8B7355",
        tabBarLabelStyle: { fontFamily: "DMSans_500Medium", fontSize: 11 },
        headerStyle: { backgroundColor: "#FAF7F2" },
        headerTitleStyle: { fontFamily: "PlayfairDisplay_700Bold", color: "#2C1810" },
        headerTintColor: "#C9A84C",
      }}
    >
      <Tabs.Screen
        name="timeline"
        options={{
          title: "Timeline",
          tabBarIcon: ({ color }) => <Clock size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="team"
        options={{
          title: "Team",
          tabBarIcon: ({ color }) => <Users size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="people"
        options={{
          title: "People",
          tabBarIcon: ({ color }) => <Heart size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="weddings"
        options={{
          title: "Weddings",
          tabBarIcon: ({ color }) => <CalendarDays size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="more"
        options={{
          title: "More",
          tabBarIcon: ({ color }) => <Menu size={22} color={color} />,
        }}
      />
    </Tabs>
  );
}
