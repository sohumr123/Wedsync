import { useRef, useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Animated,
  Modal,
} from "react-native";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "burnt";
import {
  Clock,
  MapPin,
  Plus,
  Zap,
  Users,
  Sparkles,
  Heart,
  Gem,
  Wine,
  Music,
  Star,
  Car,
  Calendar,
  Sun,
  Cloud,
  CloudSun,
  CloudRain,
  CloudSnow,
  CloudDrizzle,
  CloudLightning,
  Droplets,
  CheckCircle,
} from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { WeddingDetailDTO, TimelineEventDTO, EventCategory } from "@/lib/types";
import { EVENT_CATEGORY_LABELS } from "@/lib/types";
import { QUERY_KEYS, formatTime, formatDate, isEventNow, isEventPast } from "@/lib/utils";
import { useTimelineWeather, useSunsetTime, type WeatherData } from "@/lib/weather";
import useWeddingStore from "@/lib/state/wedding-store";

// Map iconName string → lucide component
const WEATHER_ICONS: Record<string, React.ComponentType<{ size: number; color: string }>> = {
  Sun,
  Cloud,
  CloudSun,
  CloudRain,
  CloudSnow,
  CloudDrizzle,
  CloudLightning,
};

function WeatherBadge({ weather }: { weather: WeatherData }) {
  const IconComp = WEATHER_ICONS[weather.iconName] ?? Cloud;
  const isRainy = weather.precipitationProbability >= 20;
  const iconColor = weather.iconName === "Sun" || weather.iconName === "CloudSun"
    ? "#C9A84C"
    : weather.iconName === "CloudRain" || weather.iconName === "CloudDrizzle" || weather.iconName === "CloudLightning"
    ? "#3B82F6"
    : weather.iconName === "CloudSnow"
    ? "#93C5FD"
    : "#8B7355";

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 4,
        backgroundColor: "#F5F0E8",
        borderRadius: 100,
        paddingHorizontal: 8,
        paddingVertical: 3,
        alignSelf: "flex-start",
        marginTop: 6,
      }}
    >
      <IconComp size={12} color={iconColor} />
      <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 11, color: "#2C1810" }}>
        {weather.temperatureF}°F
      </Text>
      <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 11, color: "#8B7355" }}>
        {weather.description}
      </Text>
      {isRainy ? (
        <>
          <Droplets size={10} color="#3B82F6" />
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 11, color: "#3B82F6" }}>
            {weather.precipitationProbability}%
          </Text>
        </>
      ) : null}
    </View>
  );
}

function CategoryIcon({ category, size, color }: { category: EventCategory; size: number; color: string }) {
  const icons: Record<EventCategory, React.ReactNode> = {
    gettingReady: <Sparkles size={size} color={color} />,
    firstLook: <Heart size={size} color={color} />,
    ceremony: <Gem size={size} color={color} />,
    cocktail: <Wine size={size} color={color} />,
    reception: <Music size={size} color={color} />,
    sendOff: <Star size={size} color={color} />,
    travel: <Car size={size} color={color} />,
    other: <Calendar size={size} color={color} />,
  };
  return <>{icons[category]}</>;
}

function PulsingDot() {
  const scale = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scale, { toValue: 1.4, duration: 700, useNativeDriver: true }),
        Animated.timing(scale, { toValue: 1, duration: 700, useNativeDriver: true }),
      ])
    ).start();
  }, [scale]);
  return (
    <Animated.View
      style={{
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: "#C9A84C",
        transform: [{ scale }],
      }}
    />
  );
}

export default function TimelineScreen() {
  const router = useRouter();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const queryClient = useQueryClient();

  const [backOnTrackEvent, setBackOnTrackEvent] = useState<TimelineEventDTO | null>(null);
  const [markDoneEvent, setMarkDoneEvent] = useState<TimelineEventDTO | null>(null);
  const [markDoneResult, setMarkDoneResult] = useState<{
    completedAt: string;
    delayMinutes: number;
    bufferMinutes: number;
    adjustedCount: number;
    nextEvent: TimelineEventDTO | null;
    suggestedNextStartTime: string | null;
  } | null>(null);

  const markDoneMutation = useMutation({
    mutationFn: (eventId: string) =>
      api.post<{
        completedAt: string;
        delayMinutes: number;
        bufferMinutes: number;
        adjustedCount: number;
        nextEvent: TimelineEventDTO | null;
        suggestedNextStartTime: string | null;
      }>(`/api/weddings/${activeWeddingId}/events/${eventId}/complete`, {}),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(activeWeddingId ?? "") });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.events(activeWeddingId ?? "") });
      setMarkDoneResult(result);
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
      setMarkDoneEvent(null);
    },
  });

  const backOnTrackMutation = useMutation({
    mutationFn: (eventId: string) =>
      api.post<{ updatedCount: number }>(`/api/weddings/${activeWeddingId}/events/${eventId}/back-on-track`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(activeWeddingId ?? "") });
      toast({ title: "Schedule reset to original times", preset: "done" });
      setBackOnTrackEvent(null);
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
      setBackOnTrackEvent(null);
    },
  });

  const { data: wedding, isLoading } = useQuery({
    queryKey: QUERY_KEYS.wedding(activeWeddingId ?? ""),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${activeWeddingId}`),
    enabled: !!activeWeddingId,
    refetchInterval: 30000,
  });

  const events = wedding?.events ?? [];
  const sortedEvents = [...events].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
  );

  const { weatherMap } = useTimelineWeather(sortedEvents);
  const { sunsetTime } = useSunsetTime(wedding?.weddingDate ?? null);

  const nowEvent = sortedEvents.find(isEventNow);
  const upNextEvents = sortedEvents.filter(
    (e) => !isEventPast(e) && !isEventNow(e)
  ).slice(0, 2);

  const openEvent = (eventId: string) =>
    router.push({
      pathname: "/quick-adjust",
      params: { eventId, weddingId: activeWeddingId ?? "" },
    });

  const isAdmin = wedding?.myRole === "admin";
  const pendingCount = wedding?.pendingChangeRequests?.length ?? 0;

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="timeline-screen">
      <ScrollView
        contentContainerStyle={{ paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Admin banner */}
        {isAdmin && pendingCount > 0 ? (
          <Pressable
            testID="approvals-banner"
            onPress={() => router.push("/approvals")}
            style={{
              backgroundColor: "#FDF8EE",
              borderBottomWidth: 1,
              borderBottomColor: "#E8D5A0",
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 12,
              gap: 8,
            }}
          >
            <Zap size={16} color="#C9A84C" />
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#2C1810", flex: 1 }}>
              {pendingCount} pending adjustment {pendingCount === 1 ? "request" : "requests"}
            </Text>
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#C9A84C" }}>
              Review →
            </Text>
          </Pressable>
        ) : null}

        {/* Wedding header */}
        <View style={{ paddingHorizontal: 24, paddingTop: 28, paddingBottom: 20 }}>
          {wedding ? (
            <>
              <Text
                style={{
                  fontFamily: "PlayfairDisplay_700Bold",
                  fontSize: 30,
                  color: "#2C1810",
                  lineHeight: 36,
                }}
              >
                {wedding.partner1Name} & {wedding.partner2Name}
              </Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}>
                <Clock size={13} color="#8B7355" />
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                  {formatDate(wedding.weddingDate)}
                </Text>
              </View>
              {wedding.venueName ? (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 }}>
                  <MapPin size={13} color="#8B7355" />
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                    {wedding.venueName}
                  </Text>
                </View>
              ) : null}
            </>
          ) : null}
        </View>

        {/* NOW card */}
        {nowEvent ? (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <Pressable
              testID={`now-event-${nowEvent.id}`}
              onPress={() => openEvent(nowEvent.id)}
              style={({ pressed }) => ({
                backgroundColor: "#FFFFFF",
                borderRadius: 18,
                borderWidth: 2,
                borderColor: "#C9A84C",
                padding: 18,
                shadowColor: "#C9A84C",
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.15,
                shadowRadius: 12,
                elevation: 4,
                opacity: pressed ? 0.9 : 1,
              })}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <PulsingDot />
                <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 11, color: "#C9A84C", letterSpacing: 1.5 }}>
                  LIVE NOW
                </Text>
              </View>
              <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810", marginBottom: 6 }}>
                {nowEvent.title}
              </Text>
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                {formatTime(nowEvent.startTime)} – {formatTime(nowEvent.endTime)}
              </Text>
              {nowEvent.locationName ? (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                  <MapPin size={12} color="#8B7355" />
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
                    {nowEvent.locationName}
                  </Text>
                </View>
              ) : null}
              {weatherMap[nowEvent.id] ? (
                <WeatherBadge weather={weatherMap[nowEvent.id]} />
              ) : null}
            </Pressable>
          </View>
        ) : null}

        {/* Up next */}
        {upNextEvents.length > 0 ? (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1.2,
                textTransform: "uppercase",
                marginBottom: 10,
              }}
            >
              Up Next
            </Text>
            {upNextEvents.map((event) => (
              <Pressable
                testID={`upcoming-event-${event.id}`}
                key={event.id}
                onPress={() => openEvent(event.id)}
                style={({ pressed }) => ({
                  backgroundColor: "#FFFFFF",
                  borderRadius: 14,
                  borderWidth: 1,
                  borderColor: "#E8E0D5",
                  padding: 14,
                  marginBottom: 8,
                  opacity: pressed ? 0.85 : 1,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 12,
                })}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    backgroundColor: "#FDF8EE",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <CategoryIcon category={event.category} size={16} color="#C9A84C" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#2C1810" }}>
                    {event.title}
                  </Text>
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
                    {formatTime(event.startTime)}
                  </Text>
                </View>
              </Pressable>
            ))}
          </View>
        ) : null}

        {/* Full timeline */}
        <View style={{ paddingHorizontal: 20 }}>
          <Text
            style={{
              fontFamily: "DMSans_500Medium",
              fontSize: 11,
              color: "#8B7355",
              letterSpacing: 1.2,
              textTransform: "uppercase",
              marginBottom: 14,
            }}
          >
            Full Timeline
          </Text>
          {(() => {
            type Item =
              | { type: "event"; event: TimelineEventDTO; index: number }
              | { type: "sunset"; time: Date };

            const items: Item[] = sortedEvents.map((event, index) => ({
              type: "event",
              event,
              index,
            }));

            if (sunsetTime) {
              const sunsetMs = sunsetTime.getTime();
              const insertAt = items.findIndex(
                (item) =>
                  item.type === "event" &&
                  new Date(item.event.startTime).getTime() > sunsetMs
              );
              const pos = insertAt === -1 ? items.length : insertAt;
              items.splice(pos, 0, { type: "sunset", time: sunsetTime });
            }

            return items.map((item, i) => {
              if (item.type === "sunset") {
                return <SunsetMarker key="sunset" time={item.time} />;
              }
              return (
                <TimelineRow
                  key={item.event.id}
                  event={item.event}
                  isLast={item.index === sortedEvents.length - 1}
                  onPress={() => openEvent(item.event.id)}
                  weather={weatherMap[item.event.id]}
                  onLongPress={isAdmin ? () => setBackOnTrackEvent(item.event) : undefined}
                  onMarkDone={isAdmin && !item.event.completedAt ? () => setMarkDoneEvent(item.event) : undefined}
                />
              );
            });
          })()}
          {sortedEvents.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 48 }}>
              <Clock size={40} color="#E8E0D5" />
              <Text
                style={{
                  fontFamily: "PlayfairDisplay_400Regular",
                  fontSize: 18,
                  color: "#8B7355",
                  marginTop: 12,
                  textAlign: "center",
                }}
              >
                No events yet
              </Text>
              {isAdmin ? (
                <Text
                  style={{
                    fontFamily: "DMSans_400Regular",
                    fontSize: 13,
                    color: "#8B7355",
                    marginTop: 6,
                    textAlign: "center",
                  }}
                >
                  Tap + to add the first event
                </Text>
              ) : null}
            </View>
          ) : null}
        </View>
      </ScrollView>

      {/* Mark Done confirmation modal */}
      <Modal visible={markDoneEvent !== null && markDoneResult === null} transparent animationType="fade">
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 }}
          onPress={() => setMarkDoneEvent(null)}
        >
          <Pressable
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              padding: 28,
              width: "100%",
              maxWidth: 340,
            }}
            onPress={() => {}}
          >
            <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810", marginBottom: 10 }}>
              Mark as Done?
            </Text>
            {markDoneEvent ? (
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "#8B7355", marginBottom: 24, lineHeight: 22 }}>
                This will mark "{markDoneEvent.title}" as complete and adjust the rest of the schedule.
              </Text>
            ) : null}
            <Pressable
              testID="confirm-mark-done"
              onPress={() => markDoneEvent && markDoneMutation.mutate(markDoneEvent.id)}
              disabled={markDoneMutation.isPending}
              style={({ pressed }) => ({
                backgroundColor: "#C9A84C",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                marginBottom: 10,
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                {markDoneMutation.isPending ? "Marking…" : "Mark Done"}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setMarkDoneEvent(null)}
              style={({ pressed }) => ({
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                borderWidth: 1,
                borderColor: "#E8E0D5",
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 15, color: "#8B7355" }}>Cancel</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Mark Done results modal */}
      <Modal visible={markDoneResult !== null} transparent animationType="fade">
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 }}
          onPress={() => { setMarkDoneEvent(null); setMarkDoneResult(null); }}
        >
          <Pressable
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              padding: 28,
              width: "100%",
              maxWidth: 340,
            }}
            onPress={() => {}}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <CheckCircle size={22} color="#16A34A" />
              <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810" }}>
                Event Marked Done
              </Text>
            </View>
            {markDoneResult ? (
              <>
                <View
                  style={{
                    backgroundColor: markDoneResult.delayMinutes > 0 ? "#FFFBEB" : "#F0FDF4",
                    borderRadius: 12,
                    padding: 14,
                    marginBottom: 16,
                  }}
                >
                  {markDoneResult.delayMinutes > 0 ? (
                    <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#D97706" }}>
                      Running {markDoneResult.delayMinutes} min late
                    </Text>
                  ) : (
                    <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#16A34A" }}>
                      Right on time!
                    </Text>
                  )}
                </View>
                {markDoneResult.nextEvent ? (
                  <View style={{ marginBottom: 16, gap: 4 }}>
                    <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#8B7355" }}>
                      Next up
                    </Text>
                    <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#2C1810" }}>
                      {markDoneResult.nextEvent.title}
                    </Text>
                    {markDoneResult.suggestedNextStartTime ? (
                      <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                        Suggested start: {formatTime(markDoneResult.suggestedNextStartTime)}
                      </Text>
                    ) : null}
                  </View>
                ) : null}
                {markDoneResult.adjustedCount > 0 ? (
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginBottom: 16 }}>
                    Adjusted {markDoneResult.adjustedCount} upcoming event{markDoneResult.adjustedCount === 1 ? "" : "s"}
                  </Text>
                ) : null}
              </>
            ) : null}
            <Pressable
              testID="mark-done-dismiss"
              onPress={() => { setMarkDoneEvent(null); setMarkDoneResult(null); }}
              style={({ pressed }) => ({
                backgroundColor: "#C9A84C",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>Done</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Back on Track confirmation modal */}
      <Modal visible={backOnTrackEvent !== null} transparent animationType="fade">
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 }}
          onPress={() => setBackOnTrackEvent(null)}
        >
          <Pressable
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              padding: 28,
              width: "100%",
              maxWidth: 340,
            }}
            onPress={() => {}}
          >
            <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810", marginBottom: 10 }}>
              Back on Track from here?
            </Text>
            {backOnTrackEvent ? (
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "#8B7355", marginBottom: 24, lineHeight: 22 }}>
                This will reset "{backOnTrackEvent.title}" and all following events to their original scheduled times.
              </Text>
            ) : null}
            <Pressable
              testID="confirm-back-on-track"
              onPress={() => backOnTrackEvent && backOnTrackMutation.mutate(backOnTrackEvent.id)}
              disabled={backOnTrackMutation.isPending}
              style={({ pressed }) => ({
                backgroundColor: "#C9A84C",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                marginBottom: 10,
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                {backOnTrackMutation.isPending ? "Resetting…" : "Reset Schedule"}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setBackOnTrackEvent(null)}
              style={({ pressed }) => ({
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 15, color: "#8B7355" }}>Cancel</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Admin FAB */}
      {isAdmin ? (
        <Pressable
          testID="add-event-fab"
          onPress={() =>
            router.push({
              pathname: "/add-event",
              params: { weddingId: activeWeddingId ?? "" },
            })
          }
          style={({ pressed }) => ({
            position: "absolute",
            bottom: 28,
            right: 24,
            width: 56,
            height: 56,
            borderRadius: 28,
            backgroundColor: "#C9A84C",
            alignItems: "center",
            justifyContent: "center",
            shadowColor: "#2C1810",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.2,
            shadowRadius: 10,
            elevation: 6,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Plus size={24} color="#FFFFFF" />
        </Pressable>
      ) : null}
    </View>
  );
}

function SunsetMarker({ time }: { time: Date }) {
  const label = time.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  return (
    <View style={{ flexDirection: "row", gap: 14, marginBottom: 4 }}>
      {/* Time column */}
      <View style={{ width: 56, alignItems: "flex-end" }}>
        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 12, color: "#C9A84C", marginTop: 10 }}>
          {label}
        </Text>
      </View>
      {/* Connector */}
      <View style={{ alignItems: "center", width: 20 }}>
        <View
          style={{
            width: 10,
            height: 10,
            borderRadius: 5,
            backgroundColor: "#F5D76E",
            marginTop: 12,
            zIndex: 1,
          }}
        />
        <View style={{ width: 1.5, flex: 1, backgroundColor: "#E8E0D5", marginTop: 2, minHeight: 16 }} />
      </View>
      {/* Label */}
      <View
        style={{
          flex: 1,
          flexDirection: "row",
          alignItems: "center",
          gap: 6,
          paddingVertical: 10,
          marginBottom: 4,
        }}
      >
        <Sun size={13} color="#C9A84C" />
        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#C9A84C" }}>
          Sunset
        </Text>
      </View>
    </View>
  );
}

function TimelineRow({
  event,
  isLast,
  onPress,
  weather,
  onLongPress,
  onMarkDone,
}: {
  event: TimelineEventDTO;
  isLast: boolean;
  onPress: () => void;
  weather?: WeatherData;
  onLongPress?: () => void;
  onMarkDone?: () => void;
}) {
  const isNow = isEventNow(event);
  const isPast = isEventPast(event);
  const isCompleted = !!event.completedAt;

  return (
    <View style={{ flexDirection: "row", gap: 14 }}>
      {/* Time column */}
      <View style={{ width: 56, alignItems: "flex-end" }}>
        <Text
          style={{
            fontFamily: "DMSans_500Medium",
            fontSize: 12,
            color: isPast ? "#C8B8A2" : isNow ? "#C9A84C" : "#8B7355",
            marginTop: 14,
          }}
        >
          {formatTime(event.startTime)}
        </Text>
      </View>

      {/* Connector line + dot */}
      <View style={{ alignItems: "center", width: 20 }}>
        <View
          style={{
            width: isNow ? 14 : 10,
            height: isNow ? 14 : 10,
            borderRadius: isNow ? 7 : 5,
            backgroundColor: isCompleted ? "#22C55E" : isPast ? "#E8E0D5" : isNow ? "#C9A84C" : "#D4B870",
            marginTop: 16,
            zIndex: 1,
          }}
        />
        {!isLast ? (
          <View
            style={{
              width: 1.5,
              flex: 1,
              backgroundColor: "#E8E0D5",
              marginTop: 2,
              minHeight: 24,
            }}
          />
        ) : null}
      </View>

      {/* Card */}
      <Pressable
        testID={`timeline-event-${event.id}`}
        onPress={onPress}
        onLongPress={onLongPress}
        style={({ pressed }) => ({
          flex: 1,
          backgroundColor: isCompleted ? "#F0FBF4" : "#FFFFFF",
          borderRadius: 14,
          borderWidth: isNow ? 2 : 1,
          borderColor: isCompleted ? "#86EFAC" : isNow ? "#C9A84C" : "#E8E0D5",
          padding: 14,
          marginBottom: 10,
          opacity: pressed ? 0.85 : isCompleted ? 0.75 : isPast ? 0.6 : 1,
          shadowColor: "#2C1810",
          shadowOffset: { width: 0, height: isNow ? 4 : 1 },
          shadowOpacity: isNow ? 0.1 : 0.04,
          shadowRadius: isNow ? 10 : 4,
          elevation: isNow ? 3 : 1,
        })}
      >
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
          <View style={{ flex: 1, gap: 2 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 2 }}>
              <CategoryIcon
                category={event.category}
                size={13}
                color={isPast ? "#C8B8A2" : "#8B7355"}
              />
              <Text
                style={{
                  fontFamily: "DMSans_400Regular",
                  fontSize: 11,
                  color: isPast ? "#C8B8A2" : "#8B7355",
                  letterSpacing: 0.5,
                }}
              >
                {EVENT_CATEGORY_LABELS[event.category]}
              </Text>
              {isCompleted ? (
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 3,
                    backgroundColor: "#DCFCE7",
                    borderRadius: 100,
                    paddingHorizontal: 6,
                    paddingVertical: 2,
                  }}
                >
                  <CheckCircle size={10} color="#16A34A" />
                  <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 10, color: "#16A34A" }}>
                    Done
                  </Text>
                </View>
              ) : null}
            </View>
            <Text
              style={{
                fontFamily: "DMSans_600SemiBold",
                fontSize: 15,
                color: isPast ? "#8B7355" : "#2C1810",
              }}
            >
              {event.title}
            </Text>
            {event.locationName ? (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
                <MapPin size={11} color="#C8B8A2" />
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#C8B8A2" }}>
                  {event.locationName}
                </Text>
              </View>
            ) : null}
            {weather ? <WeatherBadge weather={weather} /> : null}
          </View>

          <View style={{ alignItems: "flex-end", gap: 4 }}>
            {onMarkDone ? (
              <Pressable
                testID={`mark-done-${event.id}`}
                onPress={(e) => { e.stopPropagation(); onMarkDone(); }}
                style={({ pressed }) => ({
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                  backgroundColor: pressed ? "#D1FAE5" : "#ECFDF5",
                  borderRadius: 100,
                  paddingHorizontal: 8,
                  paddingVertical: 4,
                  borderWidth: 1,
                  borderColor: "#86EFAC",
                })}
              >
                <CheckCircle size={12} color="#16A34A" />
                <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 11, color: "#16A34A" }}>
                  Done
                </Text>
              </Pressable>
            ) : null}
            {event.assignedVendorIds.length > 0 ? (
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  backgroundColor: "#F5F0E8",
                  borderRadius: 100,
                  paddingHorizontal: 8,
                  paddingVertical: 3,
                  gap: 4,
                }}
              >
                <Users size={10} color="#8B7355" />
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 11, color: "#8B7355" }}>
                  {event.assignedVendorIds.length}
                </Text>
              </View>
            ) : null}
          </View>
        </View>
      </Pressable>
    </View>
  );
}
