import { useState } from "react";
import { View, Text, ScrollView, Pressable, ActivityIndicator, Modal } from "react-native";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import { CalendarDays, MapPin, Trash2, Check, Key } from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { WeddingWithRoleDTO } from "@/lib/types";
import { QUERY_KEYS, formatDate } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

const ROLE_LABELS: Record<string, string> = { admin: "Admin", couple: "Couple", vendor: "Vendor" };

export default function WeddingsScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const setActiveWeddingId = useWeddingStore((s) => s.setActiveWeddingId);

  const [deleteTarget, setDeleteTarget] = useState<WeddingWithRoleDTO | null>(null);

  const { data: weddings, isLoading } = useQuery({
    queryKey: QUERY_KEYS.weddings,
    queryFn: () => api.get<WeddingWithRoleDTO[]>("/api/weddings"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/api/weddings/${id}`),
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.weddings });
      if (activeWeddingId === deletedId) {
        setActiveWeddingId(null);
        router.replace("/wedding-select");
      }
      toast({ title: "Wedding deleted", preset: "done" });
      setDeleteTarget(null);
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
      setDeleteTarget(null);
    },
  });

  const switchWedding = (id: string) => {
    setActiveWeddingId(id);
    router.replace("/(tabs)/timeline");
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FAF7F2" }} edges={["top"]}>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 24, paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        <Text
          style={{
            fontFamily: "PlayfairDisplay_700Bold",
            fontSize: 28,
            color: "#2C1810",
            marginBottom: 6,
          }}
        >
          My Weddings
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 14,
            color: "#8B7355",
            marginBottom: 24,
          }}
        >
          Tap a wedding to switch to it
        </Text>

        {isLoading ? (
          <ActivityIndicator color="#C9A84C" style={{ marginTop: 40 }} />
        ) : weddings && weddings.length > 0 ? (
          weddings.map((w) => {
            const isActive = w.id === activeWeddingId;
            const isAdmin = w.myRole === "admin";
            return (
              <Pressable
                testID={`wedding-card-${w.id}`}
                key={w.id}
                onPress={() => switchWedding(w.id)}
                style={({ pressed }) => ({
                  backgroundColor: "#FFFFFF",
                  borderRadius: 16,
                  padding: 20,
                  marginBottom: 14,
                  borderWidth: isActive ? 2 : 1,
                  borderColor: isActive ? "#C9A84C" : "#E8E0D5",
                  opacity: pressed ? 0.88 : 1,
                  shadowColor: "#2C1810",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.06,
                  shadowRadius: 8,
                  elevation: 2,
                })}
              >
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <Text
                        style={{
                          fontFamily: "PlayfairDisplay_700Bold",
                          fontSize: 19,
                          color: "#2C1810",
                          flex: 1,
                        }}
                      >
                        {w.partner1Name} & {w.partner2Name}
                      </Text>
                      {isActive ? <Check size={16} color="#C9A84C" /> : null}
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 3 }}>
                      <CalendarDays size={13} color="#8B7355" />
                      <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                        {formatDate(w.weddingDate)}
                      </Text>
                    </View>
                    {w.venueName ? (
                      <View style={{ flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 3 }}>
                        <MapPin size={13} color="#8B7355" />
                        <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                          {w.venueName}
                        </Text>
                      </View>
                    ) : null}
                    {isAdmin ? (
                      <View style={{ flexDirection: "row", alignItems: "center", gap: 5, marginTop: 4 }}>
                        <Key size={12} color="#C9A84C" />
                        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 12, color: "#C9A84C", letterSpacing: 1.5 }}>
                          {w.inviteCode}
                        </Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={{ alignItems: "flex-end", gap: 8 }}>
                    <View
                      style={{
                        backgroundColor: w.myRole === "admin" ? "#F5EDD8" : w.myRole === "vendor" ? "#E8F0F8" : "#FCE8E8",
                        borderRadius: 100,
                        paddingHorizontal: 10,
                        paddingVertical: 4,
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "DMSans_500Medium",
                          fontSize: 11,
                          color: w.myRole === "admin" ? "#C9A84C" : w.myRole === "vendor" ? "#3B82F6" : "#E8474B",
                        }}
                      >
                        {ROLE_LABELS[w.myRole] ?? w.myRole}
                      </Text>
                    </View>
                    {isAdmin ? (
                      <Pressable
                        testID={`delete-wedding-${w.id}`}
                        onPress={() => setDeleteTarget(w)}
                        hitSlop={8}
                        style={({ pressed }) => ({
                          width: 32,
                          height: 32,
                          borderRadius: 8,
                          backgroundColor: pressed ? "#FEE2E2" : "#FEF2F2",
                          alignItems: "center",
                          justifyContent: "center",
                        })}
                      >
                        <Trash2 size={15} color="#EF4444" />
                      </Pressable>
                    ) : null}
                  </View>
                </View>
              </Pressable>
            );
          })
        ) : (
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <CalendarDays size={48} color="#E8E0D5" />
            <Text
              style={{
                fontFamily: "PlayfairDisplay_400Regular",
                fontSize: 18,
                color: "#8B7355",
                marginTop: 16,
                textAlign: "center",
              }}
            >
              No weddings yet
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Delete confirmation modal */}
      <Modal visible={deleteTarget !== null} transparent animationType="fade">
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 }}
          onPress={() => setDeleteTarget(null)}
        >
          <Pressable
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              padding: 28,
              width: "100%",
              maxWidth: 340,
            }}
            onPress={() => {}}
          >
            <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 22, color: "#2C1810", marginBottom: 10 }}>
              Delete Wedding?
            </Text>
            {deleteTarget ? (
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "#8B7355", marginBottom: 24, lineHeight: 22 }}>
                This will permanently delete {deleteTarget.partner1Name} & {deleteTarget.partner2Name}'s wedding, including all events and data. This cannot be undone and will remove it from all team members' apps.
              </Text>
            ) : null}
            <Pressable
              testID="confirm-delete-wedding"
              onPress={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              style={({ pressed }) => ({
                backgroundColor: "#EF4444",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                marginBottom: 10,
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                {deleteMutation.isPending ? "Deleting…" : "Yes, Delete"}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setDeleteTarget(null)}
              style={({ pressed }) => ({
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 15, color: "#8B7355" }}>Cancel</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}
