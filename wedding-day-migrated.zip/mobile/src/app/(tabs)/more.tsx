import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import { LogOut, ChevronRight, RefreshCw, ClipboardCheck } from "lucide-react-native";
import { api } from "@/lib/api/api";
import { authClient } from "@/lib/auth-client";
import type { UserProfileDTO, WeddingDetailDTO, UserRole } from "@/lib/types";
import { VENDOR_SPECIALTY_LABELS } from "@/lib/types";
import { QUERY_KEYS, formatDate, getInitials } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

const ROLE_COLORS: Record<UserRole, string> = {
  admin: "#F5EDD8",
  couple: "#FCE8E8",
  vendor: "#E8F0F8",
};
const ROLE_TEXT: Record<UserRole, string> = {
  admin: "#C9A84C",
  couple: "#E8474B",
  vendor: "#3B82F6",
};
const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Admin",
  couple: "Couple",
  vendor: "Vendor",
};

export default function MoreScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const setActiveWeddingId = useWeddingStore((s) => s.setActiveWeddingId);

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: QUERY_KEYS.me,
    queryFn: () => api.get<UserProfileDTO>("/api/me"),
  });

  const { data: wedding } = useQuery({
    queryKey: QUERY_KEYS.wedding(activeWeddingId ?? ""),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${activeWeddingId}`),
    enabled: !!activeWeddingId,
  });

  const isAdmin = wedding?.myRole === "admin";
  const pendingCount = wedding?.pendingChangeRequests?.length ?? 0;

  const signOutMutation = useMutation({
    mutationFn: () => authClient.signOut(),
    onSuccess: () => {
      setActiveWeddingId(null);
      queryClient.clear();
      router.replace("/sign-in");
    },
    onError: () => {
      toast({ title: "Sign out failed", preset: "error" });
    },
  });

  const handleSwitchWedding = () => {
    setActiveWeddingId(null);
    router.replace("/wedding-select");
  };

  if (profileLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  const displayName = profile?.displayName || profile?.name || "You";
  const initials = getInitials(displayName);
  const role: UserRole = (wedding?.myRole as UserRole) ?? profile?.role ?? "couple";

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="more-screen">
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
        {/* Profile card */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 18,
            padding: 20,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            shadowColor: "#2C1810",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.06,
            shadowRadius: 8,
            elevation: 2,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 16 }}>
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 28,
                backgroundColor: "#C9A84C",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 20, color: "#FFFFFF" }}>
                {initials}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 17, color: "#2C1810" }}>
                  {displayName}
                </Text>
                <View
                  style={{
                    backgroundColor: ROLE_COLORS[role],
                    borderRadius: 100,
                    paddingHorizontal: 8,
                    paddingVertical: 2,
                  }}
                >
                  <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 11, color: ROLE_TEXT[role] }}>
                    {ROLE_LABELS[role]}
                  </Text>
                </View>
              </View>
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginTop: 2 }}>
                {profile?.email}
              </Text>
              {profile?.vendorSpecialty ? (
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
                  {VENDOR_SPECIALTY_LABELS[profile.vendorSpecialty]}
                </Text>
              ) : null}
            </View>
          </View>
        </View>

        {/* Wedding info */}
        {wedding ? (
          <View
            style={{
              backgroundColor: "#FDF8EE",
              borderRadius: 14,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: "#E8D5A0",
            }}
          >
            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1,
                textTransform: "uppercase",
                marginBottom: 8,
              }}
            >
              Wedding
            </Text>
            <Text style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 20, color: "#2C1810" }}>
              {wedding.partner1Name} & {wedding.partner2Name}
            </Text>
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355", marginTop: 4 }}>
              {formatDate(wedding.weddingDate)}
            </Text>
            {wedding.venueName ? (
              <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                {wedding.venueName}
              </Text>
            ) : null}
          </View>
        ) : null}

        {/* Actions */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 14,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            overflow: "hidden",
            marginBottom: 20,
          }}
        >
          {isAdmin ? (
            <ActionRow
              testID="pending-approvals-row"
              icon={<ClipboardCheck size={18} color="#C9A84C" />}
              label="Pending Approvals"
              badge={pendingCount > 0 ? String(pendingCount) : undefined}
              badgeColor="#E8474B"
              onPress={() => router.push("/approvals")}
              showDivider
            />
          ) : null}
          <ActionRow
            testID="switch-wedding-row"
            icon={<RefreshCw size={18} color="#8B7355" />}
            label="Switch Wedding"
            onPress={handleSwitchWedding}
          />
        </View>

        {/* Sign out */}
        <Pressable
          testID="sign-out-button"
          onPress={() => signOutMutation.mutate()}
          disabled={signOutMutation.isPending}
          style={({ pressed }) => ({
            alignItems: "center",
            paddingVertical: 16,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <LogOut size={16} color="#D4453F" />
            <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#D4453F" }}>
              {signOutMutation.isPending ? "Signing out…" : "Sign Out"}
            </Text>
          </View>
        </Pressable>
      </ScrollView>
    </View>
  );
}

function ActionRow({
  icon,
  label,
  badge,
  badgeColor,
  onPress,
  showDivider,
  testID,
}: {
  icon: React.ReactNode;
  label: string;
  badge?: string;
  badgeColor?: string;
  onPress: () => void;
  showDivider?: boolean;
  testID: string;
}) {
  return (
    <>
      <Pressable
        testID={testID}
        onPress={onPress}
        style={({ pressed }) => ({
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
          gap: 12,
          backgroundColor: pressed ? "#FAF7F2" : "#FFFFFF",
        })}
      >
        {icon}
        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 15, color: "#2C1810", flex: 1 }}>
          {label}
        </Text>
        {badge ? (
          <View
            style={{
              backgroundColor: badgeColor ?? "#C9A84C",
              borderRadius: 100,
              minWidth: 20,
              height: 20,
              alignItems: "center",
              justifyContent: "center",
              paddingHorizontal: 6,
            }}
          >
            <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 11, color: "#FFFFFF" }}>
              {badge}
            </Text>
          </View>
        ) : null}
        <ChevronRight size={16} color="#C8B8A2" />
      </Pressable>
      {showDivider ? (
        <View style={{ height: 1, backgroundColor: "#F0EAE0", marginLeft: 16 }} />
      ) : null}
    </>
  );
}
