import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import { Picker } from "@react-native-picker/picker";
import { Heart, Camera, Crown } from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { UserProfileDTO, UserRole, VendorSpecialty } from "@/lib/types";
import { VENDOR_SPECIALTIES, VENDOR_SPECIALTY_LABELS } from "@/lib/types";
import { QUERY_KEYS } from "@/lib/utils";

type RoleChoice = "coordinator" | "vendor" | "couple";

export default function SetupProfileScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const [fullName, setFullName] = useState<string>("");
  const [displayName, setDisplayName] = useState<string>("");
  const [roleChoice, setRoleChoice] = useState<RoleChoice | null>(null);
  const [specialty, setSpecialty] = useState<VendorSpecialty>("photographer");
  const [phone, setPhone] = useState<string>("");
  const [company, setCompany] = useState<string>("");

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isVendorType = roleChoice === "coordinator" || roleChoice === "vendor";
      const resolvedRole: UserRole = roleChoice === "couple" ? "couple" : "vendor";
      const resolvedSpecialty: VendorSpecialty =
        roleChoice === "coordinator" ? "coordinator" : specialty;

      const body: Record<string, unknown> = {
        name: fullName.trim(),
        displayName: displayName.trim() || fullName.trim(),
        role: resolvedRole,
        phone: phone.trim() || null,
      };
      if (isVendorType) {
        body.vendorSpecialty = resolvedSpecialty;
        body.company = company.trim() || null;
      }
      return api.patch<UserProfileDTO>("/api/me", body);
    },
    onSuccess: (data) => {
      queryClient.setQueryData(QUERY_KEYS.me, data);
      router.replace("/wedding-select");
    },
  });

  const isValid = fullName.trim().length > 0 && roleChoice !== null;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FAF7F2" }}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 28, paddingVertical: 40 }}
          keyboardShouldPersistTaps="handled"
        >
          <Text
            style={{
              fontFamily: "PlayfairDisplay_700Bold",
              fontSize: 32,
              color: "#2C1810",
              marginBottom: 8,
            }}
          >
            Tell us about yourself
          </Text>
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 15,
              color: "#8B7355",
              marginBottom: 36,
            }}
          >
            Help the team know who you are
          </Text>

          <FieldLabel>Full Name</FieldLabel>
          <TextInput
            testID="full-name-input"
            value={fullName}
            onChangeText={setFullName}
            placeholder="Jane Smith"
            placeholderTextColor="#C8B8A2"
            style={inputStyle}
          />

          <FieldLabel>Display Name</FieldLabel>
          <TextInput
            testID="display-name-input"
            value={displayName}
            onChangeText={setDisplayName}
            placeholder="Jane (shown to the team)"
            placeholderTextColor="#C8B8A2"
            style={inputStyle}
          />

          {/* Role selection — vertical stack */}
          <FieldLabel>My Role</FieldLabel>
          <View style={{ gap: 10, marginBottom: 24 }}>
            <RoleCard
              testID="role-coordinator"
              selected={roleChoice === "coordinator"}
              onPress={() => setRoleChoice("coordinator")}
              icon={<Crown size={22} color={roleChoice === "coordinator" ? "#C9A84C" : "#8B7355"} />}
              title="Planner or Day-of Coordinator"
              subtitle="You create the wedding and manage the timeline. Vendors and the couple join your event."
              badge="Creates wedding"
            />
            <RoleCard
              testID="role-vendor"
              selected={roleChoice === "vendor"}
              onPress={() => setRoleChoice("vendor")}
              icon={<Camera size={22} color={roleChoice === "vendor" ? "#C9A84C" : "#8B7355"} />}
              title="Vendor"
              subtitle="Photographer, videographer, DJ, florist, or other wedding professional."
            />
            <RoleCard
              testID="role-couple"
              selected={roleChoice === "couple"}
              onPress={() => setRoleChoice("couple")}
              icon={<Heart size={22} color={roleChoice === "couple" ? "#C9A84C" : "#8B7355"} />}
              title="Bride, Groom, or Partner"
              subtitle="View the timeline and add your important people — family, bridal party, and guests."
            />
          </View>

          {/* Vendor specialty picker (only for non-coordinator vendors) */}
          {roleChoice === "vendor" ? (
            <>
              <FieldLabel>Specialty</FieldLabel>
              <View
                style={{
                  borderWidth: 1,
                  borderColor: "#E8E0D5",
                  borderRadius: 12,
                  backgroundColor: "#FFFFFF",
                  marginBottom: 20,
                  overflow: "hidden",
                }}
              >
                <Picker
                  testID="specialty-picker"
                  selectedValue={specialty}
                  onValueChange={(v) => setSpecialty(v as VendorSpecialty)}
                  style={{ color: "#2C1810" }}
                >
                  {VENDOR_SPECIALTIES.filter((s) => s !== "coordinator" && s !== "planner").map((s) => (
                    <Picker.Item key={s} label={VENDOR_SPECIALTY_LABELS[s]} value={s} />
                  ))}
                </Picker>
              </View>
            </>
          ) : null}

          {/* Company / phone for vendors */}
          {roleChoice === "coordinator" || roleChoice === "vendor" ? (
            <>
              <FieldLabel>Company or Studio (optional)</FieldLabel>
              <TextInput
                testID="company-input"
                value={company}
                onChangeText={setCompany}
                placeholder="Your business name"
                placeholderTextColor="#C8B8A2"
                style={inputStyle}
              />
            </>
          ) : null}

          <FieldLabel>Phone (optional)</FieldLabel>
          <TextInput
            testID="phone-input"
            value={phone}
            onChangeText={setPhone}
            placeholder="+1 (555) 000-0000"
            placeholderTextColor="#C8B8A2"
            keyboardType="phone-pad"
            style={inputStyle}
          />

          {saveMutation.isError ? (
            <Text
              style={{
                fontFamily: "DMSans_400Regular",
                fontSize: 13,
                color: "#D4453F",
                marginBottom: 16,
                textAlign: "center",
              }}
            >
              {saveMutation.error?.message ?? "Something went wrong"}
            </Text>
          ) : null}

          <Pressable
            testID="get-started-button"
            onPress={() => saveMutation.mutate()}
            disabled={!isValid || saveMutation.isPending}
            style={({ pressed }) => ({
              backgroundColor: isValid ? "#C9A84C" : "#D4C090",
              borderRadius: 100,
              paddingVertical: 16,
              alignItems: "center",
              marginTop: 8,
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#FFFFFF" }}>
              {saveMutation.isPending ? "Saving…" : "Get Started"}
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function FieldLabel({ children }: { children: string }) {
  return (
    <Text
      style={{
        fontFamily: "DMSans_500Medium",
        fontSize: 12,
        color: "#8B7355",
        letterSpacing: 1,
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );
}

function RoleCard({
  selected,
  onPress,
  icon,
  title,
  subtitle,
  badge,
  testID,
}: {
  selected: boolean;
  onPress: () => void;
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  badge?: string;
  testID: string;
}) {
  return (
    <Pressable
      testID={testID}
      onPress={onPress}
      style={({ pressed }) => ({
        borderWidth: selected ? 2 : 1,
        borderColor: selected ? "#C9A84C" : "#E8E0D5",
        borderRadius: 16,
        backgroundColor: selected ? "#FDF8EE" : "#FFFFFF",
        padding: 16,
        flexDirection: "row",
        alignItems: "flex-start",
        gap: 14,
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 12,
          backgroundColor: selected ? "#F5EDD8" : "#F5F0E8",
          alignItems: "center",
          justifyContent: "center",
          marginTop: 2,
        }}
      >
        {icon}
      </View>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 }}>
          <Text
            style={{
              fontFamily: "DMSans_600SemiBold",
              fontSize: 15,
              color: "#2C1810",
              flex: 1,
            }}
          >
            {title}
          </Text>
          {badge ? (
            <View
              style={{
                backgroundColor: "#C9A84C",
                borderRadius: 100,
                paddingHorizontal: 8,
                paddingVertical: 2,
              }}
            >
              <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 10, color: "#FFFFFF" }}>
                {badge}
              </Text>
            </View>
          ) : null}
        </View>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 12,
            color: "#8B7355",
            lineHeight: 18,
          }}
        >
          {subtitle}
        </Text>
      </View>
    </Pressable>
  );
}

const inputStyle = {
  fontFamily: "DMSans_400Regular" as const,
  fontSize: 16,
  color: "#2C1810",
  borderBottomWidth: 1.5,
  borderBottomColor: "#E8E0D5",
  paddingVertical: 10,
  marginBottom: 24,
};
