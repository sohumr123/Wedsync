import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { useRouter } from "expo-router";
import { useMutation } from "@tanstack/react-query";
import { authClient } from "@/lib/auth-client";
import Svg, { Circle, Line, Path } from "react-native-svg";
import { SafeAreaView } from "react-native-safe-area-context";

function RingDecoration() {
  return (
    <Svg width={200} height={160} viewBox="0 0 200 160">
      <Circle cx={70} cy={80} r={40} stroke="#C9A84C" strokeWidth={2.5} fill="none" opacity={0.7} />
      <Circle cx={130} cy={80} r={40} stroke="#C9A84C" strokeWidth={2.5} fill="none" opacity={0.7} />
      <Circle cx={70} cy={80} r={30} stroke="#E8C4C4" strokeWidth={1} fill="none" opacity={0.5} />
      <Circle cx={130} cy={80} r={30} stroke="#E8C4C4" strokeWidth={1} fill="none" opacity={0.5} />
      <Path
        d="M 100 55 C 100 55, 88 42, 75 50 C 62 58, 65 75, 100 95 C 135 75, 138 58, 125 50 C 112 42, 100 55, 100 55 Z"
        fill="#C9A84C"
        opacity={0.15}
      />
      <Path
        d="M 100 58 C 100 58, 90 47, 78 54 C 66 61, 68 76, 100 93 C 132 76, 134 61, 122 54 C 110 47, 100 58, 100 58 Z"
        fill="none"
        stroke="#C9A84C"
        strokeWidth={1.5}
        opacity={0.6}
      />
    </Svg>
  );
}

export default function SignInScreen() {
  const [email, setEmail] = useState<string>("");
  const router = useRouter();

  const sendOtpMutation = useMutation({
    mutationFn: async (emailAddr: string) => {
      const result = await (authClient as any).emailOtp.sendVerificationOtp({
        email: emailAddr,
        type: "sign-in",
      });
      if (result.error) throw new Error(result.error.message ?? "Failed to send code");
      return result;
    },
    onSuccess: () => {
      router.push({ pathname: "/verify-otp", params: { email } });
    },
  });

  const handleSend = () => {
    const trimmed = email.trim();
    if (!trimmed) return;
    sendOtpMutation.mutate(trimmed);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FAF7F2" }}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 32 }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={{ flex: 1, justifyContent: "center", paddingVertical: 48 }}>
            {/* Decorative ring illustration */}
            <View style={{ alignItems: "center", marginBottom: 32 }}>
              <RingDecoration />
            </View>

            {/* Heading */}
            <Text
              style={{
                fontFamily: "PlayfairDisplay_700Bold",
                fontSize: 40,
                color: "#2C1810",
                textAlign: "center",
                lineHeight: 48,
                marginBottom: 8,
              }}
            >
              Wedding Day
            </Text>
            <Text
              style={{
                fontFamily: "DMSans_400Regular",
                fontSize: 16,
                color: "#8B7355",
                textAlign: "center",
                letterSpacing: 0.5,
                marginBottom: 52,
              }}
            >
              Coordination made beautiful
            </Text>

            {/* Email input */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "DMSans_500Medium",
                  fontSize: 12,
                  color: "#8B7355",
                  letterSpacing: 1,
                  textTransform: "uppercase",
                  marginBottom: 8,
                }}
              >
                Email Address
              </Text>
              <TextInput
                testID="email-input"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="email"
                returnKeyType="done"
                onSubmitEditing={handleSend}
                placeholder="your@email.com"
                placeholderTextColor="#C8B8A2"
                style={{
                  fontFamily: "DMSans_400Regular",
                  fontSize: 17,
                  color: "#2C1810",
                  borderBottomWidth: 1.5,
                  borderBottomColor: "#C9A84C",
                  paddingVertical: 10,
                  paddingHorizontal: 0,
                }}
              />
            </View>

            {/* Error */}
            {sendOtpMutation.isError ? (
              <Text
                style={{
                  fontFamily: "DMSans_400Regular",
                  fontSize: 13,
                  color: "#D4453F",
                  marginBottom: 16,
                  textAlign: "center",
                }}
              >
                {sendOtpMutation.error?.message ?? "Something went wrong. Please try again."}
              </Text>
            ) : null}

            {/* Send code button */}
            <Pressable
              testID="send-code-button"
              onPress={handleSend}
              disabled={sendOtpMutation.isPending || !email.trim()}
              style={({ pressed }) => ({
                backgroundColor:
                  sendOtpMutation.isPending || !email.trim() ? "#D4C090" : "#C9A84C",
                borderRadius: 100,
                paddingVertical: 16,
                alignItems: "center",
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text
                style={{
                  fontFamily: "DMSans_600SemiBold",
                  fontSize: 16,
                  color: "#FFFFFF",
                  letterSpacing: 0.3,
                }}
              >
                {sendOtpMutation.isPending ? "Sending…" : "Send Code"}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
