import { Stack } from "expo-router";
import { Toaster } from "burnt/web";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import {
  useFonts,
  PlayfairDisplay_700Bold,
  PlayfairDisplay_400Regular,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

export const unstable_settings = {
  initialRouteName: "(tabs)",
};

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

export function RootLayoutNav() {
  return (
    <Stack>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="modal" options={{ presentation: "modal" }} />
      <Stack.Screen name="sign-in" options={{ headerShown: false }} />
      <Stack.Screen name="verify-otp" options={{ headerShown: false }} />
      <Stack.Screen
        name="setup-profile"
        options={{ headerShown: false, title: "Profile Setup" }}
      />
      <Stack.Screen name="wedding-select" options={{ headerShown: false }} />
      <Stack.Screen
        name="approvals"
        options={{
          title: "Pending Approvals",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
          headerTitleStyle: { fontFamily: "PlayfairDisplay_700Bold", color: "#2C1810" },
        }}
      />
      <Stack.Screen
        name="event-detail"
        options={{
          presentation: "modal",
          title: "",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
        }}
      />
      <Stack.Screen
        name="quick-adjust"
        options={{
          presentation: "formSheet",
          sheetGrabberVisible: true,
          sheetAllowedDetents: [0.55],
          title: "Adjust Timeline",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
          headerTitleStyle: { fontFamily: "DMSans_600SemiBold", color: "#2C1810" },
        }}
      />
      <Stack.Screen
        name="adjust-event"
        options={{
          presentation: "formSheet",
          sheetGrabberVisible: true,
          sheetAllowedDetents: [0.85],
          title: "Propose Adjustment",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
          headerTitleStyle: { fontFamily: "DMSans_600SemiBold", color: "#2C1810" },
        }}
      />
      <Stack.Screen
        name="add-event"
        options={{
          presentation: "formSheet",
          sheetGrabberVisible: true,
          sheetAllowedDetents: [0.92],
          title: "Add Event",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
          headerTitleStyle: { fontFamily: "DMSans_600SemiBold", color: "#2C1810" },
        }}
      />
      <Stack.Screen
        name="add-person"
        options={{
          presentation: "formSheet",
          sheetGrabberVisible: true,
          sheetAllowedDetents: [0.75],
          title: "Add Person",
          headerStyle: { backgroundColor: "#FAF7F2" },
          headerTintColor: "#C9A84C",
          headerTitleStyle: { fontFamily: "DMSans_600SemiBold", color: "#2C1810" },
        }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    PlayfairDisplay_700Bold,
    PlayfairDisplay_400Regular,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded) SplashScreen.hideAsync();
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <QueryClientProvider client={queryClient}>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <KeyboardProvider>
          <StatusBar style="dark" />
          <Toaster />
          <RootLayoutNav />
        </KeyboardProvider>
      </GestureHandlerRootView>
    </QueryClientProvider>
  );
}
