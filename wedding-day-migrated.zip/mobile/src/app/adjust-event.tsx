import { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import DateTimePicker from "@react-native-community/datetimepicker";
import { api } from "@/lib/api/api";
import type { WeddingDetailDTO, ChangeRequestDTO, TimelineEventDTO } from "@/lib/types";
import { QUERY_KEYS, formatTime } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

export default function AdjustEventScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { eventId, weddingId } = useLocalSearchParams<{ eventId: string; weddingId: string }>();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const resolvedWeddingId = weddingId ?? activeWeddingId ?? "";

  const { data: wedding } = useQuery({
    queryKey: QUERY_KEYS.wedding(resolvedWeddingId),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${resolvedWeddingId}`),
    enabled: !!resolvedWeddingId,
  });

  const event = wedding?.events?.find((e) => e.id === eventId);

  const [startTime, setStartTime] = useState<Date>(
    event ? new Date(event.startTime) : new Date()
  );
  const [endTime, setEndTime] = useState<Date>(
    event ? new Date(event.endTime) : new Date()
  );
  const [reason, setReason] = useState<string>("");
  const [activeTimePicker, setActiveTimePicker] = useState<"start" | "end" | null>(null);

  useEffect(() => {
    if (event) {
      setStartTime(new Date(event.startTime));
      setEndTime(new Date(event.endTime));
    }
  }, [event?.id]);

  const isAdmin = wedding?.myRole === "admin";

  const adjustMutation = useMutation({
    mutationFn: () =>
      api.post<ChangeRequestDTO | TimelineEventDTO>(
        `/api/weddings/${resolvedWeddingId}/events/${eventId}/adjust`,
        {
          proposedStartTime: startTime.toISOString(),
          proposedEndTime: endTime.toISOString(),
          reason: reason.trim() || undefined,
        }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(resolvedWeddingId) });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.events(resolvedWeddingId) });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.changeRequests(resolvedWeddingId) });
      toast({
        title: isAdmin ? "Time updated!" : "Adjustment sent for approval",
        preset: "done",
      });
      router.back();
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  if (!event) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator color="#C9A84C" />
      </View>
    );
  }

  const togglePicker = (which: "start" | "end") => {
    setActiveTimePicker(activeTimePicker === which ? null : which);
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="adjust-event-screen">
      <ScrollView
        contentContainerStyle={{ padding: 24, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
      >
        <Text
          style={{
            fontFamily: "PlayfairDisplay_700Bold",
            fontSize: 22,
            color: "#2C1810",
            marginBottom: 4,
          }}
        >
          {event.title}
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 13,
            color: "#8B7355",
            marginBottom: 28,
          }}
        >
          Current: {formatTime(event.startTime)} – {formatTime(event.endTime)}
        </Text>

        {/* Start time */}
        <SectionLabel>New Start Time</SectionLabel>
        <Pressable
          testID="start-time-picker-button"
          onPress={() => togglePicker("start")}
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: activeTimePicker === "start" ? "#C9A84C" : "#E8E0D5",
            padding: 14,
            marginBottom: 0,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottomLeftRadius: activeTimePicker === "start" ? 0 : 12,
            borderBottomRightRadius: activeTimePicker === "start" ? 0 : 12,
          }}
        >
          <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 16, color: "#2C1810" }}>
            {formatTime(startTime.toISOString())}
          </Text>
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
            {activeTimePicker === "start" ? "Tap to close" : "Tap to change"}
          </Text>
        </Pressable>
        {activeTimePicker === "start" && (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderTopWidth: 0,
              borderColor: "#C9A84C",
              borderBottomLeftRadius: 12,
              borderBottomRightRadius: 12,
              marginBottom: 16,
            }}
          >
            <DateTimePicker
              testID="start-time-picker"
              value={startTime}
              mode="time"
              display="spinner"
              onChange={(_, date) => { if (date) setStartTime(date); }}
              style={{ backgroundColor: "#FFFFFF" }}
            />
            <Pressable
              testID="start-time-picker-done"
              onPress={() => setActiveTimePicker(null)}
              style={{ alignItems: "center", paddingVertical: 10, borderTopWidth: 1, borderTopColor: "#E8E0D5" }}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#C9A84C" }}>Done</Text>
            </Pressable>
          </View>
        )}
        {activeTimePicker !== "start" && <View style={{ marginBottom: 16 }} />}

        {/* End time */}
        <SectionLabel>New End Time</SectionLabel>
        <Pressable
          testID="end-time-picker-button"
          onPress={() => togglePicker("end")}
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: activeTimePicker === "end" ? "#C9A84C" : "#E8E0D5",
            padding: 14,
            marginBottom: 0,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottomLeftRadius: activeTimePicker === "end" ? 0 : 12,
            borderBottomRightRadius: activeTimePicker === "end" ? 0 : 12,
          }}
        >
          <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 16, color: "#2C1810" }}>
            {formatTime(endTime.toISOString())}
          </Text>
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
            {activeTimePicker === "end" ? "Tap to close" : "Tap to change"}
          </Text>
        </Pressable>
        {activeTimePicker === "end" && (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderTopWidth: 0,
              borderColor: "#C9A84C",
              borderBottomLeftRadius: 12,
              borderBottomRightRadius: 12,
              marginBottom: 16,
            }}
          >
            <DateTimePicker
              testID="end-time-picker"
              value={endTime}
              mode="time"
              display="spinner"
              onChange={(_, date) => { if (date) setEndTime(date); }}
              style={{ backgroundColor: "#FFFFFF" }}
            />
            <Pressable
              testID="end-time-picker-done"
              onPress={() => setActiveTimePicker(null)}
              style={{ alignItems: "center", paddingVertical: 10, borderTopWidth: 1, borderTopColor: "#E8E0D5" }}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#C9A84C" }}>Done</Text>
            </Pressable>
          </View>
        )}
        {activeTimePicker !== "end" && <View style={{ marginBottom: 16 }} />}

        {/* Reason */}
        <SectionLabel>Reason for Change</SectionLabel>
        <TextInput
          testID="reason-input"
          value={reason}
          onChangeText={setReason}
          placeholder="e.g. Running 15 minutes behind schedule…"
          placeholderTextColor="#C8B8A2"
          multiline
          numberOfLines={4}
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            padding: 14,
            fontFamily: "DMSans_400Regular",
            fontSize: 15,
            color: "#2C1810",
            minHeight: 100,
            textAlignVertical: "top",
            marginBottom: 8,
          }}
        />
      </ScrollView>

      {/* Submit */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E8E0D5",
          padding: 20,
          paddingBottom: 36,
        }}
      >
        <Pressable
          testID="submit-adjustment-button"
          onPress={() => adjustMutation.mutate()}
          disabled={adjustMutation.isPending}
          style={({ pressed }) => ({
            backgroundColor: "#C9A84C",
            borderRadius: 100,
            paddingVertical: 16,
            alignItems: "center",
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#FFFFFF" }}>
            {adjustMutation.isPending
              ? "Submitting…"
              : isAdmin
              ? "Update Time"
              : "Send for Approval"}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function SectionLabel({ children }: { children: string }) {
  return (
    <Text
      style={{
        fontFamily: "DMSans_500Medium",
        fontSize: 11,
        color: "#8B7355",
        letterSpacing: 1,
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );
}
