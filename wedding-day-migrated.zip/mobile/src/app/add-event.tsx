import { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Picker } from "@react-native-picker/picker";
import { api } from "@/lib/api/api";
import type { TimelineEventDTO, EventCategory } from "@/lib/types";
import { EVENT_CATEGORIES, EVENT_CATEGORY_LABELS } from "@/lib/types";
import { QUERY_KEYS, formatTime } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

export default function AddEventScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { weddingId } = useLocalSearchParams<{ weddingId: string }>();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const resolvedWeddingId = weddingId ?? activeWeddingId ?? "";

  const [title, setTitle] = useState<string>("");
  const [category, setCategory] = useState<EventCategory>("ceremony");
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [endTime, setEndTime] = useState<Date>(new Date(Date.now() + 60 * 60 * 1000));
  const [locationName, setLocationName] = useState<string>("");
  const [address, setAddress] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [activeTimePicker, setActiveTimePicker] = useState<"start" | "end" | null>(null);
  const [tempTime, setTempTime] = useState<Date>(new Date());

  const addMutation = useMutation({
    mutationFn: () =>
      api.post<TimelineEventDTO>(`/api/weddings/${resolvedWeddingId}/events`, {
        title: title.trim(),
        category,
        startTime: startTime.toISOString(),
        endTime: endTime.toISOString(),
        locationName: locationName.trim() || undefined,
        address: address.trim() || undefined,
        description: description.trim() || undefined,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(resolvedWeddingId) });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.events(resolvedWeddingId) });
      toast({ title: "Event added!", preset: "done" });
      router.back();
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const isValid = title.trim().length > 0;

  const openPicker = (which: "start" | "end") => {
    setTempTime(which === "start" ? startTime : endTime);
    setActiveTimePicker(which);
  };

  const confirmPicker = () => {
    if (activeTimePicker === "start") setStartTime(tempTime);
    else if (activeTimePicker === "end") setEndTime(tempTime);
    setActiveTimePicker(null);
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="add-event-screen">
      <Modal
        visible={activeTimePicker !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setActiveTimePicker(null)}
      >
        <View style={{ flex: 1, justifyContent: "flex-end" }}>
          <Pressable
            style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.4)" }}
            onPress={() => setActiveTimePicker(null)}
          />
          <View style={{ backgroundColor: "#FAF7F2", borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingBottom: 40 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#E8E0D5" }}>
              <Pressable onPress={() => setActiveTimePicker(null)}>
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 16, color: "#8B7355" }}>Cancel</Text>
              </Pressable>
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#2C1810" }}>
                {activeTimePicker === "start" ? "Start Time" : "End Time"}
              </Text>
              <Pressable onPress={confirmPicker}>
                <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#C9A84C" }}>Done</Text>
              </Pressable>
            </View>
            <DateTimePicker
              testID="time-picker-modal"
              value={tempTime}
              mode="time"
              display="spinner"
              onChange={(_, date) => { if (date) setTempTime(date); }}
              style={{ backgroundColor: "#FAF7F2" }}
            />
          </View>
        </View>
      </Modal>
      <ScrollView
        contentContainerStyle={{ padding: 24, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Title */}
        <FieldLabel>Event Title</FieldLabel>
        <TextInput
          testID="title-input"
          value={title}
          onChangeText={setTitle}
          placeholder="e.g. First Dance"
          placeholderTextColor="#C8B8A2"
          style={inputStyle}
        />

        {/* Category */}
        <FieldLabel>Category</FieldLabel>
        <View
          style={{
            borderWidth: 1,
            borderColor: "#E8E0D5",
            borderRadius: 12,
            backgroundColor: "#FFFFFF",
            marginBottom: 20,
            overflow: "hidden",
          }}
        >
          <Picker
            testID="category-picker"
            selectedValue={category}
            onValueChange={(v) => setCategory(v as EventCategory)}
            style={{ color: "#2C1810" }}
          >
            {EVENT_CATEGORIES.map((c) => (
              <Picker.Item key={c} label={EVENT_CATEGORY_LABELS[c]} value={c} />
            ))}
          </Picker>
        </View>

        {/* Start time */}
        <FieldLabel>Start Time</FieldLabel>
        <Pressable
          testID="start-time-button"
          onPress={() => openPicker("start")}
          style={timePickerStyle}
        >
          <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 16, color: "#2C1810" }}>
            {formatTime(startTime.toISOString())}
          </Text>
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
            Tap to change
          </Text>
        </Pressable>

        {/* End time */}
        <FieldLabel>End Time</FieldLabel>
        <Pressable
          testID="end-time-button"
          onPress={() => openPicker("end")}
          style={timePickerStyle}
        >
          <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 16, color: "#2C1810" }}>
            {formatTime(endTime.toISOString())}
          </Text>
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355" }}>
            Tap to change
          </Text>
        </Pressable>
        {/* Location */}
        <FieldLabel>Location Name</FieldLabel>
        <TextInput
          testID="location-input"
          value={locationName}
          onChangeText={setLocationName}
          placeholder="e.g. Main Ballroom"
          placeholderTextColor="#C8B8A2"
          style={inputStyle}
        />

        {/* Address */}
        <FieldLabel>Address (optional)</FieldLabel>
        <AddressSearch
          value={address}
          onChangeText={setAddress}
          onSelect={(displayName, shortName) => {
            setAddress(displayName);
            if (!locationName.trim()) setLocationName(shortName);
          }}
        />

        {/* Description */}
        <FieldLabel>Notes (optional)</FieldLabel>
        <TextInput
          testID="description-input"
          value={description}
          onChangeText={setDescription}
          placeholder="Any details for the team…"
          placeholderTextColor="#C8B8A2"
          multiline
          numberOfLines={3}
          style={{
            ...inputStyle,
            minHeight: 80,
            textAlignVertical: "top",
            borderWidth: 1,
            borderColor: "#E8E0D5",
            borderRadius: 12,
            backgroundColor: "#FFFFFF",
            padding: 14,
            borderBottomWidth: 1,
          }}
        />
      </ScrollView>

      {/* Submit */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E8E0D5",
          padding: 20,
          paddingBottom: 36,
        }}
      >
        <Pressable
          testID="add-event-button"
          onPress={() => addMutation.mutate()}
          disabled={!isValid || addMutation.isPending}
          style={({ pressed }) => ({
            backgroundColor: isValid ? "#C9A84C" : "#D4C090",
            borderRadius: 100,
            paddingVertical: 16,
            alignItems: "center",
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#FFFFFF" }}>
            {addMutation.isPending ? "Adding…" : "Add Event"}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function FieldLabel({ children }: { children: string }) {
  return (
    <Text
      style={{
        fontFamily: "DMSans_500Medium",
        fontSize: 11,
        color: "#8B7355",
        letterSpacing: 1,
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );
}

const inputStyle = {
  fontFamily: "DMSans_400Regular" as const,
  fontSize: 16,
  color: "#2C1810",
  borderBottomWidth: 1.5,
  borderBottomColor: "#E8E0D5",
  paddingVertical: 10,
  marginBottom: 20,
  backgroundColor: "transparent",
};

const timePickerStyle = {
  backgroundColor: "#FFFFFF",
  borderRadius: 12,
  borderWidth: 1,
  borderColor: "#E8E0D5",
  padding: 14,
  marginBottom: 16,
  flexDirection: "row" as const,
  justifyContent: "space-between" as const,
  alignItems: "center" as const,
};

type NominatimResult = {
  place_id: number;
  display_name: string;
  name: string;
  address: {
    house_number?: string;
    road?: string;
    venue?: string;
    building?: string;
    amenity?: string;
  };
};

function AddressSearch({
  value,
  onChangeText,
  onSelect,
}: {
  value: string;
  onChangeText: (text: string) => void;
  onSelect: (displayName: string, shortName: string) => void;
}) {
  const [results, setResults] = useState<NominatimResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleChange = (text: string) => {
    onChangeText(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (text.length < 3) {
      setResults([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(text)}&format=json&limit=5&addressdetails=1`,
          { headers: { "User-Agent": "WeddingDayApp/1.0" } }
        );
        const data: NominatimResult[] = await res.json();
        setResults(data);
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 400);
  };

  const handleSelect = (r: NominatimResult) => {
    const shortName =
      r.address.venue ||
      r.address.amenity ||
      r.address.building ||
      r.name ||
      r.display_name.split(",")[0];
    onSelect(r.display_name, shortName);
    setResults([]);
  };

  return (
    <View style={{ marginBottom: 20, zIndex: 10 }}>
      <View style={{ position: "relative" }}>
        <TextInput
          testID="address-input"
          value={value}
          onChangeText={handleChange}
          placeholder="123 Wedding Venue Rd"
          placeholderTextColor="#C8B8A2"
          style={{ ...inputStyle, marginBottom: 0 }}
        />
        {loading ? (
          <ActivityIndicator
            size="small"
            color="#C9A84C"
            style={{ position: "absolute", right: 0, top: 12 }}
          />
        ) : null}
      </View>
      {results.length > 0 ? (
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            marginTop: 4,
            overflow: "hidden",
            shadowColor: "#2C1810",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.1,
            shadowRadius: 12,
            elevation: 6,
          }}
        >
          {results.map((r, i) => {
            const parts = r.display_name.split(", ");
            const primary = parts.slice(0, 2).join(", ");
            const secondary = parts.slice(2).join(", ");
            return (
              <Pressable
                testID={`address-result-${i}`}
                key={r.place_id}
                onPress={() => handleSelect(r)}
                style={({ pressed }) => ({
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  borderBottomWidth: i < results.length - 1 ? 1 : 0,
                  borderBottomColor: "#F0EAE0",
                  backgroundColor: pressed ? "#FDF8EE" : "#FFFFFF",
                })}
              >
                <Text
                  style={{ fontFamily: "DMSans_500Medium", fontSize: 14, color: "#2C1810" }}
                  numberOfLines={1}
                >
                  {primary}
                </Text>
                {secondary ? (
                  <Text
                    style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355", marginTop: 1 }}
                    numberOfLines={1}
                  >
                    {secondary}
                  </Text>
                ) : null}
              </Pressable>
            );
          })}
        </View>
      ) : null}
    </View>
  );
}
