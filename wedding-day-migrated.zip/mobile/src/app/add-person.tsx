import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Picker } from "@react-native-picker/picker";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { fetch as expoFetch } from "expo/fetch";
import { Camera } from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { ImportantPersonDTO, ImportantPersonCategory } from "@/lib/types";
import { IMPORTANT_PERSON_CATEGORIES, PERSON_CATEGORY_LABELS } from "@/lib/types";
import { QUERY_KEYS } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

const pickAndUploadPhoto = async (): Promise<string | null> => {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["images"],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.7,
  });
  if (result.canceled) return null;

  const asset = result.assets[0];
  const formData = new FormData();
  formData.append("file", { uri: asset.uri, type: "image/jpeg", name: "photo.jpg" } as any);

  const response = await expoFetch(`${process.env.EXPO_PUBLIC_BACKEND_URL}/api/upload`, {
    method: "POST",
    body: formData,
    credentials: "include",
  });
  const json = (await response.json()) as { data: { url: string } };
  return json.data.url;
};

export default function AddPersonScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { weddingId } = useLocalSearchParams<{ weddingId: string }>();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const resolvedWeddingId = weddingId ?? activeWeddingId ?? "";

  const [name, setName] = useState<string>("");
  const [relationship, setRelationship] = useState<string>("");
  const [category, setCategory] = useState<ImportantPersonCategory>("family");
  const [notes, setNotes] = useState<string>("");
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState<boolean>(false);

  const handlePickPhoto = async () => {
    setUploadingPhoto(true);
    try {
      const url = await pickAndUploadPhoto();
      if (url) setPhotoUrl(url);
    } catch {
      toast({ title: "Failed to upload photo", preset: "error" });
    } finally {
      setUploadingPhoto(false);
    }
  };

  const addMutation = useMutation({
    mutationFn: () =>
      api.post<ImportantPersonDTO>(`/api/weddings/${resolvedWeddingId}/important-people`, {
        name: name.trim(),
        relationship: relationship.trim(),
        category,
        notes: notes.trim() || undefined,
        photoUrl: photoUrl ?? undefined,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.people(resolvedWeddingId) });
      toast({ title: "Person added!", preset: "done" });
      router.back();
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const isValid = name.trim().length > 0 && relationship.trim().length > 0;

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="add-person-screen">
      <ScrollView
        contentContainerStyle={{ padding: 24, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Photo picker */}
        <View style={{ alignItems: "center", marginBottom: 24 }}>
          <Pressable
            testID="photo-picker-button"
            onPress={handlePickPhoto}
            disabled={uploadingPhoto}
            style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
          >
            {photoUrl ? (
              <Image
                source={{ uri: photoUrl }}
                style={{ width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: "#C9A84C" }}
                contentFit="cover"
              />
            ) : (
              <View
                style={{
                  width: 88,
                  height: 88,
                  borderRadius: 44,
                  backgroundColor: "#F5EDD8",
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 2,
                  borderColor: "#E8D5A0",
                  borderStyle: "dashed",
                }}
              >
                {uploadingPhoto ? (
                  <ActivityIndicator color="#C9A84C" />
                ) : (
                  <Camera size={28} color="#C9A84C" />
                )}
              </View>
            )}
          </Pressable>
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 12,
              color: "#8B7355",
              marginTop: 8,
            }}
          >
            {uploadingPhoto ? "Uploading…" : "Add Photo"}
          </Text>
        </View>

        {/* Name */}
        <FieldLabel>Full Name</FieldLabel>
        <TextInput
          testID="name-input"
          value={name}
          onChangeText={setName}
          placeholder="e.g. Margaret Smith"
          placeholderTextColor="#C8B8A2"
          style={inputStyle}
        />

        {/* Relationship */}
        <FieldLabel>Relationship</FieldLabel>
        <TextInput
          testID="relationship-input"
          value={relationship}
          onChangeText={setRelationship}
          placeholder="e.g. Mother of the Bride"
          placeholderTextColor="#C8B8A2"
          style={inputStyle}
        />

        {/* Category */}
        <FieldLabel>Category</FieldLabel>
        <View
          style={{
            borderWidth: 1,
            borderColor: "#E8E0D5",
            borderRadius: 12,
            backgroundColor: "#FFFFFF",
            marginBottom: 20,
            overflow: "hidden",
          }}
        >
          <Picker
            testID="category-picker"
            selectedValue={category}
            onValueChange={(v) => setCategory(v as ImportantPersonCategory)}
            style={{ color: "#2C1810" }}
          >
            {IMPORTANT_PERSON_CATEGORIES.map((c) => (
              <Picker.Item key={c} label={PERSON_CATEGORY_LABELS[c]} value={c} />
            ))}
          </Picker>
        </View>

        {/* Notes */}
        <FieldLabel>Notes (optional)</FieldLabel>
        <TextInput
          testID="notes-input"
          value={notes}
          onChangeText={setNotes}
          placeholder="Dietary needs, photo preferences, anything the team should know…"
          placeholderTextColor="#C8B8A2"
          multiline
          numberOfLines={4}
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            padding: 14,
            fontFamily: "DMSans_400Regular",
            fontSize: 15,
            color: "#2C1810",
            minHeight: 100,
            textAlignVertical: "top",
            marginBottom: 8,
          }}
        />
      </ScrollView>

      {/* Submit */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E8E0D5",
          padding: 20,
          paddingBottom: 36,
        }}
      >
        <Pressable
          testID="add-person-button"
          onPress={() => addMutation.mutate()}
          disabled={!isValid || addMutation.isPending || uploadingPhoto}
          style={({ pressed }) => ({
            backgroundColor: isValid ? "#C9A84C" : "#D4C090",
            borderRadius: 100,
            paddingVertical: 16,
            alignItems: "center",
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#FFFFFF" }}>
            {addMutation.isPending ? "Adding…" : "Add Person"}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function FieldLabel({ children }: { children: string }) {
  return (
    <Text
      style={{
        fontFamily: "DMSans_500Medium",
        fontSize: 11,
        color: "#8B7355",
        letterSpacing: 1,
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );
}

const inputStyle = {
  fontFamily: "DMSans_400Regular" as const,
  fontSize: 16,
  color: "#2C1810",
  borderBottomWidth: 1.5,
  borderBottomColor: "#E8E0D5",
  paddingVertical: 10,
  marginBottom: 20,
};
