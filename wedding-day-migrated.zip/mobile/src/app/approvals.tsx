import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import { CheckCircle, XCircle, Clock } from "lucide-react-native";
import { api } from "@/lib/api/api";
import type { ChangeRequestDTO, WeddingDetailDTO } from "@/lib/types";
import { QUERY_KEYS, formatTime } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

export default function ApprovalsScreen() {
  const queryClient = useQueryClient();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const weddingId = activeWeddingId ?? "";

  const { data: requests, isLoading } = useQuery({
    queryKey: QUERY_KEYS.changeRequests(weddingId),
    queryFn: () =>
      api.get<ChangeRequestDTO[]>(`/api/weddings/${weddingId}/change-requests?status=pending`),
    enabled: !!weddingId,
  });

  const { data: wedding } = useQuery({
    queryKey: QUERY_KEYS.wedding(weddingId),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${weddingId}`),
    enabled: !!weddingId,
  });

  const approveMutation = useMutation({
    mutationFn: (requestId: string) =>
      api.post<ChangeRequestDTO>(
        `/api/weddings/${weddingId}/change-requests/${requestId}/approve`
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.changeRequests(weddingId) });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(weddingId) });
      toast({ title: "Approved!", preset: "done" });
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (requestId: string) =>
      api.post<ChangeRequestDTO>(
        `/api/weddings/${weddingId}/change-requests/${requestId}/reject`
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.changeRequests(weddingId) });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(weddingId) });
      toast({ title: "Rejected", preset: "error" });
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const events = wedding?.events ?? [];
  const getEventTitle = (eventId: string) =>
    events.find((e) => e.id === eventId)?.title ?? "Event";

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  const pendingRequests = requests ?? [];

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="approvals-screen">
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        {pendingRequests.length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: 80 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: "#F5EDD8",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 20,
              }}
            >
              <CheckCircle size={40} color="#C9A84C" />
            </View>
            <Text
              style={{
                fontFamily: "PlayfairDisplay_700Bold",
                fontSize: 24,
                color: "#2C1810",
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              All caught up!
            </Text>
            <Text
              style={{
                fontFamily: "DMSans_400Regular",
                fontSize: 14,
                color: "#8B7355",
                textAlign: "center",
              }}
            >
              No pending adjustment requests
            </Text>
          </View>
        ) : (
          <>
            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1,
                textTransform: "uppercase",
                marginBottom: 14,
              }}
            >
              {pendingRequests.length} Pending {pendingRequests.length === 1 ? "Request" : "Requests"}
            </Text>
            {pendingRequests.map((req) => (
              <RequestCard
                key={req.id}
                request={req}
                eventTitle={getEventTitle(req.eventId)}
                onApprove={() => approveMutation.mutate(req.id)}
                onReject={() => rejectMutation.mutate(req.id)}
                isLoading={approveMutation.isPending || rejectMutation.isPending}
              />
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function RequestCard({
  request,
  eventTitle,
  onApprove,
  onReject,
  isLoading,
}: {
  request: ChangeRequestDTO;
  eventTitle: string;
  onApprove: () => void;
  onReject: () => void;
  isLoading: boolean;
}) {
  return (
    <View
      testID={`request-card-${request.id}`}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 18,
        marginBottom: 14,
        borderWidth: 1,
        borderColor: "#E8E0D5",
        shadowColor: "#2C1810",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.06,
        shadowRadius: 8,
        elevation: 2,
      }}
    >
      {/* Event title */}
      <Text
        style={{
          fontFamily: "PlayfairDisplay_700Bold",
          fontSize: 18,
          color: "#2C1810",
          marginBottom: 4,
        }}
      >
        {eventTitle}
      </Text>

      {/* Requested by */}
      <Text
        style={{
          fontFamily: "DMSans_400Regular",
          fontSize: 12,
          color: "#8B7355",
          marginBottom: 14,
        }}
      >
        Requested by {request.requestedByName}
      </Text>

      {/* Time change */}
      {(request.proposedStartTime || request.proposedEndTime) ? (
        <View
          style={{
            backgroundColor: "#FDF8EE",
            borderRadius: 10,
            padding: 12,
            marginBottom: 12,
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            flexWrap: "wrap",
          }}
        >
          <Clock size={14} color="#C9A84C" />
          {request.proposedStartTime ? (
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#2C1810" }}>
              {formatTime(request.proposedStartTime)}
            </Text>
          ) : null}
          {request.proposedStartTime && request.proposedEndTime ? (
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>→</Text>
          ) : null}
          {request.proposedEndTime ? (
            <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 13, color: "#2C1810" }}>
              {formatTime(request.proposedEndTime)}
            </Text>
          ) : null}
        </View>
      ) : null}

      {/* Reason */}
      {request.reason ? (
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 13,
            color: "#8B7355",
            fontStyle: "italic",
            marginBottom: 14,
            lineHeight: 19,
          }}
        >
          "{request.reason}"
        </Text>
      ) : null}

      {/* Actions */}
      <View style={{ flexDirection: "row", gap: 10 }}>
        <Pressable
          testID={`reject-${request.id}`}
          onPress={onReject}
          disabled={isLoading}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            borderWidth: 1.5,
            borderColor: "#E8474B",
            borderRadius: 100,
            paddingVertical: 12,
            opacity: pressed || isLoading ? 0.7 : 1,
          })}
        >
          <XCircle size={16} color="#E8474B" />
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#E8474B" }}>
            Reject
          </Text>
        </Pressable>
        <Pressable
          testID={`approve-${request.id}`}
          onPress={onApprove}
          disabled={isLoading}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            backgroundColor: "#059669",
            borderRadius: 100,
            paddingVertical: 12,
            opacity: pressed || isLoading ? 0.7 : 1,
          })}
        >
          <CheckCircle size={16} color="#FFFFFF" />
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 14, color: "#FFFFFF" }}>
            Approve
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
