import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Plus, LogIn, LogOut, CalendarDays, MapPin } from "lucide-react-native";
import { api } from "@/lib/api/api";
import { authClient } from "@/lib/auth-client";
import type { WeddingWithRoleDTO, WeddingDTO } from "@/lib/types";
import { QUERY_KEYS, formatDate } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { toast } from "burnt";

const ROLE_LABELS: Record<string, string> = {
  admin: "Admin",
  couple: "Couple",
  vendor: "Vendor",
};

export default function WeddingSelectScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const setActiveWeddingId = useWeddingStore((s) => s.setActiveWeddingId);

  const [mode, setMode] = useState<"none" | "create" | "join">("none");
  const [inviteCode, setInviteCode] = useState<string>("");

  // Create form state
  const [partner1, setPartner1] = useState<string>("");
  const [partner2, setPartner2] = useState<string>("");
  const [weddingDate, setWeddingDate] = useState<Date>(new Date());
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);
  const [venueName, setVenueName] = useState<string>("");

  const { data: weddings, isLoading } = useQuery({
    queryKey: QUERY_KEYS.weddings,
    queryFn: () => api.get<WeddingWithRoleDTO[]>("/api/weddings"),
  });

  const selectWedding = (id: string) => {
    setActiveWeddingId(id);
    router.replace("/(tabs)/timeline");
  };

  const createMutation = useMutation({
    mutationFn: () =>
      api.post<WeddingDTO>("/api/weddings", {
        partner1Name: partner1.trim(),
        partner2Name: partner2.trim(),
        weddingDate: weddingDate.toISOString(),
        venueName: venueName.trim() || undefined,
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.weddings });
      setActiveWeddingId(data.id);
      router.replace("/(tabs)/timeline");
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const joinMutation = useMutation({
    mutationFn: () =>
      api.post<WeddingWithRoleDTO>("/api/weddings/join", { inviteCode: inviteCode.trim().toUpperCase() }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.weddings });
      setActiveWeddingId(data.id);
      router.replace("/(tabs)/timeline");
    },
    onError: (err: Error) => {
      toast({ title: err.message, preset: "error" });
    },
  });

  const signOutMutation = useMutation({
    mutationFn: () => authClient.signOut(),
    onSuccess: () => {
      setActiveWeddingId(null);
      router.replace("/sign-in");
    },
  });

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FAF7F2" }}>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 24, paddingVertical: 40 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={{ alignItems: "center", marginBottom: 40 }}>
          <Text
            style={{
              fontFamily: "PlayfairDisplay_700Bold",
              fontSize: 36,
              color: "#C9A84C",
              letterSpacing: 0.5,
            }}
          >
            Wedding Day
          </Text>
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 15,
              color: "#8B7355",
              marginTop: 4,
            }}
          >
            Planners create · Everyone else joins
          </Text>
        </View>

        {/* Existing weddings */}
        {isLoading ? (
          <ActivityIndicator color="#C9A84C" style={{ marginBottom: 24 }} />
        ) : weddings && weddings.length > 0 ? (
          <View style={{ marginBottom: 24 }}>
            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1,
                textTransform: "uppercase",
                marginBottom: 12,
              }}
            >
              Your Weddings
            </Text>
            {weddings.map((w) => (
              <Pressable
                testID={`wedding-card-${w.id}`}
                key={w.id}
                onPress={() => selectWedding(w.id)}
                style={({ pressed }) => ({
                  backgroundColor: "#FFFFFF",
                  borderRadius: 16,
                  padding: 20,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor: "#E8E0D5",
                  opacity: pressed ? 0.85 : 1,
                  shadowColor: "#2C1810",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.06,
                  shadowRadius: 8,
                  elevation: 2,
                })}
              >
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <Text
                    style={{
                      fontFamily: "PlayfairDisplay_700Bold",
                      fontSize: 20,
                      color: "#2C1810",
                      flex: 1,
                    }}
                  >
                    {w.partner1Name} & {w.partner2Name}
                  </Text>
                  <View
                    style={{
                      backgroundColor:
                        w.myRole === "admin" ? "#F5EDD8" : w.myRole === "vendor" ? "#E8F0F8" : "#FCE8E8",
                      borderRadius: 100,
                      paddingHorizontal: 10,
                      paddingVertical: 4,
                    }}
                  >
                    <Text
                      style={{
                        fontFamily: "DMSans_500Medium",
                        fontSize: 11,
                        color:
                          w.myRole === "admin" ? "#C9A84C" : w.myRole === "vendor" ? "#3B82F6" : "#E8474B",
                      }}
                    >
                      {ROLE_LABELS[w.myRole] ?? w.myRole}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", marginTop: 8, gap: 6 }}>
                  <CalendarDays size={14} color="#8B7355" />
                  <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                    {formatDate(w.weddingDate)}
                  </Text>
                </View>
                {w.venueName ? (
                  <View style={{ flexDirection: "row", alignItems: "center", marginTop: 4, gap: 6 }}>
                    <MapPin size={14} color="#8B7355" />
                    <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
                      {w.venueName}
                    </Text>
                  </View>
                ) : null}
              </Pressable>
            ))}
          </View>
        ) : null}

        {/* Divider */}
        {weddings && weddings.length > 0 ? (
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 24, gap: 12 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: "#E8E0D5" }} />
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>or</Text>
            <View style={{ flex: 1, height: 1, backgroundColor: "#E8E0D5" }} />
          </View>
        ) : null}

        {/* Action buttons */}
        <View style={{ gap: 12, marginBottom: 24 }}>
          <Pressable
            testID="create-wedding-button"
            onPress={() => setMode(mode === "create" ? "none" : "create")}
            style={({ pressed }) => ({
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: mode === "create" ? "#C9A84C" : "#FFFFFF",
              borderWidth: 1.5,
              borderColor: "#C9A84C",
              borderRadius: 14,
              paddingVertical: 16,
              gap: 8,
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <Plus size={18} color={mode === "create" ? "#FFFFFF" : "#C9A84C"} />
            <Text
              style={{
                fontFamily: "DMSans_600SemiBold",
                fontSize: 15,
                color: mode === "create" ? "#FFFFFF" : "#C9A84C",
              }}
            >
              Create a Wedding
            </Text>
          </Pressable>

          <Pressable
            testID="join-wedding-button"
            onPress={() => setMode(mode === "join" ? "none" : "join")}
            style={({ pressed }) => ({
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: mode === "join" ? "#2C1810" : "#FFFFFF",
              borderWidth: 1.5,
              borderColor: "#2C1810",
              borderRadius: 14,
              paddingVertical: 16,
              gap: 8,
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <LogIn size={18} color={mode === "join" ? "#FFFFFF" : "#2C1810"} />
            <Text
              style={{
                fontFamily: "DMSans_600SemiBold",
                fontSize: 15,
                color: mode === "join" ? "#FFFFFF" : "#2C1810",
              }}
            >
              Join with Invite Code
            </Text>
          </Pressable>
        </View>

        {/* Create form */}
        {mode === "create" ? (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: "#E8E0D5",
              marginBottom: 24,
              gap: 16,
            }}
          >
            <Text
              style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 18, color: "#2C1810", marginBottom: 4 }}
            >
              Create a Wedding
            </Text>

            <FormField label="Partner 1 Name">
              <TextInput
                testID="partner1-input"
                value={partner1}
                onChangeText={setPartner1}
                placeholder="e.g. Sarah"
                placeholderTextColor="#C8B8A2"
                style={inputStyle}
              />
            </FormField>

            <FormField label="Partner 2 Name">
              <TextInput
                testID="partner2-input"
                value={partner2}
                onChangeText={setPartner2}
                placeholder="e.g. James"
                placeholderTextColor="#C8B8A2"
                style={inputStyle}
              />
            </FormField>

            <FormField label="Wedding Date">
              <Pressable
                testID="date-picker-button"
                onPress={() => setShowDatePicker(true)}
                style={{
                  borderBottomWidth: 1.5,
                  borderBottomColor: "#E8E0D5",
                  paddingVertical: 10,
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 16, color: "#2C1810" }}>
                  {formatDate(weddingDate.toISOString())}
                </Text>
                <CalendarDays size={16} color="#8B7355" />
              </Pressable>
              {showDatePicker ? (
                <DateTimePicker
                  testID="date-time-picker"
                  value={weddingDate}
                  mode="date"
                  display={Platform.OS === "ios" ? "inline" : "default"}
                  minimumDate={new Date()}
                  onChange={(_, date) => {
                    setShowDatePicker(Platform.OS === "ios");
                    if (date) setWeddingDate(date);
                  }}
                />
              ) : null}
            </FormField>

            <FormField label="Venue Name (optional)">
              <TextInput
                testID="venue-input"
                value={venueName}
                onChangeText={setVenueName}
                placeholder="Grand Ballroom, Central Park…"
                placeholderTextColor="#C8B8A2"
                style={inputStyle}
              />
            </FormField>

            <Pressable
              testID="create-submit-button"
              onPress={() => createMutation.mutate()}
              disabled={!partner1.trim() || !partner2.trim() || createMutation.isPending}
              style={({ pressed }) => ({
                backgroundColor: partner1.trim() && partner2.trim() ? "#C9A84C" : "#D4C090",
                borderRadius: 100,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                {createMutation.isPending ? "Creating…" : "Create Wedding"}
              </Text>
            </Pressable>
          </View>
        ) : null}

        {/* Join form */}
        {mode === "join" ? (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: "#E8E0D5",
              marginBottom: 24,
              gap: 16,
            }}
          >
            <Text
              style={{ fontFamily: "PlayfairDisplay_700Bold", fontSize: 18, color: "#2C1810", marginBottom: 4 }}
            >
              Join a Wedding
            </Text>

            <FormField label="8-Character Invite Code">
              <TextInput
                testID="invite-code-input"
                value={inviteCode}
                onChangeText={(t) => setInviteCode(t.toUpperCase())}
                placeholder="ABC12345"
                placeholderTextColor="#C8B8A2"
                autoCapitalize="characters"
                maxLength={8}
                style={{ ...inputStyle, fontFamily: "PlayfairDisplay_700Bold", letterSpacing: 4 }}
              />
            </FormField>

            <Pressable
              testID="join-submit-button"
              onPress={() => joinMutation.mutate()}
              disabled={inviteCode.trim().length !== 8 || joinMutation.isPending}
              style={({ pressed }) => ({
                backgroundColor: inviteCode.trim().length === 8 ? "#2C1810" : "#8B7355",
                borderRadius: 100,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
                {joinMutation.isPending ? "Joining…" : "Join Wedding"}
              </Text>
            </Pressable>
          </View>
        ) : null}

        {/* Sign out */}
        <Pressable
          testID="sign-out-button"
          onPress={() => signOutMutation.mutate()}
          style={{ alignItems: "center", marginTop: 8, paddingVertical: 12 }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <LogOut size={14} color="#8B7355" />
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 13, color: "#8B7355" }}>
              Sign out
            </Text>
          </View>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View>
      <Text
        style={{
          fontFamily: "DMSans_500Medium",
          fontSize: 11,
          color: "#8B7355",
          letterSpacing: 1,
          textTransform: "uppercase",
          marginBottom: 6,
        }}
      >
        {label}
      </Text>
      {children}
    </View>
  );
}

const inputStyle = {
  fontFamily: "DMSans_400Regular" as const,
  fontSize: 16,
  color: "#2C1810",
  borderBottomWidth: 1.5,
  borderBottomColor: "#E8E0D5",
  paddingVertical: 10,
};
