import { useState } from "react";
import { View, Text, Pressable, ActivityIndicator } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api/api";
import type { WeddingDetailDTO, TimelineEventDTO } from "@/lib/types";
import { QUERY_KEYS, formatTime } from "@/lib/utils";
import { toast } from "burnt";
import { ChevronRight } from "lucide-react-native";

const PUSH_OPTIONS = [
  { label: "+5 min", minutes: 5 },
  { label: "+10 min", minutes: 10 },
  { label: "+15 min", minutes: 15 },
  { label: "+20 min", minutes: 20 },
];

export default function QuickAdjustScreen() {
  const { eventId, weddingId } = useLocalSearchParams<{ eventId: string; weddingId: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [selectedMinutes, setSelectedMinutes] = useState<number | null>(null);

  const wedding = queryClient.getQueryData<WeddingDetailDTO>(
    QUERY_KEYS.wedding(weddingId ?? "")
  );
  const event = wedding?.events?.find((e) => e.id === eventId);
  const isAdmin = wedding?.myRole === "admin";

  const adjustMutation = useMutation({
    mutationFn: async (minutes: number) => {
      if (!event || !weddingId || !eventId) throw new Error("Missing data");
      const newStart = new Date(event.startTime);
      newStart.setMinutes(newStart.getMinutes() + minutes);
      const newEnd = new Date(event.endTime);
      newEnd.setMinutes(newEnd.getMinutes() + minutes);

      return api.post(`/api/weddings/${weddingId}/events/${eventId}/adjust`, {
        proposedStartTime: newStart.toISOString(),
        proposedEndTime: newEnd.toISOString(),
        reason: `Pushed ${minutes} minutes`,
      });
    },
    onSuccess: (_, minutes) => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.wedding(weddingId ?? "") });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.events(weddingId ?? "") });
      if (isAdmin) {
        toast({ title: `Pushed ${minutes} min`, message: "Timeline updated", preset: "done" });
      } else {
        toast({ title: "Request sent", message: "Waiting for admin approval", preset: "done" });
      }
      router.back();
    },
    onError: (err: Error) => {
      toast({ title: "Failed", message: err.message, preset: "error" });
    },
  });

  const handlePush = (minutes: number) => {
    setSelectedMinutes(minutes);
    adjustMutation.mutate(minutes);
  };

  if (!event) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator color="#C9A84C" />
      </View>
    );
  }

  const newTimes = (minutes: number) => {
    const s = new Date(event.startTime);
    s.setMinutes(s.getMinutes() + minutes);
    const e2 = new Date(event.endTime);
    e2.setMinutes(e2.getMinutes() + minutes);
    return `${formatTime(s.toISOString())} – ${formatTime(e2.toISOString())}`;
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2", padding: 24 }}>
      {/* Event info */}
      <View
        style={{
          backgroundColor: "#FFFFFF",
          borderRadius: 16,
          padding: 18,
          borderWidth: 1,
          borderColor: "#E8E0D5",
          marginBottom: 28,
        }}
      >
        <Text
          style={{
            fontFamily: "PlayfairDisplay_700Bold",
            fontSize: 20,
            color: "#2C1810",
            marginBottom: 6,
          }}
        >
          {event.title}
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 14,
            color: "#8B7355",
          }}
        >
          Currently {formatTime(event.startTime)} – {formatTime(event.endTime)}
        </Text>
      </View>

      {/* Context label */}
      <Text
        style={{
          fontFamily: "DMSans_500Medium",
          fontSize: 11,
          color: "#8B7355",
          letterSpacing: 1,
          textTransform: "uppercase",
          marginBottom: 14,
        }}
      >
        {isAdmin ? "Push event by" : "Request to push by"}
      </Text>

      {/* Push buttons 2x2 grid */}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 12, marginBottom: 28 }}>
        {PUSH_OPTIONS.map(({ label, minutes }) => {
          const isLoading = adjustMutation.isPending && selectedMinutes === minutes;
          return (
            <Pressable
              testID={`push-${minutes}-button`}
              key={minutes}
              onPress={() => handlePush(minutes)}
              disabled={adjustMutation.isPending}
              style={({ pressed }) => ({
                flex: 1,
                minWidth: "44%",
                backgroundColor: isLoading ? "#C9A84C" : "#FFFFFF",
                borderRadius: 16,
                borderWidth: 1.5,
                borderColor: "#C9A84C",
                paddingVertical: 20,
                alignItems: "center",
                opacity: pressed || (adjustMutation.isPending && !isLoading) ? 0.6 : 1,
                shadowColor: "#C9A84C",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 2,
              })}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFFFFF" size="small" />
              ) : (
                <>
                  <Text
                    style={{
                      fontFamily: "PlayfairDisplay_700Bold",
                      fontSize: 22,
                      color: "#C9A84C",
                      marginBottom: 4,
                    }}
                  >
                    {label}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "DMSans_400Regular",
                      fontSize: 11,
                      color: "#8B7355",
                    }}
                  >
                    {newTimes(minutes)}
                  </Text>
                </>
              )}
            </Pressable>
          );
        })}
      </View>

      {/* Admin note / vendor note */}
      <Text
        style={{
          fontFamily: "DMSans_400Regular",
          fontSize: 12,
          color: "#8B7355",
          textAlign: "center",
          marginBottom: 24,
        }}
      >
        {isAdmin
          ? "As admin, changes apply immediately to the timeline."
          : "Your request will be sent to the admin for approval."}
      </Text>

      {/* View full details */}
      <Pressable
        testID="view-details-button"
        onPress={() =>
          router.replace({
            pathname: "/event-detail",
            params: { eventId: eventId ?? "", weddingId: weddingId ?? "" },
          })
        }
        style={({ pressed }) => ({
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
          opacity: pressed ? 0.6 : 1,
          paddingVertical: 8,
        })}
      >
        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 14, color: "#C9A84C" }}>
          View full event details
        </Text>
        <ChevronRight size={14} color="#C9A84C" />
      </Pressable>
    </View>
  );
}
