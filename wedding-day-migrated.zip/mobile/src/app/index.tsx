import { Redirect } from "expo-router";
import { authClient } from "@/lib/auth-client";
import useWeddingStore from "@/lib/state/wedding-store";
import { View, ActivityIndicator } from "react-native";

export default function Index() {
  const { data: session, isPending } = authClient.useSession();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);

  if (isPending) {
    return (
      <View
        testID="loading-indicator"
        style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}
      >
        <ActivityIndicator color="#C9A84C" />
      </View>
    );
  }
  if (!session) return <Redirect href="/sign-in" />;
  if (!activeWeddingId) return <Redirect href="/wedding-select" />;
  return <Redirect href="/(tabs)/timeline" />;
}
