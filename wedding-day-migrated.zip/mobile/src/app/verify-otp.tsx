import { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { authClient } from "@/lib/auth-client";
import { OtpInput } from "react-native-otp-entry";
import { SafeAreaView } from "react-native-safe-area-context";
import { api } from "@/lib/api/api";
import type { UserProfileDTO } from "@/lib/types";
import { QUERY_KEYS } from "@/lib/utils";
import { Mail } from "lucide-react-native";

export default function VerifyOtpScreen() {
  const { email } = useLocalSearchParams<{ email: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [otp, setOtp] = useState<string>("");
  const [countdown, setCountdown] = useState<number>(30);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    startCountdown();
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const startCountdown = () => {
    setCountdown(30);
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const resendMutation = useMutation({
    mutationFn: async () => {
      const result = await (authClient as any).emailOtp.sendVerificationOtp({
        email: email ?? "",
        type: "sign-in",
      });
      if (result?.error) throw new Error(result.error.message ?? "Failed to resend");
    },
    onSuccess: () => {
      setError(null);
      startCountdown();
    },
    onError: (err: Error) => {
      setError(err.message);
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async (code: string) => {
      const result = await (authClient as any).signIn.emailOtp({
        email: email ?? "",
        otp: code,
      });
      if (result?.error) throw new Error(result.error.message ?? "Invalid code");
      return result;
    },
    onSuccess: async () => {
      setError(null);
      try {
        const profile = await api.get<UserProfileDTO>("/api/me");
        queryClient.setQueryData(QUERY_KEYS.me, profile);
        const isNewUser = !profile.displayName || profile.displayName === profile.name;
        if (isNewUser) {
          router.replace("/setup-profile");
        } else {
          router.replace("/wedding-select");
        }
      } catch {
        router.replace("/wedding-select");
      }
    },
    onError: (err: Error) => {
      setError(err.message);
    },
  });

  const handleOtpFilled = (code: string) => {
    setOtp(code);
    verifyMutation.mutate(code);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FAF7F2" }}>
      <View style={{ flex: 1, paddingHorizontal: 32, paddingTop: 60 }}>
        {/* Back */}
        <Pressable
          testID="back-button"
          onPress={() => router.back()}
          style={{ marginBottom: 40 }}
        >
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "#C9A84C" }}>
            ← Back
          </Text>
        </Pressable>

        {/* Icon */}
        <View style={{ alignItems: "center", marginBottom: 28 }}>
          <View
            style={{
              width: 72,
              height: 72,
              borderRadius: 36,
              backgroundColor: "#F5EDD8",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Mail size={32} color="#C9A84C" />
          </View>
        </View>

        {/* Heading */}
        <Text
          style={{
            fontFamily: "PlayfairDisplay_700Bold",
            fontSize: 30,
            color: "#2C1810",
            textAlign: "center",
            marginBottom: 10,
          }}
        >
          Check your email
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 15,
            color: "#8B7355",
            textAlign: "center",
            marginBottom: 8,
          }}
        >
          We sent a 6-digit code to
        </Text>
        <Text
          style={{
            fontFamily: "DMSans_600SemiBold",
            fontSize: 15,
            color: "#2C1810",
            textAlign: "center",
            marginBottom: 40,
          }}
        >
          {email}
        </Text>

        {/* OTP Input */}
        <View testID="otp-input">
          <OtpInput
            numberOfDigits={6}
            onFilled={handleOtpFilled}
            focusColor="#C9A84C"
            theme={{
              pinCodeContainerStyle: {
                borderBottomWidth: 2,
                borderBottomColor: "#E8E0D5",
                borderTopWidth: 0,
                borderLeftWidth: 0,
                borderRightWidth: 0,
                borderRadius: 0,
                minWidth: 40,
                height: 52,
              },
              focusedPinCodeContainerStyle: {
                borderBottomColor: "#C9A84C",
              },
              filledPinCodeContainerStyle: {
                borderBottomColor: "#C9A84C",
              },
              pinCodeTextStyle: {
                fontFamily: "PlayfairDisplay_700Bold",
                fontSize: 26,
                color: "#2C1810",
              },
            }}
          />
        </View>

        {/* Error */}
        {error ? (
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 13,
              color: "#D4453F",
              textAlign: "center",
              marginTop: 16,
            }}
          >
            {error}
          </Text>
        ) : null}

        {/* Loading */}
        {verifyMutation.isPending ? (
          <Text
            style={{
              fontFamily: "DMSans_400Regular",
              fontSize: 13,
              color: "#8B7355",
              textAlign: "center",
              marginTop: 16,
            }}
          >
            Verifying…
          </Text>
        ) : null}

        {/* Resend */}
        <View style={{ flexDirection: "row", justifyContent: "center", marginTop: 36, gap: 4 }}>
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 14, color: "#8B7355" }}>
            Didn't get it?
          </Text>
          {countdown > 0 ? (
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 14, color: "#8B7355" }}>
              Resend in {countdown}s
            </Text>
          ) : (
            <Pressable
              testID="resend-button"
              onPress={() => resendMutation.mutate()}
              disabled={resendMutation.isPending}
            >
              <Text
                style={{
                  fontFamily: "DMSans_600SemiBold",
                  fontSize: 14,
                  color: "#C9A84C",
                }}
              >
                {resendMutation.isPending ? "Sending…" : "Resend code"}
              </Text>
            </Pressable>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}
