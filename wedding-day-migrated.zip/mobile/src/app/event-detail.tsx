import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  MapPin,
  Clock,
  Users,
  Sparkles,
  Heart,
  Gem,
  Wine,
  Music,
  Star,
  Car,
  Calendar,
} from "lucide-react-native";
import { api } from "@/lib/api/api";
import { AddressNavigator } from "@/components/AddressNavigator";
import type { WeddingDetailDTO, EventCategory } from "@/lib/types";
import { EVENT_CATEGORY_LABELS } from "@/lib/types";
import { QUERY_KEYS, formatTime, getInitials } from "@/lib/utils";
import useWeddingStore from "@/lib/state/wedding-store";
import { differenceInMinutes } from "date-fns";

function CategoryIcon({ category, size, color }: { category: EventCategory; size: number; color: string }) {
  const props = { size, color };
  switch (category) {
    case "gettingReady": return <Sparkles {...props} />;
    case "firstLook": return <Heart {...props} />;
    case "ceremony": return <Gem {...props} />;
    case "cocktail": return <Wine {...props} />;
    case "reception": return <Music {...props} />;
    case "sendOff": return <Star {...props} />;
    case "travel": return <Car {...props} />;
    default: return <Calendar {...props} />;
  }
}

function formatDuration(startIso: string, endIso: string): string {
  const mins = differenceInMinutes(new Date(endIso), new Date(startIso));
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h} hr ${m} min` : `${h} hr`;
}

const AVATAR_COLORS = ["#C9A84C", "#E8C4C4", "#8B7355", "#A8C5DA", "#B5A99A"];
function getAvatarColor(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export default function EventDetailScreen() {
  const router = useRouter();
  const { eventId, weddingId } = useLocalSearchParams<{ eventId: string; weddingId: string }>();
  const activeWeddingId = useWeddingStore((s) => s.activeWeddingId);
  const resolvedWeddingId = weddingId ?? activeWeddingId ?? "";

  const { data: wedding, isLoading } = useQuery({
    queryKey: QUERY_KEYS.wedding(resolvedWeddingId),
    queryFn: () => api.get<WeddingDetailDTO>(`/api/weddings/${resolvedWeddingId}`),
    enabled: !!resolvedWeddingId,
  });

  const event = wedding?.events?.find((e) => e.id === eventId);
  const isAdmin = wedding?.myRole === "admin";

  const assignedMembers = (wedding?.members ?? []).filter((m) =>
    event?.assignedVendorIds.includes(m.userId)
  );

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <ActivityIndicator testID="loading-indicator" color="#C9A84C" />
      </View>
    );
  }

  if (!event) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#FAF7F2" }}>
        <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 15, color: "#8B7355" }}>
          Event not found
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#FAF7F2" }} testID="event-detail-screen">
      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 120 }}>
        {/* Category badge */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 12,
              backgroundColor: "#FDF8EE",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <CategoryIcon category={event.category} size={20} color="#C9A84C" />
          </View>
          <Text
            style={{
              fontFamily: "DMSans_500Medium",
              fontSize: 12,
              color: "#8B7355",
              letterSpacing: 1,
              textTransform: "uppercase",
            }}
          >
            {EVENT_CATEGORY_LABELS[event.category]}
          </Text>
        </View>

        {/* Title */}
        <Text
          style={{
            fontFamily: "PlayfairDisplay_700Bold",
            fontSize: 30,
            color: "#2C1810",
            lineHeight: 36,
            marginBottom: 20,
          }}
        >
          {event.title}
        </Text>

        {/* Time info */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 14,
            padding: 16,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: "#E8E0D5",
            gap: 12,
          }}
        >
          <InfoRow
            icon={<Clock size={16} color="#C9A84C" />}
            label="Time"
            value={`${formatTime(event.startTime)} – ${formatTime(event.endTime)}`}
          />
          <InfoRow
            icon={<Clock size={16} color="#8B7355" />}
            label="Duration"
            value={formatDuration(event.startTime, event.endTime)}
          />
          {event.locationName ? (
            <InfoRow
              icon={<MapPin size={16} color="#C9A84C" />}
              label="Location"
              value={event.locationName}
              address={event.address ?? undefined}
            />
          ) : null}
        </View>

        {/* Description */}
        {event.description ? (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 14,
              padding: 16,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#E8E0D5",
            }}
          >
            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1,
                textTransform: "uppercase",
                marginBottom: 8,
              }}
            >
              Notes
            </Text>
            <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 14, color: "#2C1810", lineHeight: 22 }}>
              {event.description}
            </Text>
          </View>
        ) : null}

        {/* Assigned vendors */}
        {assignedMembers.length > 0 ? (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 14,
              padding: 16,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#E8E0D5",
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Users size={14} color="#8B7355" />
              <Text
                style={{
                  fontFamily: "DMSans_500Medium",
                  fontSize: 11,
                  color: "#8B7355",
                  letterSpacing: 1,
                  textTransform: "uppercase",
                }}
              >
                Assigned Vendors
              </Text>
            </View>
            {assignedMembers.map((m) => {
              const name = m.user.displayName || m.user.name;
              return (
                <View key={m.id} style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <View
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 16,
                      backgroundColor: getAvatarColor(name),
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 12, color: "#FFFFFF" }}>
                      {getInitials(name)}
                    </Text>
                  </View>
                  <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 14, color: "#2C1810" }}>
                    {name}
                  </Text>
                </View>
              );
            })}
          </View>
        ) : null}
      </ScrollView>

      {/* Sticky action bar */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E8E0D5",
          padding: 20,
          paddingBottom: 36,
          flexDirection: "row",
          gap: 12,
        }}
      >
        {isAdmin ? (
          <Pressable
            testID="edit-event-button"
            onPress={() =>
              router.push({
                pathname: "/adjust-event",
                params: { eventId: event.id, weddingId: resolvedWeddingId },
              })
            }
            style={({ pressed }) => ({
              flex: 1,
              borderWidth: 1.5,
              borderColor: "#C9A84C",
              borderRadius: 100,
              paddingVertical: 14,
              alignItems: "center",
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#C9A84C" }}>
              Edit Time
            </Text>
          </Pressable>
        ) : null}
        <Pressable
          testID="adjust-event-button"
          onPress={() =>
            router.push({
              pathname: "/adjust-event",
              params: { eventId: event.id, weddingId: resolvedWeddingId },
            })
          }
          style={({ pressed }) => ({
            flex: 1,
            backgroundColor: "#C9A84C",
            borderRadius: 100,
            paddingVertical: 14,
            alignItems: "center",
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text style={{ fontFamily: "DMSans_600SemiBold", fontSize: 15, color: "#FFFFFF" }}>
            {isAdmin ? "Adjust Time" : "Propose Adjustment"}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function InfoRow({
  icon,
  label,
  value,
  sub,
  address,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  address?: string;
}) {
  return (
    <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 10 }}>
      <View style={{ marginTop: 1 }}>{icon}</View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 11, color: "#8B7355", marginBottom: 1 }}>
          {label}
        </Text>
        <Text style={{ fontFamily: "DMSans_500Medium", fontSize: 14, color: "#2C1810" }}>
          {value}
        </Text>
        {address ? (
          <AddressNavigator address={address} locationName={value} />
        ) : sub ? (
          <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#8B7355", marginTop: 1 }}>
            {sub}
          </Text>
        ) : null}
      </View>
    </View>
  );
}
