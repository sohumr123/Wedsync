import { fetch } from "expo/fetch";
import { authClient } from "../auth-client";

interface ApiResponse<T> { data: T; }
const baseUrl = process.env.EXPO_PUBLIC_BACKEND_URL!;

const request = async <T>(url: string, options: RequestInit = {}): Promise<T> => {
  const session = authClient.getSession ? await authClient.getSession() : null;
  const token = (session as any)?.data?.session?.token ?? null;

  const headers: Record<string, string> = {};
  if (options.body) {
    headers["Content-Type"] = "application/json";
  }
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const { body, signal, ...restOptions } = options;
  const response = await fetch(`${baseUrl}${url}`, {
    ...restOptions,
    ...(body != null ? { body } : {}),
    ...(signal != null ? { signal } : {}),
    headers: { ...headers, ...(options.headers as Record<string, string> ?? {}) },
    credentials: "include",
  });

  if (response.status === 204) return undefined as T;

  const contentType = response.headers.get("content-type");
  if (contentType?.includes("application/json")) {
    const json = await response.json() as ApiResponse<T> | { error: { message: string; code: string } };
    if ("error" in json) throw new Error((json as { error: { message: string; code: string } }).error.message);
    return (json as ApiResponse<T>).data;
  }
  return undefined as T;
};

export const api = {
  get: <T>(url: string) => request<T>(url),
  post: <T>(url: string, body?: unknown) => request<T>(url, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  put: <T>(url: string, body: unknown) => request<T>(url, { method: "PUT", body: JSON.stringify(body) }),
  delete: <T>(url: string) => request<T>(url, { method: "DELETE" }),
  patch: <T>(url: string, body: unknown) => request<T>(url, { method: "PATCH", body: JSON.stringify(body) }),
};
