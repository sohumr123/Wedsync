import { useQuery } from "@tanstack/react-query";
import * as Location from "expo-location";
import type { TimelineEventDTO } from "./types";

export type WeatherData = {
  temperatureF: number;
  precipitationProbability: number;
  weatherCode: number;
  iconName: string;
  description: string;
};

// WMO weather interpretation codes → display info
const WMO: Record<number, { description: string; iconName: string }> = {
  0:  { description: "Clear sky",       iconName: "Sun" },
  1:  { description: "Mainly clear",    iconName: "Sun" },
  2:  { description: "Partly cloudy",   iconName: "CloudSun" },
  3:  { description: "Overcast",        iconName: "Cloud" },
  45: { description: "Foggy",           iconName: "Cloud" },
  48: { description: "Freezing fog",    iconName: "Cloud" },
  51: { description: "Light drizzle",   iconName: "CloudDrizzle" },
  53: { description: "Drizzle",         iconName: "CloudDrizzle" },
  55: { description: "Heavy drizzle",   iconName: "CloudDrizzle" },
  61: { description: "Light rain",      iconName: "CloudRain" },
  63: { description: "Rain",            iconName: "CloudRain" },
  65: { description: "Heavy rain",      iconName: "CloudRain" },
  71: { description: "Light snow",      iconName: "CloudSnow" },
  73: { description: "Snow",            iconName: "CloudSnow" },
  75: { description: "Heavy snow",      iconName: "CloudSnow" },
  77: { description: "Snow grains",     iconName: "CloudSnow" },
  80: { description: "Light showers",   iconName: "CloudRain" },
  81: { description: "Showers",         iconName: "CloudRain" },
  82: { description: "Heavy showers",   iconName: "CloudRain" },
  85: { description: "Snow showers",    iconName: "CloudSnow" },
  86: { description: "Snow showers",    iconName: "CloudSnow" },
  95: { description: "Thunderstorm",    iconName: "CloudLightning" },
  96: { description: "Thunderstorm",    iconName: "CloudLightning" },
  99: { description: "Thunderstorm",    iconName: "CloudLightning" },
};

export function getWeatherInfo(code: number): { description: string; iconName: string } {
  if (WMO[code]) return WMO[code];
  if (code <= 1)  return { description: "Clear",      iconName: "Sun" };
  if (code <= 3)  return { description: "Cloudy",     iconName: "Cloud" };
  if (code <= 48) return { description: "Foggy",      iconName: "Cloud" };
  if (code <= 67) return { description: "Rain",       iconName: "CloudRain" };
  if (code <= 77) return { description: "Snow",       iconName: "CloudSnow" };
  if (code <= 82) return { description: "Showers",    iconName: "CloudRain" };
  if (code <= 86) return { description: "Snow",       iconName: "CloudSnow" };
  return             { description: "Thunderstorm", iconName: "CloudLightning" };
}

async function geocodeAddress(address: string): Promise<{ lat: number; lon: number } | null> {
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`;
    const res = await fetch(url, {
      headers: { "User-Agent": "WeddingDayApp/1.0" },
    });
    const data = await res.json() as Array<{ lat: string; lon: string }>;
    if (Array.isArray(data) && data[0]) {
      return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
    }
  } catch { /* geocode failed */ }
  return null;
}

async function fetchWeatherAtTime(
  lat: number,
  lon: number,
  datetime: Date
): Promise<WeatherData | null> {
  try {
    const date = datetime.toISOString().split("T")[0];
    const url =
      `https://api.open-meteo.com/v1/forecast` +
      `?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}` +
      `&hourly=temperature_2m,precipitation_probability,weathercode` +
      `&temperature_unit=fahrenheit&timezone=auto` +
      `&start_date=${date}&end_date=${date}`;

    const res = await fetch(url);
    const data = await res.json() as {
      error?: boolean;
      hourly?: {
        time: string[];
        temperature_2m: (number | null)[];
        precipitation_probability: (number | null)[];
        weathercode: (number | null)[];
      };
    };

    if (data.error || !data.hourly) return null;

    const hour = datetime.getHours();
    const temp = data.hourly.temperature_2m[hour];
    const precip = data.hourly.precipitation_probability[hour] ?? 0;
    const code = data.hourly.weathercode[hour];

    if (temp == null || code == null) return null;

    return {
      temperatureF: Math.round(temp),
      precipitationProbability: Math.round(precip),
      weatherCode: code,
      ...getWeatherInfo(code),
    };
  } catch { /* fetch failed */ }
  return null;
}

// Max forecast window for Open-Meteo free tier
const MAX_FORECAST_DAYS = 16;

export function useTimelineWeather(events: TimelineEventDTO[]): {
  weatherMap: Record<string, WeatherData>;
  isLoading: boolean;
  tooFarOut: boolean;
} {
  const addressEvents = events.filter((e) => e.address || e.locationName);

  // Check if wedding date is within forecast range
  const firstEvent = events[0];
  const weddingDate = firstEvent ? new Date(firstEvent.startTime) : null;
  const daysUntil = weddingDate
    ? Math.ceil((weddingDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : 999;
  const tooFarOut = daysUntil > MAX_FORECAST_DAYS;

  const queryKey = [
    "timeline-weather",
    addressEvents.map((e) => `${e.id}:${e.address ?? e.locationName}`).join("|"),
  ];

  const { data, isLoading } = useQuery({
    queryKey,
    queryFn: async (): Promise<Record<string, WeatherData>> => {
      const result: Record<string, WeatherData> = {};
      // Cache geocoding results within this fetch to avoid duplicate calls
      const geoCache: Record<string, { lat: number; lon: number } | null> = {};

      for (const event of addressEvents) {
        const searchTerm = event.address || event.locationName;
        if (!searchTerm) continue;

        if (!(searchTerm in geoCache)) {
          // Respect Nominatim rate limit: 1 req/sec
          await new Promise((r) => setTimeout(r, 350));
          geoCache[searchTerm] = await geocodeAddress(searchTerm);
        }

        const coords = geoCache[searchTerm];
        if (!coords) continue;

        const weather = await fetchWeatherAtTime(coords.lat, coords.lon, new Date(event.startTime));
        if (weather) result[event.id] = weather;
      }
      return result;
    },
    staleTime: 30 * 60 * 1000,  // 30 min
    enabled: addressEvents.length > 0 && !tooFarOut,
  });

  return { weatherMap: data ?? {}, isLoading, tooFarOut };
}

export function useSunsetTime(weddingDate: string | null): {
  sunsetTime: Date | null;
} {
  const { data } = useQuery({
    queryKey: ["sunset", weddingDate],
    queryFn: async (): Promise<Date | null> => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return null;

      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      const { latitude, longitude } = loc.coords;

      const date = new Date(weddingDate!).toISOString().split("T")[0];
      const url =
        `https://api.open-meteo.com/v1/forecast` +
        `?latitude=${latitude.toFixed(4)}&longitude=${longitude.toFixed(4)}` +
        `&daily=sunset&timezone=auto&start_date=${date}&end_date=${date}`;

      const res = await fetch(url);
      const json = await res.json() as { daily?: { sunset: string[] } };
      if (!json.daily?.sunset?.[0]) return null;
      return new Date(json.daily.sunset[0]);
    },
    staleTime: 60 * 60 * 1000,
    enabled: !!weddingDate,
  });

  return { sunsetTime: data ?? null };
}
