import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface WeddingStore {
  activeWeddingId: string | null;
  setActiveWeddingId: (id: string | null) => void;
}

const useWeddingStore = create<WeddingStore>()(
  persist(
    (set) => ({
      activeWeddingId: null,
      setActiveWeddingId: (id) => set({ activeWeddingId: id }),
    }),
    { name: "wedding-storage", storage: createJSONStorage(() => AsyncStorage) }
  )
);

export default useWeddingStore;
