import { format, isWithinInterval } from "date-fns";
import type { TimelineEventDTO } from "./types";

export const formatTime = (iso: string) => format(new Date(iso), "h:mm a");
export const formatDate = (iso: string) => format(new Date(iso), "EEEE, MMMM d, yyyy");
export const isEventNow = (event: TimelineEventDTO) =>
  isWithinInterval(new Date(), { start: new Date(event.startTime), end: new Date(event.endTime) });
export const isEventPast = (event: TimelineEventDTO) => new Date(event.endTime) < new Date();
export const getInitials = (name: string) =>
  name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

export const QUERY_KEYS = {
  me: ["me"] as const,
  weddings: ["weddings"] as const,
  wedding: (id: string) => ["wedding", id] as const,
  events: (id: string) => ["events", id] as const,
  changeRequests: (id: string) => ["changeRequests", id] as const,
  people: (id: string) => ["people", id] as const,
  members: (id: string) => ["members", id] as const,
};
