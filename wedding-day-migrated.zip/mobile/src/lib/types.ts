export const VENDOR_SPECIALTIES = ["photographer","videographer","dj","planner","coordinator","florist","caterer","officiant","hairMakeup","transportation","other"] as const;
export type VendorSpecialty = typeof VENDOR_SPECIALTIES[number];

export const VENDOR_SPECIALTY_LABELS: Record<VendorSpecialty, string> = {
  photographer: "Photographer", videographer: "Videographer", dj: "DJ",
  planner: "Wedding Planner", coordinator: "Day-of Coordinator", florist: "Florist",
  caterer: "Caterer", officiant: "Officiant", hairMakeup: "Hair & Makeup",
  transportation: "Transportation", other: "Other"
};

export const EVENT_CATEGORIES = ["gettingReady","firstLook","ceremony","cocktail","reception","sendOff","travel","other"] as const;
export type EventCategory = typeof EVENT_CATEGORIES[number];

export const EVENT_CATEGORY_LABELS: Record<EventCategory, string> = {
  gettingReady: "Getting Ready", firstLook: "First Look", ceremony: "Ceremony",
  cocktail: "Cocktail Hour", reception: "Reception", sendOff: "Send Off",
  travel: "Travel", other: "Other"
};

export const EVENT_CATEGORY_ICONS: Record<EventCategory, string> = {
  gettingReady: "sparkles", firstLook: "heart", ceremony: "gem", cocktail: "wine",
  reception: "music", sendOff: "star", travel: "car", other: "calendar"
};

export const IMPORTANT_PERSON_CATEGORIES = ["family","bridalParty","speechGiver","officiant","vip","other"] as const;
export type ImportantPersonCategory = typeof IMPORTANT_PERSON_CATEGORIES[number];

export const PERSON_CATEGORY_LABELS: Record<ImportantPersonCategory, string> = {
  family: "Family", bridalParty: "Bridal Party", speechGiver: "Speech / Toast",
  officiant: "Officiant", vip: "VIP Guest", other: "Other"
};

export type UserRole = "vendor" | "couple" | "admin";

export type UserProfileDTO = {
  id: string; userId: string; email: string; name: string; displayName: string;
  role: UserRole; vendorSpecialty: VendorSpecialty | null; phone: string | null;
  company: string | null; image: string | null; createdAt: string; updatedAt: string;
};

export type WeddingMemberDTO = {
  id: string; weddingId: string; userId: string; role: UserRole;
  vendorSpecialty: VendorSpecialty | null; joinedAt: string;
  user: { id: string; displayName: string; name: string; email: string; image: string | null; phone: string | null; company: string | null; };
};

export type WeddingDTO = {
  id: string; partner1Name: string; partner2Name: string; weddingDate: string;
  venueName: string | null; timezone: string; inviteCode: string; createdById: string; createdAt: string; updatedAt: string;
};

export type WeddingWithRoleDTO = WeddingDTO & { myRole: UserRole; myVendorSpecialty: VendorSpecialty | null; };

export type TimelineEventDTO = {
  id: string; weddingId: string; title: string; description: string | null;
  startTime: string; endTime: string; locationName: string | null; address: string | null;
  category: EventCategory; assignedVendorIds: string[]; orderIndex: number; createdAt: string; updatedAt: string;
  originalStartTime: string | null; originalEndTime: string | null;
  completedAt: string | null;
};

export type ChangeRequestDTO = {
  id: string; weddingId: string; eventId: string; requestedById: string; requestedByName: string;
  proposedStartTime: string | null; proposedEndTime: string | null; proposedTitle: string | null;
  proposedDescription: string | null; reason: string | null; status: "pending" | "approved" | "rejected";
  resolvedById: string | null; resolvedAt: string | null; createdAt: string;
};

export type ImportantPersonDTO = {
  id: string; weddingId: string; name: string; relationship: string; photoUrl: string | null;
  notes: string | null; category: ImportantPersonCategory; createdAt: string; updatedAt: string;
};

export type WeddingDetailDTO = WeddingDTO & {
  myRole: UserRole; myVendorSpecialty: VendorSpecialty | null;
  members: WeddingMemberDTO[]; events: TimelineEventDTO[];
  importantPeople: ImportantPersonDTO[]; pendingChangeRequests: ChangeRequestDTO[];
};
