import { useState } from "react";
import { View, Text, Pressable, Modal, Linking, Platform } from "react-native";
import { MapPin, Navigation2, X } from "lucide-react-native";

type MapApp = {
  name: string;
  color: string;
  scheme: string;
  fallback: string;
};

function getMapApps(encoded: string): MapApp[] {
  const apps: MapApp[] = [];
  if (Platform.OS === "ios") {
    apps.push({
      name: "Apple Maps",
      color: "#2196F3",
      scheme: `maps://?q=${encoded}`,
      fallback: `https://maps.apple.com/?q=${encoded}`,
    });
  }
  apps.push({
    name: "Google Maps",
    color: "#4285F4",
    scheme: `comgooglemaps://?daddr=${encoded}&directionsmode=driving`,
    fallback: `https://www.google.com/maps/dir/?api=1&destination=${encoded}`,
  });
  apps.push({
    name: "Waze",
    color: "#33CCFF",
    scheme: `waze://?q=${encoded}&navigate=yes`,
    fallback: `https://waze.com/ul?q=${encoded}&navigate=yes`,
  });
  return apps;
}

export function AddressNavigator({
  address,
  locationName,
}: {
  address: string;
  locationName?: string;
}) {
  const [visible, setVisible] = useState<boolean>(false);
  const encoded = encodeURIComponent(address);
  const apps = getMapApps(encoded);

  const openApp = async (app: MapApp) => {
    const canOpen = await Linking.canOpenURL(app.scheme);
    await Linking.openURL(canOpen ? app.scheme : app.fallback);
    setVisible(false);
  };

  return (
    <>
      <Pressable
        testID="navigate-address-button"
        onPress={() => setVisible(true)}
        style={({ pressed }) => ({
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          opacity: pressed ? 0.7 : 1,
          paddingVertical: 2,
          alignSelf: "flex-start",
        })}
      >
        <Text
          style={{
            fontFamily: "DMSans_400Regular",
            fontSize: 12,
            color: "#C9A84C",
            textDecorationLine: "underline",
            flex: 1,
            flexWrap: "wrap",
          }}
        >
          {address}
        </Text>
        <Navigation2 size={12} color="#C9A84C" />
      </Pressable>

      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={() => setVisible(false)}
      >
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
          onPress={() => setVisible(false)}
        >
          <Pressable
            style={{
              backgroundColor: "#FFFFFF",
              borderTopLeftRadius: 24,
              borderTopRightRadius: 24,
              paddingTop: 20,
              paddingBottom: 44,
              paddingHorizontal: 24,
            }}
            onPress={() => {}}
          >
            {/* Handle bar */}
            <View
              style={{
                width: 36,
                height: 4,
                borderRadius: 2,
                backgroundColor: "#E8E0D5",
                alignSelf: "center",
                marginBottom: 20,
              }}
            />

            {/* Header */}
            <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 6 }}>
              <View
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  backgroundColor: "#FDF8EE",
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 2,
                }}
              >
                <MapPin size={18} color="#C9A84C" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontFamily: "PlayfairDisplay_700Bold",
                    fontSize: 20,
                    color: "#2C1810",
                    marginBottom: 2,
                  }}
                >
                  {locationName ?? "Navigate to"}
                </Text>
                <Text
                  style={{
                    fontFamily: "DMSans_400Regular",
                    fontSize: 13,
                    color: "#8B7355",
                    lineHeight: 18,
                  }}
                  numberOfLines={2}
                >
                  {address}
                </Text>
              </View>
              <Pressable
                onPress={() => setVisible(false)}
                hitSlop={10}
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 15,
                  backgroundColor: "#F5F0E8",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <X size={16} color="#8B7355" />
              </Pressable>
            </View>

            <Text
              style={{
                fontFamily: "DMSans_500Medium",
                fontSize: 11,
                color: "#8B7355",
                letterSpacing: 1,
                textTransform: "uppercase",
                marginTop: 20,
                marginBottom: 12,
              }}
            >
              Open with
            </Text>

            {apps.map((app) => (
              <Pressable
                testID={`open-${app.name.toLowerCase().replace(" ", "-")}`}
                key={app.name}
                onPress={() => openApp(app)}
                style={({ pressed }) => ({
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 14,
                  backgroundColor: pressed ? "#FDF8EE" : "#FAFAF8",
                  borderRadius: 14,
                  padding: 16,
                  marginBottom: 10,
                  borderWidth: 1,
                  borderColor: "#E8E0D5",
                })}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 12,
                    backgroundColor: app.color + "18",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Navigation2 size={20} color={app.color} />
                </View>
                <Text
                  style={{ fontFamily: "DMSans_600SemiBold", fontSize: 16, color: "#2C1810", flex: 1 }}
                >
                  {app.name}
                </Text>
                <Text style={{ fontFamily: "DMSans_400Regular", fontSize: 12, color: "#C9A84C" }}>
                  Open →
                </Text>
              </Pressable>
            ))}
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}
