import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { prisma } from "../prisma";
import { requireAuth, getUser } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";
import type { UserProfileDTO } from "../types";
import { USER_ROLES, VENDOR_SPECIALTIES } from "../types";

const meRouter = new Hono<AppBindings>();

function toUserProfileDTO(user: {
  id: string;
  email: string;
  name: string;
  displayName: string | null;
  role: string | null;
  vendorSpecialty: string | null;
  phone: string | null;
  company: string | null;
  image: string | null;
  createdAt: Date;
  updatedAt: Date;
}): UserProfileDTO {
  return {
    id: user.id,
    userId: user.id,
    email: user.email,
    name: user.name,
    displayName: user.displayName ?? "",
    role: (user.role as UserProfileDTO["role"]) ?? "couple",
    vendorSpecialty: (user.vendorSpecialty as UserProfileDTO["vendorSpecialty"]) ?? null,
    phone: user.phone,
    company: user.company,
    image: user.image,
    createdAt: user.createdAt.toISOString(),
    updatedAt: user.updatedAt.toISOString(),
  };
}

meRouter.get("/", requireAuth, async (c) => {
  try {
    const authUser = getUser(c);
    const user = await prisma.user.findUnique({ where: { id: authUser.id } });
    if (!user) throw new HttpError(404, "USER_NOT_FOUND", "User not found");
    return c.json({ data: toUserProfileDTO(user) });
  } catch (err) {
    return handleError(c, err);
  }
});

const patchMeSchema = z.object({
  displayName: z.string().optional(),
  role: z.enum(USER_ROLES).optional(),
  vendorSpecialty: z.enum(VENDOR_SPECIALTIES).nullable().optional(),
  phone: z.string().nullable().optional(),
  company: z.string().nullable().optional(),
  image: z.string().nullable().optional(),
});

meRouter.patch("/", requireAuth, zValidator("json", patchMeSchema), async (c) => {
  try {
    const authUser = getUser(c);
    const body = c.req.valid("json");
    const updated = await prisma.user.update({
      where: { id: authUser.id },
      data: {
        ...(body.displayName !== undefined && { displayName: body.displayName }),
        ...(body.role !== undefined && { role: body.role }),
        ...(body.vendorSpecialty !== undefined && { vendorSpecialty: body.vendorSpecialty }),
        ...(body.phone !== undefined && { phone: body.phone }),
        ...(body.company !== undefined && { company: body.company }),
        ...(body.image !== undefined && { image: body.image }),
      },
    });
    return c.json({ data: toUserProfileDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

export { meRouter };
