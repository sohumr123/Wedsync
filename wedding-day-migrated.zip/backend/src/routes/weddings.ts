import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { prisma } from "../prisma";
import { requireAuth, getUser, requireWeddingMember, requireWeddingAdmin } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";
import type {
  WeddingDTO,
  WeddingWithRoleDTO,
  WeddingDetailDTO,
  WeddingMemberDTO,
  TimelineEventDTO,
  ImportantPersonDTO,
  ChangeRequestDTO,
} from "../types";
import type { Context } from "hono";

const weddingsRouter = new Hono<AppBindings>();

function getParam(c: Context, name: string): string {
  const val = c.req.param(name);
  if (!val) throw new HttpError(400, "MISSING_PARAM", `Missing route param: ${name}`);
  return val;
}

function randomInviteCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

function toWeddingDTO(w: {
  id: string;
  partner1Name: string;
  partner2Name: string;
  weddingDate: Date;
  venueName: string | null;
  timezone: string;
  inviteCode: string;
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
}): WeddingDTO {
  return {
    id: w.id,
    partner1Name: w.partner1Name,
    partner2Name: w.partner2Name,
    weddingDate: w.weddingDate.toISOString(),
    venueName: w.venueName,
    timezone: w.timezone,
    inviteCode: w.inviteCode,
    createdById: w.createdById,
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
  };
}

function toMemberDTO(m: {
  id: string;
  weddingId: string;
  userId: string;
  role: string;
  vendorSpecialty: string | null;
  joinedAt: Date;
  user: {
    id: string;
    displayName: string | null;
    name: string;
    email: string;
    image: string | null;
    phone: string | null;
    company: string | null;
  };
}): WeddingMemberDTO {
  return {
    id: m.id,
    weddingId: m.weddingId,
    userId: m.userId,
    role: m.role as WeddingMemberDTO["role"],
    vendorSpecialty: (m.vendorSpecialty as WeddingMemberDTO["vendorSpecialty"]) ?? null,
    joinedAt: m.joinedAt.toISOString(),
    user: {
      id: m.user.id,
      displayName: m.user.displayName ?? "",
      name: m.user.name,
      email: m.user.email,
      image: m.user.image,
      phone: m.user.phone,
      company: m.user.company,
    },
  };
}

function toTimelineEventDTO(e: {
  id: string;
  weddingId: string;
  title: string;
  description: string | null;
  startTime: Date;
  endTime: Date;
  originalStartTime: Date | null;
  originalEndTime: Date | null;
  completedAt: Date | null;
  locationName: string | null;
  address: string | null;
  category: string;
  assignedVendorIds: string | null;
  orderIndex: number;
  createdAt: Date;
  updatedAt: Date;
}): TimelineEventDTO {
  return {
    id: e.id,
    weddingId: e.weddingId,
    title: e.title,
    description: e.description,
    startTime: e.startTime.toISOString(),
    endTime: e.endTime.toISOString(),
    originalStartTime: e.originalStartTime?.toISOString() ?? null,
    originalEndTime: e.originalEndTime?.toISOString() ?? null,
    completedAt: e.completedAt?.toISOString() ?? null,
    locationName: e.locationName,
    address: e.address,
    category: e.category as TimelineEventDTO["category"],
    assignedVendorIds: e.assignedVendorIds ? JSON.parse(e.assignedVendorIds) : [],
    orderIndex: e.orderIndex,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt.toISOString(),
  };
}

function toImportantPersonDTO(p: {
  id: string;
  weddingId: string;
  name: string;
  relationship: string;
  photoUrl: string | null;
  notes: string | null;
  category: string;
  createdAt: Date;
  updatedAt: Date;
}): ImportantPersonDTO {
  return {
    id: p.id,
    weddingId: p.weddingId,
    name: p.name,
    relationship: p.relationship,
    photoUrl: p.photoUrl,
    notes: p.notes,
    category: p.category as ImportantPersonDTO["category"],
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

function toChangeRequestDTO(r: {
  id: string;
  weddingId: string;
  eventId: string;
  requestedById: string;
  requestedByName: string;
  proposedStartTime: Date | null;
  proposedEndTime: Date | null;
  proposedTitle: string | null;
  proposedDescription: string | null;
  reason: string | null;
  status: string;
  resolvedById: string | null;
  resolvedAt: Date | null;
  createdAt: Date;
}): ChangeRequestDTO {
  return {
    id: r.id,
    weddingId: r.weddingId,
    eventId: r.eventId,
    requestedById: r.requestedById,
    requestedByName: r.requestedByName,
    proposedStartTime: r.proposedStartTime?.toISOString() ?? null,
    proposedEndTime: r.proposedEndTime?.toISOString() ?? null,
    proposedTitle: r.proposedTitle,
    proposedDescription: r.proposedDescription,
    reason: r.reason,
    status: r.status as ChangeRequestDTO["status"],
    resolvedById: r.resolvedById,
    resolvedAt: r.resolvedAt?.toISOString() ?? null,
    createdAt: r.createdAt.toISOString(),
  };
}

// GET /api/weddings — list weddings user is a member of
weddingsRouter.get("/", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const memberships = await prisma.weddingMember.findMany({
      where: { userId: user.id },
      include: { wedding: true },
    });
    const result: WeddingWithRoleDTO[] = memberships.map((m) => ({
      ...toWeddingDTO(m.wedding),
      myRole: m.role as WeddingWithRoleDTO["myRole"],
      myVendorSpecialty: (m.vendorSpecialty as WeddingWithRoleDTO["myVendorSpecialty"]) ?? null,
    }));
    return c.json({ data: result });
  } catch (err) {
    return handleError(c, err);
  }
});

const createWeddingSchema = z.object({
  partner1Name: z.string().min(1),
  partner2Name: z.string().min(1),
  weddingDate: z.string().min(1),
  venueName: z.string().optional(),
  timezone: z.string().optional(),
});

// POST /api/weddings — create a new wedding
weddingsRouter.post("/", requireAuth, zValidator("json", createWeddingSchema), async (c) => {
  try {
    const user = getUser(c);
    const body = c.req.valid("json");
    const inviteCode = randomInviteCode();

    const wedding = await prisma.wedding.create({
      data: {
        partner1Name: body.partner1Name,
        partner2Name: body.partner2Name,
        weddingDate: new Date(body.weddingDate),
        venueName: body.venueName ?? null,
        timezone: body.timezone ?? "UTC",
        inviteCode,
        createdById: user.id,
        members: {
          create: {
            userId: user.id,
            role: "admin",
            vendorSpecialty: null,
          },
        },
      },
    });

    return c.json({ data: toWeddingDTO(wedding) }, 201);
  } catch (err) {
    return handleError(c, err);
  }
});

const joinWeddingSchema = z.object({
  inviteCode: z.string().min(1),
});

// POST /api/weddings/join — join a wedding via invite code
weddingsRouter.post("/join", requireAuth, zValidator("json", joinWeddingSchema), async (c) => {
  try {
    const user = getUser(c);
    const { inviteCode } = c.req.valid("json");

    const wedding = await prisma.wedding.findUnique({ where: { inviteCode } });
    if (!wedding) throw new HttpError(404, "WEDDING_NOT_FOUND", "No wedding found with that invite code");

    // Check if already a member
    const existing = await prisma.weddingMember.findUnique({
      where: { weddingId_userId: { weddingId: wedding.id, userId: user.id } },
    });
    if (existing) throw new HttpError(409, "ALREADY_MEMBER", "You are already a member of this wedding");

    // Determine role from user profile
    const userRecord = await prisma.user.findUnique({ where: { id: user.id } });
    const memberRole = userRecord?.role === "vendor" ? "vendor" : "couple";
    const vendorSpecialty = memberRole === "vendor" ? (userRecord?.vendorSpecialty ?? null) : null;

    const member = await prisma.weddingMember.create({
      data: {
        weddingId: wedding.id,
        userId: user.id,
        role: memberRole,
        vendorSpecialty,
      },
    });

    const result: WeddingWithRoleDTO = {
      ...toWeddingDTO(wedding),
      myRole: member.role as WeddingWithRoleDTO["myRole"],
      myVendorSpecialty: (member.vendorSpecialty as WeddingWithRoleDTO["myVendorSpecialty"]) ?? null,
    };
    return c.json({ data: result });
  } catch (err) {
    return handleError(c, err);
  }
});

// GET /api/weddings/:id — get full wedding details
weddingsRouter.get("/:id", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const member = await requireWeddingMember(user.id, weddingId);

    const wedding = await prisma.wedding.findUnique({
      where: { id: weddingId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                displayName: true,
                name: true,
                email: true,
                image: true,
                phone: true,
                company: true,
              },
            },
          },
        },
        events: { orderBy: { startTime: "asc" } },
        importantPeople: true,
        changeRequests: {
          where: { status: "pending" },
        },
      },
    });

    if (!wedding) throw new HttpError(404, "WEDDING_NOT_FOUND", "Wedding not found");

    const result: WeddingDetailDTO = {
      ...toWeddingDTO(wedding),
      myRole: member.role as WeddingDetailDTO["myRole"],
      myVendorSpecialty: (member.vendorSpecialty as WeddingDetailDTO["myVendorSpecialty"]) ?? null,
      members: wedding.members.map(toMemberDTO),
      events: wedding.events.map(toTimelineEventDTO),
      importantPeople: wedding.importantPeople.map(toImportantPersonDTO),
      pendingChangeRequests: wedding.changeRequests.map(toChangeRequestDTO),
    };

    return c.json({ data: result });
  } catch (err) {
    return handleError(c, err);
  }
});

// DELETE /api/weddings/:id — delete wedding (admin only)
weddingsRouter.delete("/:id", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingAdmin(user.id, weddingId);

    await prisma.wedding.delete({ where: { id: weddingId } });
    return c.json({ data: { success: true } });
  } catch (err) {
    return handleError(c, err);
  }
});

const patchWeddingSchema = z.object({
  partner1Name: z.string().min(1).optional(),
  partner2Name: z.string().min(1).optional(),
  weddingDate: z.string().optional(),
  venueName: z.string().nullable().optional(),
  timezone: z.string().optional(),
});

// PATCH /api/weddings/:id — update wedding (admin only)
weddingsRouter.patch("/:id", requireAuth, zValidator("json", patchWeddingSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingAdmin(user.id, weddingId);
    const body = c.req.valid("json");

    const updated = await prisma.wedding.update({
      where: { id: weddingId },
      data: {
        ...(body.partner1Name !== undefined && { partner1Name: body.partner1Name }),
        ...(body.partner2Name !== undefined && { partner2Name: body.partner2Name }),
        ...(body.weddingDate !== undefined && { weddingDate: new Date(body.weddingDate) }),
        ...(body.venueName !== undefined && { venueName: body.venueName }),
        ...(body.timezone !== undefined && { timezone: body.timezone }),
      },
    });

    return c.json({ data: toWeddingDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

const patchMemberSchema = z.object({
  role: z.enum(["admin", "vendor", "couple"]),
});

// PATCH /api/weddings/:id/members/:memberId — promote/demote member (admin only)
weddingsRouter.patch("/:id/members/:memberId", requireAuth, zValidator("json", patchMemberSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const memberId = getParam(c, "memberId");
    await requireWeddingAdmin(user.id, weddingId);
    const { role } = c.req.valid("json");

    const member = await prisma.weddingMember.findFirst({ where: { id: memberId, weddingId } });
    if (!member) throw new HttpError(404, "MEMBER_NOT_FOUND", "Member not found");
    if (member.userId === user.id) throw new HttpError(400, "CANNOT_CHANGE_OWN_ROLE", "You cannot change your own role");

    const updated = await prisma.weddingMember.update({
      where: { id: memberId },
      data: { role },
      include: {
        user: { select: { id: true, displayName: true, name: true, email: true, image: true, phone: true, company: true } },
      },
    });

    return c.json({ data: toMemberDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

export {
  weddingsRouter,
  toWeddingDTO,
  toMemberDTO,
  toTimelineEventDTO,
  toImportantPersonDTO,
  toChangeRequestDTO,
};
