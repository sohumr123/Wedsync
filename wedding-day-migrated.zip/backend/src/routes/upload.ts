import { Hono } from "hono";
import { requireAuth } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";

const uploadRouter = new Hono<AppBindings>();

// POST /api/upload — accept multipart file, return base64 data URL
uploadRouter.post("/", requireAuth, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get("file");

    if (!file || typeof file === "string") {
      throw new HttpError(400, "MISSING_FILE", "No file provided in field 'file'");
    }

    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const base64 = btoa(String.fromCharCode(...bytes));
    const contentType = file.type || "application/octet-stream";
    const url = `data:${contentType};base64,${base64}`;

    return c.json({ data: { url } });
  } catch (err) {
    return handleError(c, err);
  }
});

export { uploadRouter };
