import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { prisma } from "../prisma";
import { requireAuth, getUser, requireWeddingMember, requireWeddingAdmin } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";
import type { ChangeRequestDTO } from "../types";
import { CHANGE_REQUEST_STATUS } from "../types";
import type { Context } from "hono";

const changeRequestsRouter = new Hono<AppBindings>();

function getParam(c: Context, name: string): string {
  const val = c.req.param(name);
  if (!val) throw new HttpError(400, "MISSING_PARAM", `Missing route param: ${name}`);
  return val;
}

function toChangeRequestDTO(r: {
  id: string;
  weddingId: string;
  eventId: string;
  requestedById: string;
  requestedByName: string;
  proposedStartTime: Date | null;
  proposedEndTime: Date | null;
  proposedTitle: string | null;
  proposedDescription: string | null;
  reason: string | null;
  status: string;
  resolvedById: string | null;
  resolvedAt: Date | null;
  createdAt: Date;
}): ChangeRequestDTO {
  return {
    id: r.id,
    weddingId: r.weddingId,
    eventId: r.eventId,
    requestedById: r.requestedById,
    requestedByName: r.requestedByName,
    proposedStartTime: r.proposedStartTime?.toISOString() ?? null,
    proposedEndTime: r.proposedEndTime?.toISOString() ?? null,
    proposedTitle: r.proposedTitle,
    proposedDescription: r.proposedDescription,
    reason: r.reason,
    status: r.status as ChangeRequestDTO["status"],
    resolvedById: r.resolvedById,
    resolvedAt: r.resolvedAt?.toISOString() ?? null,
    createdAt: r.createdAt.toISOString(),
  };
}

// GET /api/weddings/:id/change-requests
changeRequestsRouter.get(
  "/",
  requireAuth,
  zValidator("query", z.object({ status: z.enum(CHANGE_REQUEST_STATUS).optional() })),
  async (c) => {
    try {
      const user = getUser(c);
      const weddingId = getParam(c, "id");
      await requireWeddingMember(user.id, weddingId);
      const { status } = c.req.valid("query");

      const requests = await prisma.changeRequest.findMany({
        where: {
          weddingId,
          ...(status ? { status } : {}),
        },
        orderBy: { createdAt: "desc" },
      });

      return c.json({ data: requests.map(toChangeRequestDTO) });
    } catch (err) {
      return handleError(c, err);
    }
  }
);

// POST /api/weddings/:id/change-requests/:requestId/approve
changeRequestsRouter.post("/:requestId/approve", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const requestId = getParam(c, "requestId");
    await requireWeddingAdmin(user.id, weddingId);

    const changeRequest = await prisma.changeRequest.findFirst({
      where: { id: requestId, weddingId },
    });
    if (!changeRequest) throw new HttpError(404, "REQUEST_NOT_FOUND", "Change request not found");
    if (changeRequest.status !== "pending") {
      throw new HttpError(409, "NOT_PENDING", "Change request is not pending");
    }

    // Apply changes to the event
    await prisma.timelineEvent.update({
      where: { id: changeRequest.eventId },
      data: {
        ...(changeRequest.proposedStartTime && { startTime: changeRequest.proposedStartTime }),
        ...(changeRequest.proposedEndTime && { endTime: changeRequest.proposedEndTime }),
        ...(changeRequest.proposedTitle && { title: changeRequest.proposedTitle }),
        ...(changeRequest.proposedDescription !== null &&
          changeRequest.proposedDescription !== undefined && {
            description: changeRequest.proposedDescription,
          }),
      },
    });

    const updated = await prisma.changeRequest.update({
      where: { id: requestId },
      data: {
        status: "approved",
        resolvedById: user.id,
        resolvedAt: new Date(),
      },
    });

    return c.json({ data: toChangeRequestDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

// POST /api/weddings/:id/change-requests/:requestId/reject
changeRequestsRouter.post("/:requestId/reject", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const requestId = getParam(c, "requestId");
    await requireWeddingAdmin(user.id, weddingId);

    const changeRequest = await prisma.changeRequest.findFirst({
      where: { id: requestId, weddingId },
    });
    if (!changeRequest) throw new HttpError(404, "REQUEST_NOT_FOUND", "Change request not found");
    if (changeRequest.status !== "pending") {
      throw new HttpError(409, "NOT_PENDING", "Change request is not pending");
    }

    const updated = await prisma.changeRequest.update({
      where: { id: requestId },
      data: {
        status: "rejected",
        resolvedById: user.id,
        resolvedAt: new Date(),
      },
    });

    return c.json({ data: toChangeRequestDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

export { changeRequestsRouter };
