import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { prisma } from "../prisma";
import { requireAuth, getUser, requireWeddingMember, requireWeddingAdmin } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";
import type { TimelineEventDTO, ChangeRequestDTO } from "../types";
import { EVENT_CATEGORIES } from "../types";
import type { Context } from "hono";

const eventsRouter = new Hono<AppBindings>();

function getParam(c: Context, name: string): string {
  const val = c.req.param(name);
  if (!val) throw new HttpError(400, "MISSING_PARAM", `Missing route param: ${name}`);
  return val;
}

function toTimelineEventDTO(e: {
  id: string;
  weddingId: string;
  title: string;
  description: string | null;
  startTime: Date;
  endTime: Date;
  originalStartTime: Date | null;
  originalEndTime: Date | null;
  completedAt: Date | null;
  locationName: string | null;
  address: string | null;
  category: string;
  assignedVendorIds: string;
  orderIndex: number;
  createdAt: Date;
  updatedAt: Date;
}): TimelineEventDTO {
  return {
    id: e.id,
    weddingId: e.weddingId,
    title: e.title,
    description: e.description,
    startTime: e.startTime.toISOString(),
    endTime: e.endTime.toISOString(),
    originalStartTime: e.originalStartTime?.toISOString() ?? null,
    originalEndTime: e.originalEndTime?.toISOString() ?? null,
    completedAt: e.completedAt?.toISOString() ?? null,
    locationName: e.locationName,
    address: e.address,
    category: e.category as TimelineEventDTO["category"],
    assignedVendorIds: e.assignedVendorIds ? JSON.parse(e.assignedVendorIds) : [],
    orderIndex: e.orderIndex,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt.toISOString(),
  };
}

function toChangeRequestDTO(r: {
  id: string;
  weddingId: string;
  eventId: string;
  requestedById: string;
  requestedByName: string;
  proposedStartTime: Date | null;
  proposedEndTime: Date | null;
  proposedTitle: string | null;
  proposedDescription: string | null;
  reason: string | null;
  status: string;
  resolvedById: string | null;
  resolvedAt: Date | null;
  createdAt: Date;
}): ChangeRequestDTO {
  return {
    id: r.id,
    weddingId: r.weddingId,
    eventId: r.eventId,
    requestedById: r.requestedById,
    requestedByName: r.requestedByName,
    proposedStartTime: r.proposedStartTime?.toISOString() ?? null,
    proposedEndTime: r.proposedEndTime?.toISOString() ?? null,
    proposedTitle: r.proposedTitle,
    proposedDescription: r.proposedDescription,
    reason: r.reason,
    status: r.status as ChangeRequestDTO["status"],
    resolvedById: r.resolvedById,
    resolvedAt: r.resolvedAt?.toISOString() ?? null,
    createdAt: r.createdAt.toISOString(),
  };
}

// GET /api/weddings/:id/events
eventsRouter.get("/", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingMember(user.id, weddingId);

    const events = await prisma.timelineEvent.findMany({
      where: { weddingId },
      orderBy: { startTime: "asc" },
    });

    return c.json({ data: events.map(toTimelineEventDTO) });
  } catch (err) {
    return handleError(c, err);
  }
});

const createEventSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  startTime: z.string().min(1),
  endTime: z.string().min(1),
  locationName: z.string().optional(),
  address: z.string().optional(),
  category: z.enum(EVENT_CATEGORIES),
  assignedVendorIds: z.array(z.string()).optional(),
});

// POST /api/weddings/:id/events
eventsRouter.post("/", requireAuth, zValidator("json", createEventSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingAdmin(user.id, weddingId);
    const body = c.req.valid("json");

    const lastEvent = await prisma.timelineEvent.findFirst({
      where: { weddingId },
      orderBy: { orderIndex: "desc" },
      select: { orderIndex: true },
    });
    const orderIndex = (lastEvent?.orderIndex ?? -1) + 1;

    const event = await prisma.timelineEvent.create({
      data: {
        weddingId,
        title: body.title,
        description: body.description ?? null,
        startTime: new Date(body.startTime),
        endTime: new Date(body.endTime),
        locationName: body.locationName ?? null,
        address: body.address ?? null,
        category: body.category,
        assignedVendorIds: JSON.stringify(body.assignedVendorIds ?? []),
        orderIndex,
      },
    });

    return c.json({ data: toTimelineEventDTO(event) }, 201);
  } catch (err) {
    return handleError(c, err);
  }
});

const patchEventSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().nullable().optional(),
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  locationName: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  category: z.enum(EVENT_CATEGORIES).optional(),
  assignedVendorIds: z.array(z.string()).optional(),
});

// PATCH /api/weddings/:id/events/:eventId
eventsRouter.patch("/:eventId", requireAuth, zValidator("json", patchEventSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const eventId = getParam(c, "eventId");
    await requireWeddingAdmin(user.id, weddingId);
    const body = c.req.valid("json");

    const existing = await prisma.timelineEvent.findFirst({ where: { id: eventId, weddingId } });
    if (!existing) throw new HttpError(404, "EVENT_NOT_FOUND", "Event not found");

    const updated = await prisma.timelineEvent.update({
      where: { id: eventId },
      data: {
        ...(body.title !== undefined && { title: body.title }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.startTime !== undefined && { startTime: new Date(body.startTime) }),
        ...(body.endTime !== undefined && { endTime: new Date(body.endTime) }),
        ...(body.locationName !== undefined && { locationName: body.locationName }),
        ...(body.address !== undefined && { address: body.address }),
        ...(body.category !== undefined && { category: body.category }),
        ...(body.assignedVendorIds !== undefined && {
          assignedVendorIds: JSON.stringify(body.assignedVendorIds),
        }),
      },
    });

    return c.json({ data: toTimelineEventDTO(updated) });
  } catch (err) {
    return handleError(c, err);
  }
});

// DELETE /api/weddings/:id/events/:eventId
eventsRouter.delete("/:eventId", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const eventId = getParam(c, "eventId");
    await requireWeddingAdmin(user.id, weddingId);

    const existing = await prisma.timelineEvent.findFirst({ where: { id: eventId, weddingId } });
    if (!existing) throw new HttpError(404, "EVENT_NOT_FOUND", "Event not found");

    await prisma.timelineEvent.delete({ where: { id: eventId } });
    return c.json({ data: { success: true } });
  } catch (err) {
    return handleError(c, err);
  }
});

const adjustEventSchema = z.object({
  proposedStartTime: z.string().optional(),
  proposedEndTime: z.string().optional(),
  proposedTitle: z.string().optional(),
  proposedDescription: z.string().optional(),
  reason: z.string().optional(),
});

// POST /api/weddings/:id/events/:eventId/adjust
eventsRouter.post("/:eventId/adjust", requireAuth, zValidator("json", adjustEventSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const eventId = getParam(c, "eventId");
    const member = await requireWeddingMember(user.id, weddingId);
    const body = c.req.valid("json");

    const existing = await prisma.timelineEvent.findFirst({ where: { id: eventId, weddingId } });
    if (!existing) throw new HttpError(404, "EVENT_NOT_FOUND", "Event not found");

    // Admins apply immediately
    if (member.role === "admin") {
      const updated = await prisma.timelineEvent.update({
        where: { id: eventId },
        data: {
          ...(body.proposedStartTime !== undefined && { startTime: new Date(body.proposedStartTime) }),
          ...(body.proposedEndTime !== undefined && { endTime: new Date(body.proposedEndTime) }),
          ...(body.proposedTitle !== undefined && { title: body.proposedTitle }),
          ...(body.proposedDescription !== undefined && { description: body.proposedDescription }),
        },
      });
      return c.json({ data: toTimelineEventDTO(updated) });
    }

    // Vendors create a change request
    const userRecord = await prisma.user.findUnique({ where: { id: user.id } });
    const requestedByName = userRecord?.name ?? user.email ?? "Unknown";

    const changeRequest = await prisma.changeRequest.create({
      data: {
        weddingId,
        eventId,
        requestedById: user.id,
        requestedByName,
        proposedStartTime: body.proposedStartTime ? new Date(body.proposedStartTime) : null,
        proposedEndTime: body.proposedEndTime ? new Date(body.proposedEndTime) : null,
        proposedTitle: body.proposedTitle ?? null,
        proposedDescription: body.proposedDescription ?? null,
        reason: body.reason ?? null,
        status: "pending",
      },
    });

    return c.json({ data: toChangeRequestDTO(changeRequest) }, 201);
  } catch (err) {
    return handleError(c, err);
  }
});

const completeEventSchema = z.object({
  actualEndTime: z.string().optional(),
});

const CATEGORY_BUFFERS: Record<string, number> = {
  ceremony: 15,
  firstLook: 12,
  gettingReady: 10,
  cocktail: 10,
  reception: 10,
  sendOff: 5,
  travel: 5,
  other: 10,
};

// POST /api/weddings/:id/events/:eventId/complete
eventsRouter.post("/:eventId/complete", requireAuth, zValidator("json", completeEventSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const eventId = getParam(c, "eventId");
    await requireWeddingAdmin(user.id, weddingId);
    const body = c.req.valid("json");

    const event = await prisma.timelineEvent.findFirst({ where: { id: eventId, weddingId } });
    if (!event) throw new HttpError(404, "EVENT_NOT_FOUND", "Event not found");

    const completedAt = body.actualEndTime ? new Date(body.actualEndTime) : new Date();
    const delayMinutes = Math.round((completedAt.getTime() - new Date(event.endTime).getTime()) / 60000);

    await prisma.timelineEvent.update({
      where: { id: eventId },
      data: { completedAt },
    });

    let adjustedCount = 0;
    let nextEvent: TimelineEventDTO | null = null;
    let suggestedNextStartTime: string | null = null;
    const bufferMinutes = CATEGORY_BUFFERS[event.category] ?? 10;

    if (delayMinutes > 0) {
      const subsequentEvents = await prisma.timelineEvent.findMany({
        where: { weddingId, orderIndex: { gt: event.orderIndex } },
        orderBy: { orderIndex: "asc" },
      });

      if (subsequentEvents.length > 0) {
        await prisma.$transaction(
          subsequentEvents.map((se, idx) => {
            const shiftMs = idx === 0
              ? (delayMinutes + bufferMinutes) * 60000
              : delayMinutes * 60000;
            return prisma.timelineEvent.update({
              where: { id: se.id },
              data: {
                startTime: new Date(se.startTime.getTime() + shiftMs),
                endTime: new Date(se.endTime.getTime() + shiftMs),
              },
            });
          })
        );
        adjustedCount = subsequentEvents.length;
      }
    }

    // Re-fetch first subsequent event after updates
    const firstSubsequent = await prisma.timelineEvent.findFirst({
      where: { weddingId, orderIndex: { gt: event.orderIndex } },
      orderBy: { orderIndex: "asc" },
    });

    if (firstSubsequent) {
      nextEvent = toTimelineEventDTO(firstSubsequent);
      suggestedNextStartTime = firstSubsequent.startTime.toISOString();
    }

    return c.json({
      data: {
        completedAt: completedAt.toISOString(),
        delayMinutes,
        bufferMinutes,
        adjustedCount,
        nextEvent,
        suggestedNextStartTime,
      },
    });
  } catch (err) {
    return handleError(c, err);
  }
});

// POST /api/weddings/:id/events/:eventId/back-on-track
eventsRouter.post("/:eventId/back-on-track", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const eventId = getParam(c, "eventId");
    await requireWeddingAdmin(user.id, weddingId);

    const pivotEvent = await prisma.timelineEvent.findFirst({ where: { id: eventId, weddingId } });
    if (!pivotEvent) throw new HttpError(404, "EVENT_NOT_FOUND", "Event not found");

    const eventsToReset = await prisma.timelineEvent.findMany({
      where: { weddingId, orderIndex: { gte: pivotEvent.orderIndex } },
      orderBy: { orderIndex: "asc" },
    });

    let updatedCount = 0;
    for (const event of eventsToReset) {
      if (event.originalStartTime && event.originalEndTime) {
        await prisma.timelineEvent.update({
          where: { id: event.id },
          data: { startTime: event.originalStartTime, endTime: event.originalEndTime },
        });
        updatedCount++;
      }
    }

    return c.json({ data: { updatedCount } });
  } catch (err) {
    return handleError(c, err);
  }
});

export { eventsRouter };
