import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { prisma } from "../prisma";
import { requireAuth, getUser, requireWeddingMember, requireWeddingCoupleOrAdmin } from "../lib/auth-helpers";
import { handleError, HttpError } from "../lib/http";
import type { AppBindings } from "../lib/context";
import type { ImportantPersonDTO } from "../types";
import { IMPORTANT_PERSON_CATEGORIES } from "../types";
import type { Context } from "hono";

const importantPeopleRouter = new Hono<AppBindings>();

function getParam(c: Context, name: string): string {
  const val = c.req.param(name);
  if (!val) throw new HttpError(400, "MISSING_PARAM", `Missing route param: ${name}`);
  return val;
}

function toImportantPersonDTO(p: {
  id: string;
  weddingId: string;
  name: string;
  relationship: string;
  photoUrl: string | null;
  notes: string | null;
  category: string;
  createdAt: Date;
  updatedAt: Date;
}): ImportantPersonDTO {
  return {
    id: p.id,
    weddingId: p.weddingId,
    name: p.name,
    relationship: p.relationship,
    photoUrl: p.photoUrl,
    notes: p.notes,
    category: p.category as ImportantPersonDTO["category"],
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

// GET /api/weddings/:id/important-people
importantPeopleRouter.get("/", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingMember(user.id, weddingId);

    const people = await prisma.importantPerson.findMany({
      where: { weddingId },
      orderBy: { createdAt: "asc" },
    });

    return c.json({ data: people.map(toImportantPersonDTO) });
  } catch (err) {
    return handleError(c, err);
  }
});

const createPersonSchema = z.object({
  name: z.string().min(1),
  relationship: z.string().min(1),
  category: z.enum(IMPORTANT_PERSON_CATEGORIES),
  notes: z.string().optional(),
  photoUrl: z.string().optional(),
});

// POST /api/weddings/:id/important-people
importantPeopleRouter.post("/", requireAuth, zValidator("json", createPersonSchema), async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    await requireWeddingCoupleOrAdmin(user.id, weddingId);
    const body = c.req.valid("json");

    const person = await prisma.importantPerson.create({
      data: {
        weddingId,
        name: body.name,
        relationship: body.relationship,
        category: body.category,
        notes: body.notes ?? null,
        photoUrl: body.photoUrl ?? null,
      },
    });

    return c.json({ data: toImportantPersonDTO(person) }, 201);
  } catch (err) {
    return handleError(c, err);
  }
});

const patchPersonSchema = z.object({
  name: z.string().min(1).optional(),
  relationship: z.string().optional(),
  category: z.enum(IMPORTANT_PERSON_CATEGORIES).optional(),
  notes: z.string().nullable().optional(),
  photoUrl: z.string().nullable().optional(),
});

// PATCH /api/weddings/:id/important-people/:personId
importantPeopleRouter.patch(
  "/:personId",
  requireAuth,
  zValidator("json", patchPersonSchema),
  async (c) => {
    try {
      const user = getUser(c);
      const weddingId = getParam(c, "id");
      const personId = getParam(c, "personId");
      await requireWeddingCoupleOrAdmin(user.id, weddingId);
      const body = c.req.valid("json");

      const existing = await prisma.importantPerson.findFirst({ where: { id: personId, weddingId } });
      if (!existing) throw new HttpError(404, "PERSON_NOT_FOUND", "Important person not found");

      const updated = await prisma.importantPerson.update({
        where: { id: personId },
        data: {
          ...(body.name !== undefined && { name: body.name }),
          ...(body.relationship !== undefined && { relationship: body.relationship }),
          ...(body.category !== undefined && { category: body.category }),
          ...(body.notes !== undefined && { notes: body.notes }),
          ...(body.photoUrl !== undefined && { photoUrl: body.photoUrl }),
        },
      });

      return c.json({ data: toImportantPersonDTO(updated) });
    } catch (err) {
      return handleError(c, err);
    }
  }
);

// DELETE /api/weddings/:id/important-people/:personId
importantPeopleRouter.delete("/:personId", requireAuth, async (c) => {
  try {
    const user = getUser(c);
    const weddingId = getParam(c, "id");
    const personId = getParam(c, "personId");
    await requireWeddingCoupleOrAdmin(user.id, weddingId);

    const existing = await prisma.importantPerson.findFirst({ where: { id: personId, weddingId } });
    if (!existing) throw new HttpError(404, "PERSON_NOT_FOUND", "Important person not found");

    await prisma.importantPerson.delete({ where: { id: personId } });
    return c.json({ data: { success: true } });
  } catch (err) {
    return handleError(c, err);
  }
});

export { importantPeopleRouter };
