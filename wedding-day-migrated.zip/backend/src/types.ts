// =====================
// Shared types and constants for the wedding coordination API.
// Mirror this file on the mobile side for end-to-end type safety.
// =====================

// ----- Roles -----
export const USER_ROLES = ["vendor", "couple", "admin"] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const VENDOR_SPECIALTIES = [
  "photographer",
  "videographer",
  "dj",
  "planner",
  "coordinator",
  "florist",
  "caterer",
  "officiant",
  "hairMakeup",
  "transportation",
  "other",
] as const;
export type VendorSpecialty = (typeof VENDOR_SPECIALTIES)[number];

// ----- Timeline event categories -----
export const EVENT_CATEGORIES = [
  "gettingReady",
  "firstLook",
  "ceremony",
  "cocktail",
  "reception",
  "sendOff",
  "travel",
  "other",
] as const;
export type EventCategory = (typeof EVENT_CATEGORIES)[number];

// ----- Important person categories -----
export const IMPORTANT_PERSON_CATEGORIES = [
  "family",
  "bridalParty",
  "speechGiver",
  "officiant",
  "vip",
  "other",
] as const;
export type ImportantPersonCategory = (typeof IMPORTANT_PERSON_CATEGORIES)[number];

// ----- Change request status -----
export const CHANGE_REQUEST_STATUS = ["pending", "approved", "rejected"] as const;
export type ChangeRequestStatus = (typeof CHANGE_REQUEST_STATUS)[number];

// ----- DTOs returned by the API -----

export type UserProfileDTO = {
  id: string; // user.id
  userId: string; // user.id (alias for clarity)
  email: string;
  name: string;
  displayName: string;
  role: UserRole;
  vendorSpecialty: VendorSpecialty | null;
  phone: string | null;
  company: string | null;
  image: string | null;
  createdAt: string;
  updatedAt: string;
};

export type MeResponse = {
  user: {
    id: string;
    email: string;
    name: string;
    image: string | null;
  };
  profile: UserProfileDTO;
};

export type WeddingMemberDTO = {
  id: string;
  weddingId: string;
  userId: string;
  role: UserRole;
  vendorSpecialty: VendorSpecialty | null;
  joinedAt: string;
  user: {
    id: string;
    displayName: string;
    name: string;
    email: string;
    image: string | null;
    phone: string | null;
    company: string | null;
  };
};

export type WeddingDTO = {
  id: string;
  partner1Name: string;
  partner2Name: string;
  weddingDate: string;
  venueName: string | null;
  timezone: string;
  inviteCode: string;
  createdById: string;
  createdAt: string;
  updatedAt: string;
};

export type WeddingWithRoleDTO = WeddingDTO & {
  myRole: UserRole;
  myVendorSpecialty: VendorSpecialty | null;
};

export type TimelineEventDTO = {
  id: string;
  weddingId: string;
  title: string;
  description: string | null;
  startTime: string;
  endTime: string;
  originalStartTime: string | null;
  originalEndTime: string | null;
  completedAt: string | null;
  locationName: string | null;
  address: string | null;
  category: EventCategory;
  assignedVendorIds: string[];
  orderIndex: number;
  createdAt: string;
  updatedAt: string;
};

export type ChangeRequestDTO = {
  id: string;
  weddingId: string;
  eventId: string;
  requestedById: string;
  requestedByName: string;
  proposedStartTime: string | null;
  proposedEndTime: string | null;
  proposedTitle: string | null;
  proposedDescription: string | null;
  reason: string | null;
  status: ChangeRequestStatus;
  resolvedById: string | null;
  resolvedAt: string | null;
  createdAt: string;
};

export type ImportantPersonDTO = {
  id: string;
  weddingId: string;
  name: string;
  relationship: string;
  photoUrl: string | null;
  notes: string | null;
  category: ImportantPersonCategory;
  createdAt: string;
  updatedAt: string;
};

export type WeddingDetailDTO = WeddingDTO & {
  myRole: UserRole;
  myVendorSpecialty: VendorSpecialty | null;
  members: WeddingMemberDTO[];
  events: TimelineEventDTO[];
  importantPeople: ImportantPersonDTO[];
  pendingChangeRequests: ChangeRequestDTO[];
};

export type UploadedFileDTO = {
  id: string;
  url: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
};
