import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import "./env";
import { auth } from "./auth";
import type { AppBindings } from "./lib/context";
import { handleError } from "./lib/http";
import { meRouter } from "./routes/me";
import { weddingsRouter } from "./routes/weddings";
import { eventsRouter } from "./routes/events";
import { changeRequestsRouter } from "./routes/change-requests";
import { importantPeopleRouter } from "./routes/important-people";
import { uploadRouter } from "./routes/upload";

const app = new Hono<AppBindings>();

// CORS middleware - allow all origins (mobile app + any web client)
app.use(
  "*",
  cors({
    origin: "*",
    credentials: false,
  })
);

app.use("*", logger());

// Session middleware — reads Better Auth session and injects user/session into context
app.use("*", async (c, next) => {
  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  c.set("user", session?.user ?? null);
  c.set("session", session?.session ?? null);
  await next();
});

// Health check
app.get("/health", (c) => c.json({ status: "ok" }));

// Better Auth handler
app.on(["POST", "GET"], "/api/auth/*", (c) => auth.handler(c.req.raw));

// App routes
app.route("/api/me", meRouter);
app.route("/api/weddings", weddingsRouter);
app.route("/api/weddings/:id/events", eventsRouter);
app.route("/api/weddings/:id/change-requests", changeRequestsRouter);
app.route("/api/weddings/:id/important-people", importantPeopleRouter);
app.route("/api/upload", uploadRouter);

// Global error handler
app.onError((err, c) => handleError(c, err));

const port = Number(process.env.PORT) || 3000;

export default {
  port,
  fetch: app.fetch,
};
