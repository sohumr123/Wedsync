import { betterAuth } from "better-auth";
import { expo } from "@better-auth/expo";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { emailOTP } from "better-auth/plugins";
import { prisma } from "./prisma";
import { env } from "./env";

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: "sqlite" }),
  secret: env.BETTER_AUTH_SECRET,
  baseURL: env.BACKEND_URL,

  user: {
    additionalFields: {
      displayName: {
        type: "string",
        required: false,
        defaultValue: "",
        input: true,
      },
      role: {
        type: "string",
        required: false,
        defaultValue: "couple",
        input: true,
      },
      vendorSpecialty: {
        type: "string",
        required: false,
        input: true,
      },
      phone: {
        type: "string",
        required: false,
        input: true,
      },
      company: {
        type: "string",
        required: false,
        input: true,
      },
    },
  },

  trustedOrigins: [
    "exp://*/*",
    "http://localhost:*",
    "http://127.0.0.1:*",
  ],
  plugins: [
    expo(),
    emailOTP({
      async sendVerificationOTP({ email, otp, type }) {
        if (type !== "sign-in") return;

        const response = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${env.RESEND_API_KEY}`,
          },
          body: JSON.stringify({
            from: "Wedding Day <onboarding@resend.dev>",
            to: email,
            subject: "Your sign-in code",
            html: `<p>Your Wedding Day sign-in code is: <strong>${otp}</strong></p><p>This code expires in 10 minutes.</p>`,
          }),
        });

        if (!response.ok) {
          const data = await response.json().catch(() => null);
          throw new Error(
            (data as { message?: string } | null)?.message ||
              `Failed to send OTP (HTTP ${response.status})`
          );
        }
      },
    }),
  ],

  advanced: {
    trustedProxyHeaders: true,
    disableCSRFCheck: true,
    defaultCookieAttributes: {
      sameSite: "none",
      secure: true,
      partitioned: true,
    },
  },
});

export type AuthUser = typeof auth.$Infer.Session.user;
export type AuthSession = typeof auth.$Infer.Session.session;
