import type { Context, MiddlewareHandler } from "hono";
import { prisma } from "../prisma";
import { HttpError } from "./http";
import type { AppBindings } from "./context";

/**
 * Middleware that requires the request to have an authenticated session.
 * Throws 401 otherwise. The user/session variables are guaranteed non-null
 * after this runs.
 */
export const requireAuth: MiddlewareHandler<AppBindings> = async (c, next) => {
  const user = c.get("user");
  if (!user) {
    throw new HttpError(401, "UNAUTHENTICATED", "Authentication required");
  }
  await next();
};

export function getUser(c: Context<AppBindings>) {
  const user = c.get("user");
  if (!user) {
    throw new HttpError(401, "UNAUTHENTICATED", "Authentication required");
  }
  return user;
}

/**
 * Verify the caller is a member of the given wedding. Returns the
 * WeddingMember row. Throws 403 if not a member.
 */
export async function requireWeddingMember(userId: string, weddingId: string) {
  const member = await prisma.weddingMember.findUnique({
    where: { weddingId_userId: { weddingId, userId } },
  });
  if (!member) {
    throw new HttpError(403, "NOT_A_MEMBER", "You are not a member of this wedding");
  }
  return member;
}

/**
 * Verify the caller is an admin (per-wedding role) of the given wedding.
 * Throws 403 otherwise. Returns the WeddingMember row.
 */
export async function requireWeddingAdmin(userId: string, weddingId: string) {
  const member = await requireWeddingMember(userId, weddingId);
  if (member.role !== "admin") {
    throw new HttpError(403, "NOT_ADMIN", "Admin role required for this wedding");
  }
  return member;
}

/**
 * Verify the caller is either the couple (per-wedding role) or admin
 * for the given wedding. Throws 403 otherwise.
 */
export async function requireWeddingCoupleOrAdmin(userId: string, weddingId: string) {
  const member = await requireWeddingMember(userId, weddingId);
  if (member.role !== "admin" && member.role !== "couple") {
    throw new HttpError(403, "NOT_COUPLE_OR_ADMIN", "Couple or admin role required");
  }
  return member;
}
