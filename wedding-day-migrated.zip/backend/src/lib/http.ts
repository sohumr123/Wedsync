import type { Context } from "hono";
import type { StatusCode } from "hono/utils/http-status";

export type ApiError = {
  error: {
    message: string;
    code: string;
  };
};

// Status codes that can carry a JSON body.
export type ApiStatus = Exclude<StatusCode, 101 | 204 | 205 | 304>;

export class HttpError extends Error {
  override readonly name = "HttpError";
  constructor(
    public readonly status: ApiStatus,
    public readonly code: string,
    message: string
  ) {
    super(message);
  }
}

export function errorResponse(
  c: Context,
  status: ApiStatus,
  code: string,
  message: string
) {
  return c.json({ error: { message, code } } satisfies ApiError, status as never);
}

export function handleError(c: Context, err: unknown) {
  if (err instanceof HttpError) {
    return errorResponse(c, err.status, err.code, err.message);
  }
  console.error("Unhandled error:", err);
  const message = err instanceof Error ? err.message : "Internal server error";
  return errorResponse(c, 500, "INTERNAL", message);
}
