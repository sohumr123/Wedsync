import type {
  User,
  Wedding,
  WeddingMember,
  TimelineEvent,
  ChangeRequest,
  ImportantPerson,
} from "@prisma/client";
import type {
  WeddingDTO,
  WeddingMemberDTO,
  TimelineEventDTO,
  ChangeRequestDTO,
  ImportantPersonDTO,
  UserProfileDTO,
  UserRole,
  VendorSpecialty,
  EventCategory,
  ImportantPersonCategory,
  ChangeRequestStatus,
} from "../types";

export function parseAssignedVendorIds(json: string): string[] {
  try {
    const parsed = JSON.parse(json);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((x): x is string => typeof x === "string");
  } catch {
    return [];
  }
}

export function serializeAssignedVendorIds(ids: string[]): string {
  return JSON.stringify(ids);
}

export function userProfileDTO(u: User): UserProfileDTO {
  return {
    id: u.id,
    userId: u.id,
    email: u.email,
    name: u.name,
    displayName: u.displayName,
    role: u.role as UserRole,
    vendorSpecialty: (u.vendorSpecialty as VendorSpecialty | null) ?? null,
    phone: u.phone ?? null,
    company: u.company ?? null,
    image: u.image ?? null,
    createdAt: u.createdAt.toISOString(),
    updatedAt: u.updatedAt.toISOString(),
  };
}

export function weddingDTO(w: Wedding): WeddingDTO {
  return {
    id: w.id,
    partner1Name: w.partner1Name,
    partner2Name: w.partner2Name,
    weddingDate: w.weddingDate.toISOString(),
    venueName: w.venueName,
    timezone: w.timezone,
    inviteCode: w.inviteCode,
    createdById: w.createdById,
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
  };
}

export function weddingMemberDTO(
  m: WeddingMember & { user: User }
): WeddingMemberDTO {
  return {
    id: m.id,
    weddingId: m.weddingId,
    userId: m.userId,
    role: m.role as UserRole,
    vendorSpecialty: (m.vendorSpecialty as VendorSpecialty | null) ?? null,
    joinedAt: m.joinedAt.toISOString(),
    user: {
      id: m.user.id,
      displayName: m.user.displayName,
      name: m.user.name,
      email: m.user.email,
      image: m.user.image ?? null,
      phone: m.user.phone ?? null,
      company: m.user.company ?? null,
    },
  };
}

export function timelineEventDTO(e: TimelineEvent): TimelineEventDTO {
  return {
    id: e.id,
    weddingId: e.weddingId,
    title: e.title,
    description: e.description,
    startTime: e.startTime.toISOString(),
    endTime: e.endTime.toISOString(),
    originalStartTime: e.originalStartTime?.toISOString() ?? null,
    originalEndTime: e.originalEndTime?.toISOString() ?? null,
    completedAt: e.completedAt?.toISOString() ?? null,
    locationName: e.locationName,
    address: e.address,
    category: e.category as EventCategory,
    assignedVendorIds: parseAssignedVendorIds(e.assignedVendorIds),
    orderIndex: e.orderIndex,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt.toISOString(),
  };
}

export function changeRequestDTO(r: ChangeRequest): ChangeRequestDTO {
  return {
    id: r.id,
    weddingId: r.weddingId,
    eventId: r.eventId,
    requestedById: r.requestedById,
    requestedByName: r.requestedByName,
    proposedStartTime: r.proposedStartTime ? r.proposedStartTime.toISOString() : null,
    proposedEndTime: r.proposedEndTime ? r.proposedEndTime.toISOString() : null,
    proposedTitle: r.proposedTitle,
    proposedDescription: r.proposedDescription,
    reason: r.reason,
    status: r.status as ChangeRequestStatus,
    resolvedById: r.resolvedById,
    resolvedAt: r.resolvedAt ? r.resolvedAt.toISOString() : null,
    createdAt: r.createdAt.toISOString(),
  };
}

export function importantPersonDTO(p: ImportantPerson): ImportantPersonDTO {
  return {
    id: p.id,
    weddingId: p.weddingId,
    name: p.name,
    relationship: p.relationship,
    photoUrl: p.photoUrl,
    notes: p.notes,
    category: p.category as ImportantPersonCategory,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}
